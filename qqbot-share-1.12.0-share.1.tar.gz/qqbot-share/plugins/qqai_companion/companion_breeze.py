"""BreezeBlue hosted TTS; bounded WAV in memory, fixed official API only."""
from __future__ import annotations

import re

import aiohttp

API = 'https://api.breeze.blue/v1/text-to-speech/'
MAX_BYTES = 3 * 1024**2


class BreezeError(RuntimeError):
    """Safe, fixed diagnostic; never include upstream content or credentials."""


class BreezeVoice:
    def __init__(self, api_key, voice_id):
        if (not isinstance(api_key, str) or not 8 <= len(api_key) <= 512
                or not re.fullmatch(r'[\x21-\x7e]+', api_key)):
            raise BreezeError('Invalid BreezeBlue credential')
        if not isinstance(voice_id, str) or not re.fullmatch(r'voc_[A-Za-z0-9]{6,64}', voice_id):
            raise BreezeError('Invalid BreezeBlue voice ID')
        self._api_key = api_key
        self.voice = voice_id

    async def get_audio(self, text):
        if not isinstance(text, str) or not text.strip() or len(text) > 120:
            raise BreezeError('Invalid speech text')
        try:
            async with aiohttp.ClientSession(
                    timeout=aiohttp.ClientTimeout(total=40, connect=5, sock_read=15),
                    trust_env=False, auto_decompress=False) as session:
                async with session.post(
                        API+self.voice,
                        params={'output_format': 'wav_24000', 'delivery': 'sync'},
                        headers={'xi-api-key': self._api_key, 'Accept': 'audio/wav',
                                 'Accept-Encoding': 'identity'},
                        json={'text': text, 'model_id': 'breeze-tts-2', 'language_code': 'zh'},
                        allow_redirects=False) as response:
                    if response.status != 200:
                        # Never consume/echo API error bodies or follow redirects with the key.
                        raise BreezeError('BreezeBlue synthesis rejected')
                    content_type=response.headers.get('Content-Type', '').split(';',1)[0].lower().strip()
                    if content_type not in ('audio/wav', 'audio/x-wav', 'audio/wave', 'application/octet-stream'):
                        raise BreezeError('Unexpected BreezeBlue audio type')
                    if response.headers.get('Content-Encoding', 'identity').lower() not in ('', 'identity'):
                        raise BreezeError('Unexpected BreezeBlue encoding')
                    if response.content_length is not None and not 44 <= response.content_length <= MAX_BYTES:
                        raise BreezeError('BreezeBlue audio size limit')
                    raw=bytearray()
                    async for chunk in response.content.iter_chunked(64*1024):
                        if len(raw)+len(chunk)>MAX_BYTES:
                            raise BreezeError('BreezeBlue audio size limit')
                        raw.extend(chunk)
                    if len(raw)<44 or raw[:4]!=b'RIFF' or raw[8:12]!=b'WAVE':
                        raise BreezeError('Invalid BreezeBlue WAV')
                    # VoiceService validates PCM, sample width, duration and truncation.
                    return bytes(raw)
        except BreezeError:
            raise
        except Exception:
            # Library errors can retain request headers; suppress chained diagnostics.
            raise BreezeError('BreezeBlue request failed') from None
