"""Runs once inside the pinned AstrBot image, before starting message processing."""
import asyncio
import copy
import json
from pathlib import Path
import sqlite3
import sys

async def bootstrap():
    from astrbot.core import astrbot_config,db_helper,sp
    from astrbot.core.astrbot_config_mgr import AstrBotConfigManager
    from astrbot.core.umop_config_router import UmopConfigRouter
    data=Path('/AstrBot/data')
    if (data/'.share-bootstrap-complete').exists():raise RuntimeError('Bootstrap already completed')
    if (data/'data_v4.db').exists() and (data/'data_v4.db').stat().st_size:
        raise RuntimeError('Refusing to initialize an existing database')
    await db_helper.initialize();await sp.initialize()
    try:
        await db_helper.insert_persona('小鲸鱼',(data/'share-persona.txt').read_text(encoding='utf-8'),tools=[],skills=[])
        router=UmopConfigRouter(sp);await router.initialize()
        manager=AstrBotConfigManager(astrbot_config,router,sp);await manager.initialize()
        private=copy.deepcopy(dict(astrbot_config))
        private['platform_settings'].update(enable_id_white_list=False,wl_ignore_admin_on_group=False,
            wl_ignore_admin_on_friend=False,friend_message_needs_wake_prefix=False)
        profile=await manager.create_conf(private,name='小鲸鱼私聊_仅授权群成员')
        await router.update_routing_data({'qqai:FriendMessage:*':profile})
        directory=data/'plugin_data/qqai_companion';directory.mkdir(parents=True,exist_ok=True,mode=0o700)
        with sqlite3.connect(directory/'memory.sqlite3') as conn:
            conn.execute('CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT)')
            conn.execute('INSERT INTO meta VALUES(?,?)',('qqai_private_profile_v170',json.dumps({'id':profile,'group':astrbot_config['platform_settings']['id_whitelist'][0]})))
        (directory/'memory.sqlite3').chmod(0o600)
        (data/'.share-bootstrap-complete').write_text('1.12.0-share.1\n',encoding='utf-8')
        print('Fresh database, persona and private route prepared before first start.')
    finally:
        await sp.close();await db_helper.engine.dispose()

if __name__=='__main__':asyncio.run(bootstrap())
