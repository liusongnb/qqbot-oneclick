"""Disposable Linux Docker smoke test; never contacts a real model/QQ account."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parents[1]
TARGET=Path('/opt/qqbot-share')

def run(args,**kw):return subprocess.run(args,check=True,text=True,**kw)

answers=ROOT/'ci-answers.json'
answers.write_text(json.dumps({'group':'777777777','api_key':'synthetic-not-a-real-key',
    'api_base':'https://example.invalid/v1','model':'synthetic-test','voice_engine':'edge_tts'}))
answers.chmod(0o600)
try:
    # Exercise the actual installer. GitHub's expendable runner already has Docker.
    # get.sh downloads the public archive and verifies its SHA before install.sh.
    run(['sudo','bash',str(ROOT/'get.sh'),'--answers-file',str(answers)])
    run(['sudo','docker','compose','exec','-T','astrbot','python','-'],
        input=(ROOT/'ci/assert_native.py').read_text(encoding='utf-8'),cwd=TARGET)
    print('PASS: pinned Docker images start; native DB/persona, preloaded private route and plugin imports verified.')
finally:
    answers.unlink(missing_ok=True)
    if TARGET.exists():
        subprocess.run(['sudo','docker','compose','down'],cwd=TARGET,check=False)
