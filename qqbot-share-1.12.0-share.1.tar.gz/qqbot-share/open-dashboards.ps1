param([string]$Server,[int]$Port=22)
$ErrorActionPreference='Stop'
if(-not $Server){$Server=Read-Host 'SSH destination (user@server or SSH config alias)'}
if($Server -notmatch '^[a-zA-Z0-9_.@-]+$' -or $Server.StartsWith('-')){throw 'Invalid SSH destination'}
foreach($localPort in @(26185,26099)){
 if(Get-NetTCPConnection -State Listen -LocalPort $localPort -ErrorAction SilentlyContinue){throw "Local port $localPort is already in use"}
}
Write-Host 'SSH will request authentication if needed. Keep this window open while using the dashboards.'
$tunnel=Start-Process -FilePath ssh.exe -ArgumentList @('-N','-T','-o','ExitOnForwardFailure=yes','-o','ServerAliveInterval=30','-p',"$Port",'-L','127.0.0.1:26185:127.0.0.1:16185','-L','127.0.0.1:26099:127.0.0.1:6099',$Server) -NoNewWindow -PassThru
try{
 $ready=$false
 for($attempt=0;$attempt -lt 60;$attempt++){
  if($tunnel.HasExited){throw 'SSH tunnel exited. Try the printed ssh command in your terminal to authenticate.'}
  if((Test-NetConnection -ComputerName 127.0.0.1 -Port 26185 -InformationLevel Quiet -WarningAction SilentlyContinue) -and (Test-NetConnection -ComputerName 127.0.0.1 -Port 26099 -InformationLevel Quiet -WarningAction SilentlyContinue)){$ready=$true;break}
  Start-Sleep -Milliseconds 500
 }
 if(-not $ready){throw 'Tunnel did not become ready'}
 Start-Process 'http://127.0.0.1:26185/'
 Start-Process 'http://127.0.0.1:26099/webui/'
 Read-Host 'Press Enter to close the tunnel'
}finally{if(-not $tunnel.HasExited){Stop-Process -Id $tunnel.Id}}
