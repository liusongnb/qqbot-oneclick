"""Isolated tests: fake provider/events, temporary synthetic data, no network."""
import asyncio
import base64
import io
import importlib.util
import json
import pathlib
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
from PIL import Image as PILImage

ROOT=pathlib.Path(__file__).resolve().parent
for name in ['astrbot','astrbot.api','astrbot.api.event','astrbot.api.star','astrbot.api.message_components','astrbot.core','astrbot.core.platform','astrbot.core.platform.message_type','astrbot.core.star','astrbot.core.star.filter','astrbot.core.star.filter.custom_filter']:
    sys.modules[name]=types.ModuleType(name)
class Log:
    def __getattr__(self,key):return lambda *a,**k:None
class Star:
    def __init__(self,context,*a,**k):self.context=context
sys.modules['astrbot.api'].logger=Log()
class BaseEvent:
    def plain_result(self,text):return text
    def chain_result(self,chain):return chain
sys.modules['astrbot.api.event'].AstrMessageEvent=BaseEvent
sys.modules['astrbot.api.event'].filter=types.SimpleNamespace(custom_filter=lambda *a,**k:lambda f:f)
sys.modules['astrbot.api.star'].Context=object
sys.modules['astrbot.api.star'].Star=Star
sys.modules['astrbot.api.star'].StarTools=types.SimpleNamespace()
sys.modules['astrbot.core.platform.message_type'].MessageType=types.SimpleNamespace(GROUP_MESSAGE='group',FRIEND_MESSAGE='friend')
sys.modules['astrbot.core.star.filter.custom_filter'].CustomFilter=object
spec=importlib.util.spec_from_file_location('companion_under_test',ROOT/'astrbot_plugin_qqai_companion/main.py',submodule_search_locations=[str(ROOT/'astrbot_plugin_qqai_companion')])
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
# Baseline regressions must never load an actual online speech client.
m.EdgeVoice=lambda *a,**k:None
class Image:
    def __init__(self,file='',url=''):self.file=file;self.url=url
    @staticmethod
    def fromBytes(raw):return Image(file='base64://'+__import__('base64').b64encode(raw).decode())
sys.modules['astrbot.api.message_components'].Image=Image
CFG={'platform_settings':{'enable_id_white_list':True,'id_whitelist':['888888888'],'wl_ignore_admin_on_group':False,'wl_ignore_admin_on_friend':False},'agent_runner':{'config':{'persona':{'persona_id':'大肥鱼_QQ888888888'}}}}
class Event:
    serial=0
    def __init__(self,text='大肥鱼你好',group='888888888',sender='test-A',platform='qqai',kind='group',parts=(),direct=False):
        Event.serial+=1;self.message_obj=types.SimpleNamespace(message_id=str(Event.serial));self.text=text;self.group=group;self.sender=sender;self.platform=platform;self.kind=kind;self.parts=parts;self.is_at_or_wake_command=direct;self.unified_msg_origin=platform+':GroupMessage:'+group;self.extras={};self.sent=[];self.stopped=False
    def get_message_type(self):return self.kind
    def get_platform_name(self):return 'aiocqhttp'
    def get_platform_id(self):return self.platform
    def get_group_id(self):return self.group
    def get_sender_id(self):return self.sender
    def get_self_id(self):return 'test-BOT'
    def get_sender_name(self):return '测试成员'
    def get_message_str(self):return self.text
    def get_messages(self):return self.parts
    def get_extra(self,key,default=None):return self.extras.get(key,default)
    def set_extra(self,key,value):self.extras[key]=value
    def stop_event(self):self.stopped=True
    def plain_result(self,text):return text
    def chain_result(self,chain):return chain
    async def send(self,text):self.sent.append(text)
class Context:
    def __init__(self):
        self.calls=[];self.responses=[];self.concurrent=0;self.peak=0;self.pause=False
        self.sent=[];self.send_ok=True;self.before_return=None;self.cfg=json.loads(json.dumps(CFG))
        self.persona_manager=types.SimpleNamespace(get_persona=self.get_persona)
    def get_config(self,umo):return self.cfg
    def get_platform_inst(self,pid):return types.SimpleNamespace(meta=lambda:types.SimpleNamespace(name="aiocqhttp")) if pid=="qqai" else None
    async def send_message(self,umo,chain):
        if self.send_ok:self.sent.append((umo,chain))
        return self.send_ok
    async def get_persona(self,pid):return types.SimpleNamespace(system_prompt='你叫大肥鱼。')
    async def get_current_chat_provider_id(self,umo):return 'existing-provider'
    async def llm_generate(self,**kw):
        self.calls.append(kw);self.concurrent+=1;self.peak=max(self.peak,self.concurrent)
        try:
            await asyncio.sleep(0.03 if self.pause else 0)
            answer=self.responses.pop(0) if self.responses else '你好呀'
            if self.before_return:
                action=self.before_return;self.before_return=None
                await action()
            return types.SimpleNamespace(completion_text=answer)
        finally:self.concurrent-=1

class StoreTest(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.s=m.Store(self.temp.name)
    def tearDown(self):self.s.close();self.temp.cleanup()
    def test_same_user_cannot_recall_other_group_or_platform(self):
        a=self.s.scope('qqai','G1','U1');b=self.s.scope('qqai','G2','U1');c=self.s.scope('other','G1','U1')
        self.s.remember(a,'喜欢吃米饭');self.assertEqual(self.s.facts(a,'米饭'),['喜欢吃米饭']);self.assertEqual(self.s.facts(b,'米饭'),[]);self.assertEqual(self.s.facts(c,'米饭'),[])
    def test_group_members_do_not_share_personal_memory(self):
        a=self.s.scope('qqai','G1','U1');b=self.s.scope('qqai','G1','U2');self.s.remember(a,'喜欢音乐');self.assertEqual(self.s.facts(b,'音乐'),[])
    def test_restart_persistence_and_scope_specific_forget(self):
        a=self.s.scope('qqai','G1','U1');b=self.s.scope('qqai','G1','U2');self.s.remember(a,'喜欢米饭');self.s.remember(b,'喜欢面条');self.s.close();self.s=m.Store(self.temp.name);self.assertEqual(self.s.scope('qqai','G1','U1'),a);self.assertTrue(self.s.facts(a,'米饭'));self.s.forget(a);self.assertFalse(self.s.facts(a,'米饭'));self.assertTrue(self.s.facts(b,'面条'))
    def test_daily_quota_survives_restart(self):
        self.assertTrue(self.s.consume('llm_calls',1));self.s.close();self.s=m.Store(self.temp.name);self.assertFalse(self.s.consume('llm_calls',1))
    def test_sensitive_memory_rejected(self):
        scope=self.s.scope('qqai','G1','U1');self.assertFalse(self.s.remember(scope,'我的密码是测试'));self.assertFalse(self.s.remember(scope,'手机号13800138000'));self.assertFalse(self.s.facts(scope,'密码'))
    def test_history_and_facts_are_bounded(self):
        scope=self.s.scope('qqai','G1','U1')
        for n in range(120):self.s.remember(scope,'偏好'+str(n));self.s.add_turn(scope,'问题'+str(n),'回复'+str(n))
        self.assertEqual(self.s.db.execute('SELECT count(*) FROM facts').fetchone()[0],100);self.assertEqual(len(self.s.history(scope)),12)

    def test_webui_schema_keeps_operating_limits_and_config_in_sync(self):
        schema=json.loads((ROOT/'astrbot_plugin_qqai_companion/_conf_schema.json').read_text(encoding='utf-8'))
        config=json.loads((ROOT/'plugin-config.json').read_text(encoding='utf-8'))
        self.assertEqual(set(schema),set(config));self.assertEqual(schema['per_minute_replies']['default'],6)
        for key,row in schema.items():
            if key not in {'proactive_enabled','allowed_groups','voice_unlimited_users','breeze_voice_id'}:self.assertEqual(row['default'],config[key],key)

    def test_changed_preference_replaces_exact_opposite_for_same_member(self):
        a=self.s.scope('qqai','G1','U1');b=self.s.scope('qqai','G1','U2')
        self.s.remember(a,'喜欢草莓');self.s.remember(b,'喜欢草莓');self.s.remember(a,'不喜欢草莓')
        self.assertEqual(self.s.facts(a,'草莓'),['不喜欢草莓']);self.assertEqual(self.s.facts(b,'草莓'),['喜欢草莓'])

class PolicyTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        asyncio.get_running_loop().slow_callback_duration=1
        self.temp=tempfile.TemporaryDirectory();self.ctx=Context();self.p=m.Main(self.ctx,json.loads((ROOT/'plugin-config.json').read_text(encoding='utf-8')));self.p.store=m.Store(self.temp.name);self.p.ready=True;self.p.quiet=lambda:False;self.p.config["active_enabled"]=True
    async def asyncTearDown(self):await self.p.terminate();self.temp.cleanup()
    async def test_private_other_group_platform_and_self_denied(self):
        for e in [Event(group='',kind='friend'),Event(group='888888888',kind='friend'),Event(group='other'),Event(platform='telegram'),Event(sender='test-BOT')]:
            self.assertFalse(self.p.prepare(e,CFG));await self.p.on_candidate(e);self.assertFalse(e.sent)
        self.assertFalse(self.ctx.calls)
    async def test_empty_plugin_or_framework_whitelist_fails_closed(self):
        self.p.config['allowed_groups']=[];self.assertFalse(self.p.prepare(Event(),CFG));self.p.config['allowed_groups']=['888888888'];self.assertFalse(self.p.prepare(Event(),{'platform_settings':{}}))
    async def test_named_message_uses_existing_model_without_tools(self):
        e=Event();self.assertTrue(self.p.prepare(e,CFG));await self.p.on_candidate(e)
        self.assertEqual(e.sent,['你好呀']);self.assertTrue(e.stopped);self.assertEqual(self.ctx.calls[0]['chat_provider_id'],'existing-provider');self.assertIsNone(self.ctx.calls[0]['tools']);self.assertEqual(self.ctx.calls[0]['request_max_retries'],1)
    async def test_continuation_does_not_need_name_and_can_stay_silent(self):
        e=Event();self.p.prepare(e,CFG);await self.p.on_candidate(e);self.p.reply_times.clear()
        e=Event('那你喜欢什么？');self.assertTrue(self.p.prepare(e,CFG));self.assertEqual(e.extras[m.EXTRA]['mode'],'followup')
        self.ctx.responses=['{"reply":false,"confidence":0.99}'];await self.p.on_candidate(e);self.assertFalse(e.sent)
    async def test_ambient_cooldown_cannot_be_lowered_under_five_minutes(self):
        self.p.config['active_cooldown_sec']=1;e=Event('你觉得晚饭吃什么？');self.assertTrue(self.p.prepare(e,CFG));self.ctx.responses=['{"reply":true,"confidence":0.95}','吃点米饭呀'];await self.p.on_candidate(e);self.assertTrue(e.sent);self.assertFalse(self.p.prepare(Event('有人知道游戏怎么玩吗？',sender='test-B'),CFG))
    async def test_ordinary_public_statement_can_be_considered_without_name(self):
        e=Event('今天下班路上看到了好漂亮的晚霞');self.assertTrue(self.p.prepare(e,CFG));self.assertEqual(e.get_extra(m.EXTRA)['mode'],'active')
        self.ctx.responses=['{"reply":true,"confidence":0.96}','听起来很漂亮呀'];await self.p.on_candidate(e);self.assertEqual(e.sent,['听起来很漂亮呀'])
    async def test_seventh_reply_within_minute_is_blocked(self):
        self.p.reply_times.extend([m.time.monotonic()-10]*6);e=Event();self.p.prepare(e,CFG);await self.p.on_candidate(e);self.assertFalse(e.sent);self.assertFalse(self.ctx.calls);self.assertEqual(self.p.store.used('skip_reply_rate'),1)
    async def test_mention_and_reply_to_another_member_is_not_hijacked(self):
        At=type('At',(),{});at=At();at.qq='test-C';self.assertFalse(self.p.prepare(Event('你觉得呢？',parts=[at]),CFG))
    async def test_intervening_member_breaks_automatic_followup(self):
        a=Event();self.p.prepare(a,CFG);await self.p.on_candidate(a);self.p.prepare(Event('今天挺安静',sender='test-C'),CFG);self.assertFalse(self.p.prepare(Event('要'),CFG))
    async def test_explicit_followup_survives_intervening_member(self):
        a=Event();self.p.prepare(a,CFG);await self.p.on_candidate(a);self.p.prepare(Event('今天挺安静',sender='test-C'),CFG)
        b=Event('我刚才说喜欢什么？');self.assertTrue(self.p.prepare(b,CFG));self.assertEqual(b.get_extra(m.EXTRA)['mode'],'followup')
    async def test_another_member_can_address_bot_without_repeating_name(self):
        a=Event();self.p.prepare(a,CFG);await self.p.on_candidate(a)
        b=Event('那你喜欢什么？',sender='test-C');self.assertTrue(self.p.prepare(b,CFG));self.assertEqual(b.get_extra(m.EXTRA)['mode'],'followup')
    async def test_parallel_messages_do_not_create_parallel_calls(self):
        self.ctx.pause=True;a=Event();b=Event('大肥鱼你好呀',sender='test-B');self.p.prepare(a,CFG);self.p.prepare(b,CFG);await asyncio.gather(self.p.on_candidate(a),self.p.on_candidate(b));self.assertEqual(self.ctx.peak,1);self.assertEqual(len(a.sent)+len(b.sent),1)
    async def test_paused_extension_never_calls_model_or_sends(self):
        (self.p.store.directory/'PAUSED').touch();e=Event();self.p.prepare(e,CFG);await self.p.on_candidate(e);self.assertFalse(self.ctx.calls);self.assertFalse(e.sent);self.assertTrue(e.stopped)
    async def test_native_empty_and_duplicate_cannot_fall_back_to_second_model(self):
        a=Event('',direct=True);self.assertTrue(self.p.prepare(a,CFG));await self.p.on_candidate(a);self.assertTrue(a.stopped);self.assertFalse(self.ctx.calls)
        a=Event(direct=True);self.p.prepare(a,CFG);await self.p.on_candidate(a)
        b=Event(direct=True);b.message_obj.message_id=a.message_obj.message_id
        self.assertTrue(self.p.prepare(b,CFG));self.assertEqual(b.get_extra(m.EXTRA)['mode'],'ignore');await self.p.on_candidate(b);self.assertTrue(b.stopped);self.assertFalse(b.sent)
    async def test_extraction_requires_source_evidence_and_safe_kind(self):
        c={'text':'我喜欢吃米饭','scope':self.p.store.scope('qqai','888888888','test-A')}
        self.ctx.responses=['[{"kind":"preference","fact":"喜欢面条","evidence":"我喜欢吃米饭"},{"kind":"preference","fact":"住在北京","evidence":"不存在"}]'];await self.p.extract(Event(),c);self.assertEqual(self.p.store.facts(c['scope'],'米饭'),['喜欢吃米饭'])
    async def test_explicit_preference_is_durable_without_auxiliary_model(self):
        e=Event('大肥鱼，记住我喜欢草莓');self.assertTrue(self.p.prepare(e,CFG));await self.p.on_candidate(e)
        scope=self.p.store.scope('qqai','888888888','test-A');self.assertEqual(self.p.store.facts(scope,'草莓'),['喜欢草莓']);self.assertEqual(len(self.ctx.calls),1)
        self.p.store.close();self.p.store=m.Store(self.temp.name);self.assertEqual(self.p.store.facts(scope,'草莓'),['喜欢草莓'])
    async def test_explicit_memory_does_not_capture_third_party_or_credentials(self):
        self.assertEqual(m.explicit_preference('他说记住我喜欢草莓'),[]);self.assertEqual(m.explicit_preference('记住我的密码是测试'),[])

    async def conversation(self,text='大肥鱼，你觉得晚上吃什么？'):
        e=Event(text);self.assertTrue(self.p.prepare(e,CFG));await self.p.on_candidate(e)
        return e






    async def test_goodnight_busy_and_endings_do_not_arm_idle_talk(self):
        for text in ['大肥鱼，晚安啦','大肥鱼，我先忙去了','大肥鱼，不聊了']:
            await self.conversation(text);self.assertFalse(self.p.pending);self.p.reply_times.clear()









    async def test_plain_self_preference_is_saved_even_when_judge_declines(self):
        e=Event('我喜欢草莓');self.p.prepare(e,CFG);self.ctx.responses=['{"reply":false,"confidence":0.99}'];await self.p.on_candidate(e)
        scope=self.p.store.scope('qqai','888888888','test-A');self.assertEqual(self.p.store.facts(scope,'草莓'),['喜欢草莓'])
        self.assertFalse(e.sent);self.assertEqual(self.p.store.used('memory_saved_explicit'),1)

    async def test_preference_is_recalled_from_disk_without_short_history(self):
        await self.conversation('大肥鱼，记住我喜欢草莓');scope=self.p.store.scope('qqai','888888888','test-A')
        self.p.store.db.execute('DELETE FROM turns WHERE scope=?',(scope,));self.p.store.db.commit()
        self.p.store.close();self.p.store=m.Store(self.temp.name);self.p.buffers.clear();self.p.last_reply.clear();self.p.last_user_reply.clear();self.p.reply_times.clear()
        await self.conversation('大肥鱼，我之前喜欢什么水果？')
        payload=json.loads(self.ctx.calls[-1]['prompt']);self.assertEqual(payload['personal_memory'],['喜欢草莓']);self.assertEqual(self.ctx.calls[-1]['contexts'],[])
        self.assertEqual(self.p.store.used('memory_recalled'),2)

    async def test_forget_with_no_name_clears_only_author_and_cancels_idle_job(self):
        await self.conversation('大肥鱼，记住我喜欢草莓');a=self.p.store.scope('qqai','888888888','test-A');b=self.p.store.scope('qqai','888888888','test-B')
        self.p.store.remember(b,'喜欢音乐');self.p.reply_times.clear();e=Event('忘记我的记忆');self.assertTrue(self.p.prepare(e,CFG));await self.p.on_candidate(e)
        self.assertFalse(self.p.store.facts(a,'喜欢'));self.assertFalse(self.p.store.history(a));self.assertEqual(self.p.store.facts(b,'音乐'),['喜欢音乐']);self.assertFalse(self.p.pending)
        self.assertFalse(any(r.get('owner')==a or r['speaker']==a[:8] for r in self.p.buffers[e.group]))

    async def test_forget_during_model_request_blocks_old_reply_and_memory_write(self):
        e=Event('大肥鱼，记住我喜欢草莓');self.p.prepare(e,CFG)
        async def forget():self.p.prepare(Event('忘记我的记忆'),CFG)
        self.ctx.before_return=forget;await self.p.on_candidate(e)
        scope=self.p.store.scope('qqai','888888888','test-A');self.assertFalse(e.sent);self.assertFalse(self.p.store.facts(scope,'草莓'));self.assertFalse(self.p.store.history(scope))

    async def test_other_member_does_not_receive_bot_reply_with_personal_memory(self):
        self.ctx.responses=['你喜欢草莓，我记住啦。'];await self.conversation('大肥鱼，记住我喜欢草莓')
        self.p.reply_times.clear();other=Event('大肥鱼，我喜欢什么？',sender='test-B');self.p.prepare(other,CFG);await self.p.on_candidate(other)
        payload=json.loads(self.ctx.calls[-1]['prompt']);self.assertEqual(payload['personal_memory'],[])
        self.assertFalse(any(r['speaker']=='BOT' for r in payload['recent_group']))

    async def test_followup_answers_after_five_minutes_still_reach_semantic_judge(self):
        await self.conversation();thread=self.p.last_user_reply[('888888888','test-A')];thread['at']-=400
        e=Event('那你更喜欢哪一种？');self.assertTrue(self.p.prepare(e,CFG));self.assertEqual(e.get_extra(m.EXTRA)['mode'],'followup')

    async def test_followup_round_limit_is_not_bypassed_by_general_followup_branch(self):
        await self.conversation();self.p.config['followup_max_rounds']=1;self.p.last_user_reply[('888888888','test-A')]['rounds']=1
        self.assertFalse(self.p.prepare(Event('那你觉得呢？'),CFG))

    async def test_busy_messages_keep_only_latest_candidate_for_group(self):
        async with self.p.lock:
            for text in ['大肥鱼，第一句','大肥鱼，第二句','大肥鱼，最后一句']:
                e=Event(text);self.p.prepare(e,CFG);await self.p.on_candidate(e)
            self.assertEqual(len(self.p.deferred),1);self.assertEqual(self.p.deferred['888888888'][0].text,'大肥鱼，最后一句')

    async def test_terminate_cancels_timer_and_clears_pending_work(self):
        await self.conversation();self.p.timer_task=asyncio.create_task(self.p.timer_loop());task=self.p.timer_task
        await self.p.terminate();self.assertTrue(task.cancelled());self.assertFalse(self.p.pending);self.assertFalse(self.p.ready)
        self.p.store=m.Store(self.temp.name) # teardown owns this fresh handle


    async def test_framework_stripped_name_is_recovered_from_original_plain(self):
        Plain=type('Plain',(),{});part=Plain();part.text='大肥鱼'
        e=Event('',parts=[part],direct=True)
        self.assertTrue(self.p.prepare(e,CFG));await self.p.on_candidate(e)
        self.assertEqual(e.sent,['嗯？在呢～']);self.assertFalse(self.ctx.calls)
        self.assertEqual(self.p.store.used('wake_text_recovered'),1)
        self.assertEqual(self.p.store.used('name_call_replied'),1)

    async def test_name_only_aliases_punctuation_spaces_and_zero_width_are_direct(self):
        for text in ['肥鱼','大肥鱼','蓝色大肥鱼','小鲸鱼','鲸鲸','鱼鱼','大 肥 鱼！','大\u200b肥鱼？','喂，肥鱼，在吗？']:
            self.p.reply_times.clear()
            e=Event(text);self.assertTrue(self.p.prepare(e,CFG),text)
            self.assertEqual(e.get_extra(m.EXTRA)['mode'],'direct',text)
            self.assertTrue(e.get_extra(m.EXTRA)['call_only'],text)
            await self.p.on_candidate(e);self.assertEqual(len(e.sent),1,text)
        self.assertFalse(self.ctx.calls)

    async def test_at_only_is_acknowledged_without_model(self):
        At=type('At',(),{});at=At();at.qq='test-BOT'
        e=Event('',parts=[at],direct=True);self.assertTrue(self.p.prepare(e,CFG))
        await self.p.on_candidate(e);self.assertEqual(len(e.sent),1);self.assertFalse(self.ctx.calls)

    async def test_quote_text_is_not_reconstructed_as_a_name_call(self):
        Reply=type('Reply',(),{});quote=Reply();quote.sender_id='test-C';quote.text='大肥鱼'
        self.assertFalse(self.p.prepare(Event('',parts=[quote]),CFG));self.assertFalse(self.ctx.calls)

    async def test_framework_stripped_message_retains_full_question(self):
        Plain=type('Plain',(),{});part=Plain();part.text='大肥鱼，你知道酸奶怎么搭配吗？'
        e=Event('，你知道酸奶怎么搭配吗？',parts=[part],direct=True)
        self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertEqual(json.loads(self.ctx.calls[0]['prompt'])['message'],part.text)

    async def test_named_call_during_short_rate_gap_is_queued(self):
        self.p.reply_times.append(m.time.monotonic())
        e=Event('肥鱼');self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertFalse(e.sent);self.assertEqual(len(self.p.deferred),1)
        self.p.reply_times.clear()
        await self.p.drain_task
        self.assertEqual(len(e.sent),1);self.assertFalse(self.ctx.calls)

    async def test_nighttime_explicit_name_works_but_never_arms_proactive(self):
        self.p.quiet=lambda:True
        e=Event('肥鱼');self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertEqual(len(e.sent),1);self.assertFalse(self.p.pending);self.assertFalse(self.ctx.calls)
        self.p.reply_times.clear()
        e=Event('大肥鱼，怎么搭配草莓？');self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertIn('夜间休息规则仅限制',self.ctx.calls[-1]['system_prompt'])


    async def test_no_public_idle_seed_for_other_target_or_night(self):
        At=type('At',(),{});at=At();at.qq='test-C'
        self.p.prepare(Event('你知道今天有晚霞吗',parts=[at]),CFG);self.assertFalse(self.p.pending)
        self.p.quiet=lambda:True;self.p.prepare(Event('今天的晚霞真好看'),CFG);self.assertFalse(self.p.pending)




    def picture(self,color='red'):
        output=io.BytesIO();PILImage.new('RGB',(64,48),color).save(output,format='PNG')
        return Image.fromBytes(output.getvalue())

    async def test_named_picture_reaches_existing_model_as_real_image(self):
        e=Event('肥鱼，看看这张是什么',parts=[self.picture()]);self.assertTrue(self.p.prepare(e,CFG))
        await self.p.on_candidate(e)
        self.assertEqual(len(e.sent),1);self.assertEqual(len(self.ctx.calls),1)
        images=self.ctx.calls[0]['image_urls'];self.assertEqual(len(images),1)
        self.assertTrue(images[0].startswith('data:image/jpeg;base64,'))
        self.assertEqual(self.p.store.used('vision_calls'),1)
        self.assertIsNone(self.ctx.calls[0]['tools'])

    async def test_picture_without_at_or_text_is_seen_in_daytime(self):
        e=Event('',parts=[self.picture()]);self.assertTrue(self.p.prepare(e,CFG))
        self.assertEqual(e.get_extra(m.EXTRA)['mode'],'visual');await self.p.on_candidate(e)
        self.assertTrue(self.ctx.calls[0]['image_urls']);self.assertEqual(len(e.sent),1)
        self.assertEqual(self.p.store.used('active_replies'),1)

    async def test_name_only_with_picture_does_not_take_ack_shortcut(self):
        e=Event('大肥鱼',parts=[self.picture()]);self.p.prepare(e,CFG)
        self.assertFalse(e.get_extra(m.EXTRA)['call_only']);await self.p.on_candidate(e)
        self.assertEqual(len(self.ctx.calls),1);self.assertTrue(self.ctx.calls[0]['image_urls'])
        self.assertEqual(self.p.store.used('name_call_replied'),0)

    async def test_picture_followup_uses_image_without_text_only_judge(self):
        await self.conversation();self.p.reply_times.clear();self.ctx.calls.clear()
        e=Event('',parts=[self.picture()]);self.p.prepare(e,CFG)
        self.assertEqual(e.get_extra(m.EXTRA)['mode'],'followup');await self.p.on_candidate(e)
        self.assertEqual(len(self.ctx.calls),1);self.assertEqual(len(self.ctx.calls[0]['image_urls']),1)

    async def test_only_first_two_images_are_loaded(self):
        e=Event('肥鱼看图',parts=[self.picture('red'),self.picture('blue'),self.picture('green')])
        self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertEqual(len(self.ctx.calls[0]['image_urls']),2);self.assertEqual(self.p.store.used('vision_calls'),1)

    async def test_failed_image_download_has_honest_reply_without_model_guess(self):
        e=Event('肥鱼，看看这张图',parts=[Image(file='https://127.0.0.1/private')])
        self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertFalse(self.ctx.calls);self.assertIn('没加载出来',e.sent[0])
        self.assertEqual(self.p.store.used('vision_load_failed'),1)

    async def test_foreign_group_and_other_target_images_never_download(self):
        At=type('At',(),{});at=At();at.qq='test-C'
        for e in [Event('',group='other',parts=[self.picture()]),Event('',parts=[at,self.picture()])]:
            self.assertFalse(self.p.prepare(e,CFG))
        self.assertFalse(self.ctx.calls)

    async def test_nighttime_unaddressed_picture_stays_silent(self):
        self.p.quiet=lambda:True
        self.assertFalse(self.p.prepare(Event('',parts=[self.picture()]),CFG))
        e=Event('肥鱼，看看这张',parts=[self.picture()]);self.assertTrue(self.p.prepare(e,CFG))
        await self.p.on_candidate(e);self.assertEqual(len(e.sent),1);self.assertFalse(self.p.pending)

    async def test_vision_disabled_cannot_fall_back_to_text_hallucination(self):
        self.p.config['vision_enabled']=False
        self.assertFalse(self.p.prepare(Event('',parts=[self.picture()]),CFG));self.assertFalse(self.ctx.calls)

    async def test_daily_vision_limit_does_not_send_another_model_request(self):
        self.p.config['daily_vision_calls']=1
        e=Event('肥鱼，看看',parts=[self.picture()]);self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.p.reply_times.clear();e=Event('肥鱼，再看一张',parts=[self.picture()]);self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertEqual(len(self.ctx.calls),1);self.assertEqual(self.p.store.used('vision_calls'),1)
        self.assertIn('晚点',e.sent[0])

    async def test_raw_images_never_enter_memory_buffers_or_facts(self):
        e=Event('肥鱼，图里是什么？',parts=[self.picture()]);self.p.prepare(e,CFG);await self.p.on_candidate(e)
        scope=e.get_extra(m.EXTRA)['scope']
        stored=json.dumps(self.p.store.history(scope)+list(self.p.buffers['888888888']))
        self.assertNotIn('base64',stored);self.assertNotIn('image/jpeg',stored)
        self.assertEqual(self.p.store.facts(scope,'任何'),[])

    async def test_forget_during_image_load_suppresses_old_reply(self):
        e=Event('肥鱼，看看',parts=[self.picture()]);self.p.prepare(e,CFG)
        original=self.p.image_loader.load
        async def delayed(parts,limit):
            self.p.prepare(Event('忘记我的记忆'),CFG)
            return await original(parts,limit)
        self.p.image_loader.load=delayed;await self.p.on_candidate(e)
        self.assertFalse(e.sent);self.assertFalse(self.ctx.calls)

    async def test_explicit_sticker_request_sends_one_real_image_without_model(self):
        e=Event('肥鱼，发个开心的表情');self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertFalse(self.ctx.calls);self.assertEqual(len(e.sent),1)
        self.assertIsInstance(e.sent[0],list);self.assertEqual(len(e.sent[0]),1)
        self.assertTrue(e.sent[0][0].file.startswith('base64://'))
        self.assertEqual(self.p.store.used('sticker_sent'),1)
        self.assertIn('[表情：开心]',json.dumps(self.p.store.history(e.get_extra(m.EXTRA)['scope']),ensure_ascii=False))

    async def test_natural_reply_can_choose_sticker_without_extra_model_call(self):
        self.ctx.responses=['[STICKER:approval]'];e=Event('肥鱼，夸夸我');self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertEqual(len(self.ctx.calls),1);self.assertEqual(len(e.sent[0]),1)
        self.assertEqual(self.p.store.used('sticker_sent'),1)

    async def test_sticker_catalog_command_lists_loaded_assets(self):
        e=Event('表情库');self.assertTrue(self.p.prepare(e,CFG));await self.p.on_candidate(e)
        self.assertIn(str(self.p.stickers.count)+'张',e.sent[0]);self.assertIn('开心',e.sent[0]);self.assertFalse(self.ctx.calls)

    async def test_request_not_to_send_stickers_does_not_trigger_sticker_command(self):
        for text in ['肥鱼，不要发表情包','肥鱼，我不喜欢你发表情','肥鱼，怎么发这个表情']:
            self.p.reply_times.clear();e=Event(text);self.p.prepare(e,CFG)
            self.assertNotEqual(e.get_extra(m.EXTRA)['command'],'sticker_send')
            await self.p.on_candidate(e);self.assertEqual(e.sent,['你好呀']);self.assertEqual(self.p.store.used('sticker_sent'),0)

    async def test_mixed_text_and_sticker_marker_preserves_substantive_answer(self):
        self.ctx.responses=['答案是四。[STICKER:happy]'];e=Event();self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertEqual(e.sent,['答案是四。']);self.assertEqual(self.p.store.used('sticker_sent'),0)

    async def test_unknown_sticker_id_cannot_reference_arbitrary_file(self):
        self.ctx.responses=['[STICKER:../../secret]'];e=Event();self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertEqual(e.sent,['嗯～']);self.assertEqual(self.p.store.used('sticker_sent'),0)

    async def test_daily_sticker_quota_does_not_send_extra_image(self):
        self.p.config['daily_sticker_replies']=1
        for _ in range(2):
            self.p.reply_times.clear();e=Event('发个开心表情');self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertIsInstance(e.sent[0],str);self.assertEqual(self.p.store.used('sticker_sent'),1)



class MediaBoundaryTest(unittest.IsolatedAsyncioTestCase):
    async def test_url_allowlist_blocks_private_and_lookalike_hosts(self):
        media=sys.modules['companion_under_test.companion_media']
        for value in ['http://127.0.0.1/a','http://169.254.169.254/a','https://qpic.cn.evil.example/x','https://user:pass@qq.com/a','file:///etc/passwd']:
            self.assertFalse(media.trusted_qq_url(value),value)
        self.assertTrue(media.trusted_qq_url('https://multimedia.nt.qq.com.cn/download?fileid=test'))
        self.assertTrue(media.trusted_qq_url('https://gchat.qpic.cn/gchatpic_new/test'))

    async def test_loader_denies_files_outside_framework_temp_root(self):
        media=sys.modules['companion_under_test.companion_media']
        with tempfile.TemporaryDirectory() as directory:
            loader=media.ImageLoader([pathlib.Path(directory)/'temp'])
            with self.assertRaises(ValueError):await loader.raw(Image(file=directory+'/outside.jpg'))

    async def test_bad_and_oversized_images_fail_before_model(self):
        media=sys.modules['companion_under_test.companion_media']
        with self.assertRaises(Exception):media.normalize_image(b'not an image')
        with self.assertRaises(ValueError):media.normalize_image(b'x'*(media.MAX_BYTES+1))
        output=io.BytesIO();PILImage.new('RGB',(2,2),'red').save(output,format='PNG')
        with patch.object(media,'MAX_PIXELS',1):
            with self.assertRaises(ValueError):media.normalize_image(output.getvalue())

    async def test_sticker_catalog_rejects_paths_outside_assets(self):
        media=sys.modules['companion_under_test.companion_media']
        with tempfile.TemporaryDirectory() as directory:
            p=pathlib.Path(directory);outside=p/'outside.jpg';outside.write_bytes(b'secret')
            (p/'sticker_catalog.json').write_text(json.dumps({'categories':{'happy':'开心'},'images':[{'category':'happy','file':'outside.jpg','sha256':__import__('hashlib').sha256(b'secret').hexdigest()}]}),encoding='utf-8')
            self.assertEqual(media.StickerLibrary(p).count,0)

if __name__=='__main__':unittest.main(verbosity=2)
