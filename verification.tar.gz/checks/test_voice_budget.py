"""Persistent shared character quota and the authorized sender exemption."""
import asyncio
import json
import tempfile
import unittest
from unittest.mock import patch

import test_companion as tc
import test_voice as tv
import test_private as tp

m=tc.m


class CharacterStoreTest(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.s=m.Store(self.temp.name)
    def tearDown(self):self.s.close();self.temp.cleanup()
    def test_exact_daily_boundary_and_no_extra_attempt_on_rejection(self):
        self.assertTrue(self.s.reserve_voice_chars(1997,2000))
        self.assertTrue(self.s.reserve_voice_chars(3,2000))
        self.assertFalse(self.s.reserve_voice_chars(1,2000))
        self.assertEqual(self.s.used('tts_chars'),2000);self.assertEqual(self.s.used('tts_calls'),2)
    def test_character_budget_persists_across_reopen(self):
        self.s.reserve_voice_chars(1999,2000);self.s.close();self.s=m.Store(self.temp.name)
        self.assertFalse(self.s.reserve_voice_chars(2,2000));self.assertTrue(self.s.reserve_voice_chars(1,2000))
    def test_new_china_calendar_day_gets_new_budget(self):
        with patch.object(m,'day',return_value='2026-10-26'):self.s.reserve_voice_chars(2000,2000)
        with patch.object(m,'day',return_value='2026-10-27'):
            self.assertEqual(self.s.used('tts_chars'),0);self.assertTrue(self.s.reserve_voice_chars(2000,2000))
        with patch.object(m,'day',return_value='2026-10-26'):self.assertEqual(self.s.used('tts_chars'),2000)
    def test_legacy_attempt_count_never_limits_new_character_budget(self):
        self.s.db.execute('INSERT INTO counters VALUES(?,?,?)',(m.day(),'tts_calls',999));self.s.db.commit()
        self.assertTrue(self.s.reserve_voice_chars(20,2000));self.assertEqual(self.s.used('tts_calls'),1000)
        self.assertEqual(self.s.used('tts_chars'),20)
    def test_two_store_connections_cannot_exceed_shared_limit(self):
        second=m.Store(self.temp.name)
        try:
            self.assertTrue(self.s.reserve_voice_chars(1500,2000));self.assertFalse(second.reserve_voice_chars(501,2000))
            self.assertTrue(second.reserve_voice_chars(500,2000));self.assertFalse(self.s.reserve_voice_chars(1,2000))
        finally:second.close()
    def test_exempt_use_does_not_drain_others_or_depend_on_their_balance(self):
        self.s.reserve_voice_chars(2000,2000)
        for _ in range(25):self.assertTrue(self.s.reserve_voice_chars(100,2000,unlimited=True))
        self.assertEqual(self.s.used('tts_chars'),2000);self.assertEqual(self.s.used('tts_unlimited_chars'),2500)
        self.assertEqual(self.s.used('tts_calls'),26)
    def test_invalid_or_empty_reservation_consumes_nothing(self):
        for amount in [0,-1,True,None,'10',2001]:self.assertFalse(self.s.reserve_voice_chars(amount,2000))
        self.assertEqual(self.s.used('tts_chars'),0);self.assertEqual(self.s.used('tts_calls'),0)


class RequestRecognitionTest(unittest.TestCase):
    def test_bare_request_and_polite_variants_are_explicit(self):
        for text in ['发语音','发语音吧','给我发语音','能不能发语音','来语音听听','请发语音！']:
            self.assertTrue(tv.v.voice_intent(text),text)
    def test_negation_and_mentions_of_sending_voice_are_not_requests(self):
        for text in ['不要发语音','别发语音','能不能别发语音','我发语音给你','他发语音了','这是发语音教程']:
            self.assertFalse(tv.v.voice_intent(text),text)


class CharacterVoicePolicy(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.ctx=tp.Context()
        self.cfg=json.loads((tc.ROOT/'plugin-config.json').read_text(encoding='utf-8'))
        self.p=m.Main(self.ctx,self.cfg);self.p.store=m.Store(self.temp.name);self.p.ready=True;self.p.quiet=lambda:False
        self.cfg['voice_probability_percent']=0;self.cfg['voice_auto_enabled']=False
        self.provider=tv.Provider();self.p.edge_provider=self.provider;self.p.edge_provider_attempted=True
        self.ctx.rows.append({'user_id':20003})
        self.p.private_access=tp.PrivateAccess(self.ctx,self.p.store,['888888888'])
        await self.p.private_access.maintain(force=True)
    async def asyncTearDown(self):await self.p.terminate();self.temp.cleanup()
    async def send(self,text='发语音',sender='20001',private=False):
        self.p.reply_times.clear()
        e=tp.PrivateEvent(text,sender=sender) if private else tc.Event(text,sender=sender)
        self.assertTrue(self.p.prepare(e,self.ctx.get_config(e.unified_msg_origin)))
        self.assertTrue(e.get_extra(m.EXTRA)['voice_requested']);await self.p.on_candidate(e);return e
    async def test_bare_request_bypasses_probability_auto_switch_and_cooldown(self):
        for _ in range(2):
            e=await self.send();self.assertIsInstance(e.sent[0][0],tv.Record)
        self.assertEqual(self.p.store.used('tts_chars'),6);self.assertEqual(len(self.provider.calls),2)
    async def test_group_and_private_use_same_budget(self):
        self.cfg['daily_voice_chars']=5
        e=await self.send();self.assertIsInstance(e.sent[0][0],tv.Record)
        e=await self.send(private=True);self.assertEqual(e.sent,['你好呀'])
        self.assertEqual(self.p.store.used('tts_chars'),3);self.assertEqual(len(self.provider.calls),1)
    async def test_failure_is_counted_by_submitted_characters(self):
        self.provider.raw=RuntimeError('synthetic failure');e=await self.send()
        self.assertEqual(e.sent,['你好呀']);self.assertEqual(self.p.store.used('tts_chars'),3)
    async def test_exempt_account_gets_voice_with_exhausted_common_budget(self):
        self.p.store.reserve_voice_chars(2000,2000)
        for private in [False,True]:
            e=await self.send(sender='20003',private=private);self.assertIsInstance(e.sent[0][0],tv.Record)
        self.assertEqual(self.p.store.used('tts_chars'),2000);self.assertEqual(self.p.store.used('tts_unlimited_chars'),6)
    async def test_mentioning_exempt_number_does_not_grant_exemption(self):
        self.p.store.reserve_voice_chars(2000,2000)
        e=await self.send('20003 请用语音回复我')
        self.assertEqual(e.sent,['你好呀']);self.assertFalse(self.provider.calls)
    async def test_exemption_does_not_allow_nonmember_private_access(self):
        self.ctx.rows=[{'user_id':20001}];await self.p.private_access.maintain(force=True)
        e=tp.PrivateEvent('发语音',sender='20003')
        self.assertFalse(self.p.prepare(e,self.ctx.get_config(e.unified_msg_origin)))
        await self.p.on_candidate(e);self.assertFalse(self.provider.calls);self.assertFalse(e.sent)
    async def test_status_reports_shared_budget_and_separate_exempt_usage(self):
        await self.send();await self.send(sender='20003');self.p.write_status()
        status=json.loads((self.p.store.directory/'status.json').read_text(encoding='utf-8'))
        self.assertEqual(status['daily_voice_chars'],2000);self.assertEqual(status['voice_chars_used'],3)
        self.assertEqual(status['voice_chars_remaining'],1997);self.assertEqual(status['voice_unlimited_chars_used'],3)
        self.assertEqual(status['voice_unlimited_user_count'],1)
        self.assertIn('不要沿用历史中',await self.p.reply_system(tc.Event()))
