"""Private replies for current members of the one authorized QQ group."""
from __future__ import annotations

import asyncio
import copy
import fnmatch
import json
import re
import time

ROUTE = 'qqai:FriendMessage:*'
META = 'qqai_private_profile_v170'


class PrivateAccess:
    """A separate, fallback-disabled profile plus a fail-closed membership gate."""
    def __init__(self, context, store, groups):
        self.context = context
        self.store = store
        self.groups = tuple(map(str, groups))
        self.members = frozenset()
        self.checked_at = 0.0
        self.attempted_at = 0.0
        self.profile_id = ''
        self.profile_ready = False
        self.pipeline_seen = False
        self.error_type = ''
        self.lock = asyncio.Lock()

    @property
    def ready(self):
        if not (self.profile_ready and self.members and time.monotonic()-self.checked_at < 90):
            return False
        try:
            manager=self.context.astrbot_config_mgr
            sample='qqai:FriendMessage:'+next(iter(self.members))
            return (self.profile_safe(manager.confs[self.profile_id])
                    and manager.ucr.get_conf_id_for_umop(sample)==self.profile_id)
        except Exception:
            return False

    def permits(self, event):
        if not self.ready or str(event.get_sender_id()) not in self.members:
            return False
        try:
            manager = self.context.astrbot_config_mgr
            if manager.get_conf_info(event.unified_msg_origin)['id'] != self.profile_id:
                return False
            return self.profile_safe(self.context.get_config(event.unified_msg_origin))
        except Exception:
            return False

    def note_pipeline(self, event):
        try:
            if self.context.astrbot_config_mgr.get_conf_info(event.unified_msg_origin)['id']==self.profile_id:
                self.pipeline_seen=True
        except Exception:
            pass

    @staticmethod
    def profile_safe(config):
        settings = config.get('platform_settings', {})
        return (config.get('plugin_set') == ['qqai_companion']
                and config.get('disable_builtin_commands') is True
                and config.get('provider_settings', {}).get('enable') is False
                and settings.get('enable_id_white_list') is False
                and not settings.get('wl_ignore_admin_on_group')
                and not settings.get('wl_ignore_admin_on_friend')
                and settings.get('friend_message_needs_wake_prefix') is False)

    async def refresh_members(self):
        # No API calls from sync event filters; one bounded refresh in the timer.
        platform = self.context.get_platform_inst('qqai')
        if platform is None or platform.meta().name != 'aiocqhttp' or len(self.groups)!=1 or not re.fullmatch(r'[1-9][0-9]{3,19}',self.groups[0]):
            raise ValueError('Unexpected private authorization group or platform')
        rows = await asyncio.wait_for(platform.bot.get_group_member_list(
            group_id=int(self.groups[0]), no_cache=True), timeout=5)
        if not isinstance(rows, list) or not 1 <= len(rows) <= 2000:
            raise ValueError('Invalid group member list')
        members = set()
        for row in rows:
            member = str(row.get('user_id', '')) if isinstance(row, dict) else ''
            if not re.fullmatch(r'[1-9][0-9]{3,19}', member):
                raise ValueError('Invalid member identifier')
            members.add(member)
        self.members = frozenset(members)
        self.checked_at = time.monotonic()

    async def provision(self):
        manager = self.context.astrbot_config_mgr
        router = manager.ucr
        saved = self.store.db.execute('SELECT value FROM meta WHERE key=?', (META,)).fetchone()
        owned = json.loads(saved[0]) if saved else {}
        profile_id = owned.get('id', '')
        if profile_id and profile_id not in manager.confs:
            raise RuntimeError('Owned private profile is missing')
        # Never replace another custom private configuration.
        for route, target in router.umop_to_conf_id.items():
            parts = route.split(':', 2)
            if len(parts) != 3:
                raise ValueError('Invalid existing route')
            if ((not parts[0] or fnmatch.fnmatchcase('qqai', parts[0]))
                    and (not parts[1] or fnmatch.fnmatchcase('FriendMessage', parts[1]))
                    and target not in ('default', profile_id)):
                raise RuntimeError('A different private profile already exists')
        if not profile_id:
            config = copy.deepcopy(dict(self.context.get_config()))
            config['plugin_set'] = ['qqai_companion']
            config['disable_builtin_commands'] = True
            config['provider_settings']['enable'] = False
            config['platform_settings'].update(enable_id_white_list=False,
                wl_ignore_admin_on_group=False, wl_ignore_admin_on_friend=False,
                friend_message_needs_wake_prefix=False)
            profile_id = await manager.create_conf(config, name='小鲸鱼私聊_仅授权群成员')
            self.store.db.execute('INSERT INTO meta(key,value) VALUES(?,?)',
                                  (META, json.dumps({'id': profile_id, 'group': self.groups[0]})))
            self.store.db.commit()
        if not self.profile_safe(manager.confs[profile_id]):
            raise ValueError('Private profile safety settings changed')
        # Put the specific private route ahead of an existing generic default route.
        routing = {ROUTE: profile_id}
        routing.update({key: value for key, value in router.umop_to_conf_id.items() if key != ROUTE})
        if list(router.umop_to_conf_id.items()) != list(routing.items()):
            await router.update_routing_data(routing)
        self.profile_id = profile_id
        self.profile_ready = True

    async def maintain(self, *, force=False):
        if self.lock.locked() or (not force and time.monotonic()-self.attempted_at < 60):
            return
        async with self.lock:
            self.attempted_at = time.monotonic()
            try:
                await self.refresh_members()
                if not self.profile_ready:
                    await self.provision()
                self.error_type = ''
            except asyncio.CancelledError:
                raise
            except Exception as error:
                self.members = frozenset()
                self.checked_at = 0.0
                self.error_type = type(error).__name__

    def status(self):
        return {'private_ready': self.ready and self.pipeline_seen,
                'private_access_ready': self.ready, 'private_pipeline_seen': self.pipeline_seen,
                'private_policy': 'group_members',
                'private_member_count': len(self.members), 'private_profile_id': self.profile_id,
                'private_membership_age_sec': round(time.monotonic()-self.checked_at, 1) if self.checked_at else None,
                'private_error_type': self.error_type}
