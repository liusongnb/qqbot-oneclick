"""Virtual-day tests: no waiting for real random times, network, or QQ sends."""
import asyncio
from datetime import datetime,timedelta
import json
import random
import tempfile
import types
import unittest
from unittest.mock import patch
from test_companion import m, Context, Event, CFG, ROOT
from test_network import FakeNetwork
from companion_under_test.companion_schedule import DailySchedule,TOPICS,BJT

class ScheduleTest(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.store=m.Store(self.temp.name)
        self.now=datetime(2026,10,25,8,0,tzinfo=BJT).timestamp()
        self.schedule=DailySchedule(self.store.db,clock=lambda:self.now,rng=random.Random(27))
    def tearDown(self):self.store.close();self.temp.cleanup()
    def test_random_one_or_two_slots_only_in_daylight_and_spaced_three_hours(self):
        counts=set();times=set()
        for i in range(40):
            self.now=datetime(2026,10,25,8,0,tzinfo=BJT).timestamp()+i*86400
            plan=self.schedule.plan('888888888');counts.add(plan['goal'])
            self.assertIn(len(plan['slots']),(1,2))
            for slot in plan['slots']:
                hour=datetime.fromtimestamp(slot['at'],BJT).hour
                self.assertGreaterEqual(hour,9);self.assertLess(hour,22);times.add(round(slot['at']%86400))
            if len(plan['slots'])==2:self.assertGreaterEqual(plan['slots'][1]['at']-plan['slots'][0]['at'],10800)
        self.assertEqual(counts,{1,2});self.assertGreater(len(times),20)
    def test_restart_reuses_exact_plan_and_claim_is_not_replayed(self):
        plan=self.schedule.plan('888888888',2,2);self.now=plan['slots'][0]['at']+1
        self.assertIsNotNone(self.schedule.claim('888888888',plan))
        old=plan;self.store.close();self.store=m.Store(self.temp.name)
        self.schedule=DailySchedule(self.store.db,clock=lambda:self.now,rng=random.Random(999))
        plan=self.schedule.plan('888888888',2,2)
        self.assertEqual(plan,old);self.assertIsNone(self.schedule.claim('888888888',plan))
        self.now=plan['slots'][1]['at']+1;self.assertIsNotNone(self.schedule.claim('888888888',plan))
        self.assertIsNone(self.schedule.claim('888888888',plan))
    def test_existing_nine_openings_disable_rest_of_today(self):
        plan=self.schedule.plan('888888888',already_sent=9)
        self.assertEqual(plan['slots'],[]);self.assertIsNone(self.schedule.claim('888888888',plan,already_sent=9))
    def test_day_rollover_resets_goal_and_previous_day_not_replayed(self):
        first=self.schedule.plan('888888888');self.now+=86400
        second=self.schedule.plan('888888888')
        self.assertNotEqual(first['day'],second['day'])
        self.assertTrue(all(v['at']>self.now for v in second['slots']))
    def test_old_missed_slots_expire_without_burst_catchup(self):
        plan=self.schedule.plan('888888888',1,1);self.now=plan['slots'][0]['at']+3601
        self.assertIsNone(self.schedule.claim('888888888',plan));self.assertEqual(plan['slots'][0]['state'],'expired')
    def test_runtime_reduction_and_large_config_cannot_exceed_two(self):
        plan=self.schedule.plan('888888888',1,999)
        self.assertLessEqual(plan['goal'],2)
        self.now=plan['slots'][0]['at']+1
        self.assertIsNone(self.schedule.claim('888888888',plan,already_sent=1,maximum=1))
    def test_recent_topics_are_avoided_and_similar_openings_rejected(self):
        for topic in list(TOPICS)[:8]:self.schedule.remember_opening('888888888',topic,'刚想到一只小鲸鱼也会喜欢看天上的星星。')
        plan=self.schedule.plan('888888888',2,2)
        self.assertFalse({s['topic'] for s in plan['slots']} & set(list(TOPICS)[:8]))
        self.assertTrue(self.schedule.repetitive('888888888','刚想到，一只小鲸鱼也会喜欢看天上的星星！'))
        self.assertFalse(self.schedule.repetitive('888888888','游戏里藏的机关真是有意思呀。'))
    def test_late_install_never_immediately_posts_or_catches_up(self):
        self.now=datetime(2026,10,25,21,55,tzinfo=BJT).timestamp()
        plan=self.schedule.plan('888888888',2,2)
        self.assertEqual(plan['slots'],[])

class DailyOpeningTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        asyncio.get_running_loop().slow_callback_duration=1
        self.temp=tempfile.TemporaryDirectory();self.ctx=Context()
        self.p=m.Main(self.ctx,json.loads((ROOT/'plugin-config.json').read_text(encoding='utf-8')))
        self.p.store=m.Store(self.temp.name);self.p.ready=True;self.p.quiet=lambda:False;self.p.web=FakeNetwork()
        self.p.opening_window=lambda:True
        self.p.config.update(proactive_daily_min=2,proactive_daily_max=2)
    async def asyncTearDown(self):await self.p.terminate();self.temp.cleanup()
    def due(self,kind='casual',index=0):
        schedule=self.p.daily_scheduler();plan=self.p.opening_plan('888888888')
        # A controlled synthetic plan avoids depending on local test execution hour.
        if len(plan['slots'])<2:
            plan['goal']=2;plan['slots']=[{'at':m.time.time()+3600*i+1,'topic':list(TOPICS)[i],'kind':'casual','state':'pending'} for i in range(2)]
        plan['slots'][index]['at']=m.time.time()-1;plan['slots'][index]['kind']=kind
        schedule.write('daily_opening_plan:888888888',plan)
        self.p.reply_times.clear();return plan
    async def test_no_personal_memory_or_history_and_no_chained_followup(self):
        scope=self.p.store.scope('qqai','888888888','test-A')
        self.p.store.remember(scope,'喜欢草莓');self.p.store.add_turn(scope,'草莓','喜欢草莓就吃草莓。')
        self.p.memory_for=lambda c:(_ for _ in ()).throw(AssertionError('must not retrieve personal facts'))
        self.ctx.responses=['突然想到，游戏里的隐藏机关有时候比主线还让人惦记。']
        self.due();await self.p.proactive_tick()
        self.assertEqual(len(self.ctx.sent),1);self.assertEqual(self.p.store.used('proactive_sent'),1)
        payload=json.loads(self.ctx.calls[0]['prompt']);self.assertNotIn('草莓',self.ctx.calls[0]['prompt'])
        self.assertNotIn('personal_memory',payload);self.assertEqual(self.ctx.calls[0]['contexts'],[])
        self.assertFalse(self.p.pending);self.p.reply_times.clear();await self.p.proactive_tick()
        self.assertEqual(len(self.ctx.sent),1)
    async def test_web_opening_uses_fixed_public_query_and_verified_source(self):
        self.ctx.responses=['刚查到一个有趣的公开小知识，原来动物也藏着不少小聪明。']
        plan=self.due('web');await self.p.proactive_tick()
        self.assertEqual(self.p.web.calls,[('search',TOPICS[plan['slots'][0]['topic']][1])])
        self.assertEqual(len(self.ctx.sent),1);self.assertIn('https://example.com/public',self.ctx.sent[0][1])
        self.assertEqual(json.loads(self.ctx.calls[0]['prompt'])['verified_web_sources'],self.p.web.sources)
        self.assertEqual(self.p.store.used('web_requests'),1);self.assertEqual(self.p.store.used('proactive_web_searches'),1)
    async def test_search_failure_falls_back_without_pretending_to_have_sources(self):
        self.p.web.fail=True;self.ctx.responses=['今天忽然想给平平无奇的东西取个很厉害的名字。']
        self.due('web');await self.p.proactive_tick()
        self.assertEqual(len(self.ctx.sent),1);self.assertNotIn('来源',self.ctx.sent[0][1])
        self.assertEqual(json.loads(self.ctx.calls[0]['prompt'])['verified_web_sources'],[])
        self.assertEqual(self.p.backoff,0)
    async def test_two_daily_sends_then_no_more_even_after_reload(self):
        self.ctx.responses=['有些游戏小机关还挺会藏的。','突然想给平平无奇的东西取个厉害的名字。']
        self.due();await self.p.proactive_tick();self.due(index=1);await self.p.proactive_tick()
        self.assertEqual(len(self.ctx.sent),2)
        self.p.scheduler=None;self.p.reply_times.clear();await self.p.proactive_tick()
        self.assertEqual(len(self.ctx.sent),2);self.assertEqual(len(self.ctx.calls),2)
    async def test_previous_version_nine_messages_prevent_even_lookup(self):
        for _ in range(9):self.p.store.consume('proactive_sent',1000000)
        await self.p.proactive_tick();self.assertFalse(self.ctx.calls);self.assertFalse(self.p.web.calls)
        self.assertIsNone(self.p.opening_status()['next_due_at'])
    async def test_busy_group_waits_without_spending_slot(self):
        plan=self.due();self.p.prepare(Event('普通成员的新消息',sender='test-C'),CFG)
        await self.p.proactive_tick();self.assertFalse(self.ctx.calls);self.assertFalse(self.ctx.sent)
        self.assertEqual(self.p.daily_scheduler().plan('888888888')['slots'][0]['state'],'pending')
        self.p.last_group_activity['888888888']-=301;await self.p.proactive_tick()
        self.assertEqual(len(self.ctx.sent),1)
    async def test_message_during_generation_cancels_claimed_slot_without_retry(self):
        self.due();self.ctx.responses=['这条旧草稿不应该发出去。']
        async def incoming():self.p.prepare(Event('普通群友刚发的消息',sender='test-C'),CFG)
        self.ctx.before_return=incoming;await self.p.proactive_tick()
        self.assertFalse(self.ctx.sent);self.assertEqual(self.p.store.used('proactive_draft_cancelled'),1)
        self.p.last_group_activity['888888888']-=301;await self.p.proactive_tick()
        self.assertEqual(len(self.ctx.calls),1)
    async def test_failed_send_or_skip_never_replays_same_slot(self):
        for index,(answer,send_ok) in enumerate([('随口说一句新鲜小脑洞。',False),('[SKIP]',True)]):
            self.due(index=index);self.ctx.responses=[answer];self.ctx.send_ok=send_ok
            before=len(self.ctx.calls);await self.p.proactive_tick();self.p.reply_times.clear();await self.p.proactive_tick()
            self.assertEqual(len(self.ctx.calls),before+1)
        self.assertFalse(self.ctx.sent)
    async def test_no_work_if_disabled_paused_quiet_unlisted_or_platform_missing(self):
        for state in ['disabled','paused','quiet','unlisted','platform']:
            self.due();self.p.config['enabled']=True;self.p.quiet=lambda:False
            self.ctx.cfg=json.loads(json.dumps(CFG));self.ctx.get_platform_inst=lambda pid:types.SimpleNamespace(meta=lambda:types.SimpleNamespace(name='aiocqhttp'))
            marker=self.p.store.directory/'PAUSED';marker.unlink(missing_ok=True)
            if state=='disabled':self.p.config['enabled']=False
            elif state=='paused':marker.touch()
            elif state=='quiet':self.p.quiet=lambda:True
            elif state=='unlisted':self.ctx.cfg['platform_settings']['id_whitelist']=[]
            else:self.ctx.get_platform_inst=lambda pid:None
            await self.p.proactive_tick()
        self.assertFalse(self.ctx.calls);self.assertFalse(self.p.web.calls);self.assertFalse(self.ctx.sent)
    async def test_budget_exhausted_or_busy_model_does_not_spend_slot(self):
        self.due()
        async with self.p.lock:await self.p.proactive_tick()
        self.p.config['daily_llm_calls']=1;self.p.store.consume('llm_calls',1)
        await self.p.proactive_tick();self.assertFalse(self.ctx.calls)
        self.assertEqual(self.p.opening_plan('888888888')['slots'][0]['state'],'pending')
    async def test_repeat_draft_rejected_without_second_generation(self):
        self.p.daily_scheduler().remember_opening('888888888','animal','这个游戏的小机关居然藏在起点旁边，真会藏呀。')
        self.ctx.responses=['这个游戏的小机关居然藏在起点旁边，真会藏呀！']
        self.due();await self.p.proactive_tick();self.assertFalse(self.ctx.sent)
        self.assertEqual(len(self.ctx.calls),1);self.assertEqual(self.p.store.used('proactive_repeated_draft'),1)
    async def test_regular_named_chat_works_after_daily_opening_quota(self):
        for _ in range(2):self.p.store.consume('proactive_sent',1000000)
        e=Event('肥鱼，你在干什么？');self.p.prepare(e,CFG);await self.p.on_candidate(e)
        self.assertEqual(e.sent,['你好呀']);self.assertFalse(self.p.pending)
    async def test_replies_to_public_opening_can_continue_without_name(self):
        self.ctx.responses=['有些游戏的小机关比主线还让人惦记。'];self.due();await self.p.proactive_tick()
        self.p.reply_times.clear();e=Event('是啊，有时候就想把每个角落都翻完')
        self.assertTrue(self.p.prepare(e,CFG));self.assertEqual(e.get_extra(m.EXTRA)['mode'],'followup')
        self.ctx.responses=['{"reply":true,"confidence":0.98}','我也会想知道角落里到底藏了什么～']
        await self.p.on_candidate(e);self.assertEqual(len(e.sent),1)
        self.assertIn('有些游戏的小机关',self.ctx.calls[-1]['prompt'])
    async def test_status_and_scheduler_metadata_contain_no_member_or_personal_memory(self):
        self.due();self.p.write_status();raw=(self.p.store.directory/'status.json').read_text()
        status=json.loads(raw);self.assertEqual(status['proactive_mode'],'random_daily')
        self.assertIn(status['proactive_daily_limit'],(1,2));self.assertNotIn('test-A',raw)
        self.assertFalse(status['unsolicited_interjections_enabled'])
    async def test_unrelated_preference_not_injected_and_explicit_recall_preserved(self):
        scope=self.p.store.scope('qqai','888888888','test-A');self.p.store.remember(scope,'喜欢草莓')
        for query,expected in [('肥鱼，今天天气挺舒服的',[]),('肥鱼，你喜欢什么？',[]),
                               ('肥鱼，草莓怎么搭配？',['喜欢草莓']),('肥鱼，我之前喜欢什么水果？',['喜欢草莓'])]:
            self.p.reply_times.clear();e=Event(query);self.p.prepare(e,CFG);await self.p.on_candidate(e)
            self.assertEqual(json.loads(self.ctx.calls[-1]['prompt'])['personal_memory'],expected)
        self.assertEqual(self.p.store.facts(scope,'你喜欢什么游戏'),[])
