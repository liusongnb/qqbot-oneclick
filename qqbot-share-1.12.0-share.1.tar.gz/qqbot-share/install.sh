#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
SOURCE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
TARGET=/opt/qqbot-share
ANSWERS=''
PREPARE_ONLY=0
while (($#)); do
  case "$1" in
    --answers-file) ANSWERS=${2:?Missing answers file}; shift 2 ;;
    --prepare-only) PREPARE_ONLY=1; shift ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done
fail() { echo "$*" >&2; exit 1; }
[[ $(uname -s) == Linux && $(uname -m) == x86_64 ]] || fail 'Only Linux amd64 is supported.'
[[ $EUID == 0 ]] || fail 'Run this installer with sudo bash install.sh.'
[[ ! -e $TARGET && ! -L $TARGET ]] || fail "$TARGET already exists; nothing was overwritten."
[[ ! -d /opt/qq-ai && ! -e /opt/qq-ai/compose.yaml ]] || fail 'An existing QQAI installation was detected; use another server.'
[[ ! -e /usr/local/bin/qqbotctl ]] || fail 'qqbotctl already exists; nothing was overwritten.'
source /etc/os-release
[[ $ID == ubuntu || $ID == debian ]] || fail 'This version supports Ubuntu/Debian only.'
[[ -n ${VERSION_CODENAME:-} ]] || fail 'OS codename is required.'
if [[ $ID == ubuntu ]]; then
  [[ $VERSION_ID == 22.04 || $VERSION_ID == 24.04 ]] || fail 'Supported Ubuntu versions: 22.04, 24.04.'
else
  [[ $VERSION_ID == 12 || $VERSION_ID == 13 ]] || fail 'Supported Debian versions: 12, 13.'
fi
command -v ss >/dev/null || fail 'Please install iproute2 first.'
for port in 16185 6099; do
  [[ -z $(ss -H -ltn "sport = :$port") ]] || fail "Port $port is occupied; nothing was stopped."
done
available=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo)
(( available >= 1500000 )) || fail 'At least 1.5 GB available RAM is required; 4 GB total RAM is recommended.'
free_kb=$(df -Pk /opt | awk 'NR==2 {print $4}')
(( free_kb >= 8000000 )) || fail 'At least 8 GB free disk space is required.'
if command -v docker >/dev/null; then
  docker info >/dev/null 2>&1 || fail 'Existing Docker is unavailable; the installer will not restart it.'
  docker compose version >/dev/null 2>&1 || fail 'Existing Docker needs Compose v2; install it separately.'
  [[ -z $(docker ps -aq --filter label=com.docker.compose.project=qqbotshare) ]] || fail 'Compose project qqbotshare already exists.'
else
  # Never replace an existing container runtime or upgrade somebody else's engine.
  if dpkg-query -W -f='${db:Status-Abbrev}\n' docker.io docker-ce containerd containerd.io runc 2>/dev/null | grep -q '^ii'; then
    fail 'An existing container runtime was found; configure Docker/Compose separately.'
  fi
  [[ ! -e /etc/apt/sources.list.d/docker.sources && ! -e /etc/apt/sources.list.d/docker.list ]] || fail 'A Docker apt source already exists; configure it separately.'
  apt-get update -qq
  apt-get install -y ca-certificates curl python3
  install -m 0755 -d /etc/apt/keyrings
  curl --fail --silent --show-error --location --proto '=https' "https://download.docker.com/linux/$ID/gpg" -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  printf 'Types: deb\nURIs: https://download.docker.com/linux/%s\nSuites: %s\nComponents: stable\nArchitectures: amd64\nSigned-By: /etc/apt/keyrings/docker.asc\n' "$ID" "$VERSION_CODENAME" > /etc/apt/sources.list.d/docker.sources
  apt-get update -qq
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  docker info >/dev/null || fail 'Docker is unavailable; inspect it before retrying.'
fi
command -v python3 >/dev/null || fail 'python3 is required.'
install -d -m 0700 "$TARGET"
cp -a "$SOURCE/." "$TARGET/"
chmod 0700 "$TARGET"
trap 'echo "Installation stopped. Files are retained in /opt/qqbot-share for review; existing services were not stopped." >&2' ERR
cd "$TARGET"
if [[ -n $ANSWERS ]]; then
  python3 scripts/configure.py --answers-file "$ANSWERS"
else
  python3 scripts/configure.py < /dev/tty
fi
docker compose config --quiet
if (( PREPARE_ONLY )); then
  echo 'Prepared only: no image pulled and no container started.'
  exit 0
fi
docker compose pull
docker compose run --rm --no-deps -T --entrypoint python astrbot /share-scripts/bootstrap.py
python3 - <<'PY'
import json
from pathlib import Path
p=Path('instance.json');v=json.loads(p.read_text());v['bootstrap_complete']=True;p.write_text(json.dumps(v,indent=2)+'\n')
PY
docker compose up -d --no-build
install -m 0755 scripts/qqbotctl /usr/local/bin/qqbotctl
python3 scripts/healthcheck.py --wait
echo 'Installed. Read the guide and run: sudo qqbotctl credentials'
echo 'AstrBot: http://127.0.0.1:16185/   NapCat: http://127.0.0.1:6099/webui/'
echo 'Remote access from your own PC: ssh -N -L 26185:127.0.0.1:16185 -L 26099:127.0.0.1:6099 USER@SERVER'
echo 'Then open http://127.0.0.1:26185/ and http://127.0.0.1:26099/webui/ and scan with your bot QQ.'
