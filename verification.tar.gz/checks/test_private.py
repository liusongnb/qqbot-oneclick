"""Private membership, routing, isolation and normal feature contracts."""
import asyncio
import copy
import fnmatch
import json
import tempfile
import time
import types
import unittest

import test_companion as tc
import test_voice as tv

m=tc.m
from companion_under_test.companion_private import PrivateAccess, ROUTE

class Router:
    def __init__(self):self.umop_to_conf_id={};self.writes=0
    def get_conf_id_for_umop(self,umo):
        for pattern,target in self.umop_to_conf_id.items():
            if all(not p or fnmatch.fnmatchcase(value,p) for p,value in zip(pattern.split(':',2),umo.split(':',2))):return target
        return None
    async def update_routing_data(self,routing):self.umop_to_conf_id=dict(routing);self.writes+=1

class Manager:
    def __init__(self):
        self.ucr=Router();self.created=0
        config=copy.deepcopy(tc.CFG);config.update(plugin_set=['qqai_companion'],provider_settings={'enable':True},disable_builtin_commands=False)
        self.confs={'default':config}
    def get_conf_info(self,umo):return {'id':self.ucr.get_conf_id_for_umop(umo) or 'default'}
    async def create_conf(self,config,name):
        self.created+=1;profile='synthetic-private-profile-'+str(self.created)
        self.confs[profile]=copy.deepcopy(config);return profile

class Context(tc.Context):
    def __init__(self):
        super().__init__();self.astrbot_config_mgr=Manager();self.rows=[{'user_id':20001},{'user_id':20002}]
        self.member_calls=0;self.member_error=False
        async def members(**kwargs):
            self.member_calls+=1
            if self.member_error:raise TimeoutError('Synthetic membership failure')
            return self.rows
        self.platform=types.SimpleNamespace(meta=lambda:types.SimpleNamespace(name='aiocqhttp'),bot=types.SimpleNamespace(get_group_member_list=members))
    def get_config(self,umo=None):
        key=self.astrbot_config_mgr.get_conf_info(umo)['id'] if umo else 'default'
        return self.astrbot_config_mgr.confs[key]
    def get_platform_inst(self,pid):return self.platform if pid=='qqai' else None

class PrivateEvent(tc.Event):
    def __init__(self,text='你好呀',sender='20001',**kwargs):
        super().__init__(text,group='',sender=sender,kind='friend',**kwargs)
        self.unified_msg_origin='qqai:FriendMessage:'+sender

class PrivateTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.ctx=Context()
        self.config=json.loads((tc.ROOT/'plugin-config.json').read_text(encoding='utf-8'))
        self.p=m.Main(self.ctx,self.config);self.p.store=m.Store(self.temp.name);self.p.ready=True;self.p.quiet=lambda:False
        self.p.config['voice_probability_percent']=0
        self.access=PrivateAccess(self.ctx,self.p.store,['888888888']);self.p.private_access=self.access
        await self.access.maintain(force=True)
    async def asyncTearDown(self):
        await self.p.terminate();self.temp.cleanup()
    async def send(self,text='你好呀',sender='20001'):
        event=PrivateEvent(text,sender);self.assertTrue(self.p.prepare(event,self.ctx.get_config(event.unified_msg_origin)))
        await self.p.on_candidate(event);return event
    async def test_plain_private_message_is_direct_without_alias_or_judge(self):
        event=await self.send();self.assertEqual(event.sent,['你好呀']);self.assertEqual(len(self.ctx.calls),1)
        self.assertEqual(event.get_extra(m.EXTRA)['mode'],'direct');self.assertTrue(event.stopped)
        self.assertTrue(self.access.status()['private_ready'])
    async def test_outsider_stops_before_buffer_memory_or_model(self):
        event=PrivateEvent(sender='29999');self.assertFalse(self.p.prepare(event,self.ctx.get_config(event.unified_msg_origin)))
        await self.p.on_candidate(event);self.assertTrue(event.stopped);self.assertFalse(event.sent);self.assertFalse(self.ctx.calls)
        self.assertFalse(self.p.buffers);self.assertFalse(self.p.private_sessions)
    async def test_stale_or_failed_membership_fails_closed(self):
        self.access.checked_at-=91;self.assertFalse(self.p.allowed(PrivateEvent()))
        self.ctx.member_error=True;await self.access.maintain(force=True)
        self.assertFalse(self.access.ready);self.assertFalse(self.access.members);self.assertFalse(self.p.allowed(PrivateEvent()))
    async def test_member_removal_takes_effect_without_reloading(self):
        self.ctx.rows=[{'user_id':20002}];await self.access.maintain(force=True)
        self.assertFalse(self.p.allowed(PrivateEvent(sender='20001')));self.assertTrue(self.p.allowed(PrivateEvent(sender='20002')))
    async def test_refresh_has_bounded_frequency(self):
        calls=self.ctx.member_calls;await self.access.maintain();await self.access.maintain()
        self.assertEqual(self.ctx.member_calls,calls)
    async def test_group_default_config_is_unchanged_and_private_fallback_disabled(self):
        default=self.ctx.astrbot_config_mgr.confs['default'];self.assertTrue(default['platform_settings']['enable_id_white_list'])
        self.assertEqual(default['platform_settings']['id_whitelist'],['888888888']);self.assertTrue(default['provider_settings']['enable'])
        private=self.ctx.get_config(PrivateEvent().unified_msg_origin);self.assertTrue(PrivateAccess.profile_safe(private))
        self.assertEqual(private['agent_runner'],default['agent_runner'])
        self.assertEqual(self.ctx.astrbot_config_mgr.get_conf_info('qqai:GroupMessage:888888888')['id'],'default')
    async def test_no_builtin_or_native_fallback_if_guard_settings_are_modified(self):
        profile=self.ctx.get_config(PrivateEvent().unified_msg_origin)
        profile['provider_settings']['enable']=True
        event=PrivateEvent();self.assertFalse(self.p.prepare(event,profile));self.assertTrue(event.stopped)
        self.assertFalse(self.ctx.calls)
    async def test_unrelated_routes_preserved_and_profile_not_duplicated_on_reload(self):
        manager=self.ctx.astrbot_config_mgr;manager.ucr.umop_to_conf_id['telegram:FriendMessage:*']='unrelated'
        replacement=PrivateAccess(self.ctx,self.p.store,['888888888']);await replacement.maintain(force=True)
        self.assertTrue(replacement.ready);self.assertEqual(manager.created,1)
        self.assertEqual(manager.ucr.umop_to_conf_id['telegram:FriendMessage:*'],'unrelated')
    async def test_conflicting_custom_private_route_is_not_replaced(self):
        manager=self.ctx.astrbot_config_mgr;manager.ucr.umop_to_conf_id[ROUTE]='other-private'
        replacement=PrivateAccess(self.ctx,self.p.store,['888888888']);await replacement.maintain(force=True)
        self.assertFalse(replacement.ready);self.assertEqual(manager.ucr.umop_to_conf_id[ROUTE],'other-private')
    async def test_other_groups_and_platforms_stay_denied(self):
        for event in [tc.Event(group='other'),PrivateEvent(platform='other'),tc.Event(kind='friend',group='888888888')]:
            self.assertFalse(self.p.allowed(event))
    async def test_disabling_shared_memory_keeps_private_preferences_separate(self):
        self.p.config['shared_memory_enabled']=False
        await self.send('记住我喜欢草莓')
        private=self.p.store.scope('qqai','private:20001','20001');group=self.p.store.scope('qqai','888888888','20001')
        other=self.p.store.scope('qqai','private:20002','20002')
        self.assertEqual(self.p.store.facts(private,'草莓'),['喜欢草莓']);self.assertFalse(self.p.store.facts(group,'草莓'))
        self.assertFalse(self.p.store.facts(other,'草莓'));self.assertFalse(self.p.store.history(group))
        self.p.store.remember(group,'喜欢蓝莓');self.p.reply_times.clear();self.ctx.calls.clear()
        await self.send('我喜欢什么莓？')
        payload=json.loads(self.ctx.calls[0]['prompt']);self.assertIn('喜欢草莓',payload['personal_memory'])
        self.assertNotIn('喜欢蓝莓',payload['personal_memory'])
    async def test_private_forget_only_clears_this_member_private_scope(self):
        self.p.config['shared_memory_enabled']=False
        private=self.p.store.scope('qqai','private:20001','20001');group=self.p.store.scope('qqai','888888888','20001')
        other=self.p.store.scope('qqai','private:20002','20002')
        for scope in [private,group,other]:self.p.store.remember(scope,'喜欢草莓')
        event=await self.send('忘记我的记忆');self.assertIn('这段私聊',event.sent[0])
        self.assertFalse(self.p.store.facts(private,'草莓'));self.assertTrue(self.p.store.facts(group,'草莓'));self.assertTrue(self.p.store.facts(other,'草莓'))
    async def test_per_member_private_limit_does_not_block_another_member(self):
        self.p.config['daily_private_replies_per_user']=1
        self.assertTrue((await self.send()).sent);self.p.reply_times.clear()
        self.ctx.calls.clear()
        self.assertFalse((await self.send('用语音说晚安')).sent);self.p.reply_times.clear()
        self.assertFalse(self.ctx.calls);self.assertEqual(self.p.store.used('tts_calls'),0)
        self.assertEqual(self.p.store.used('replies'),1)
        self.assertEqual(self.p.store.used('skip_private_quota'),1)
        self.assertTrue((await self.send(sender='20002')).sent)
    async def test_existing_global_budget_still_applies_to_private(self):
        self.p.config['daily_replies']=1;self.p.store.consume('replies',1)
        event=await self.send();self.assertFalse(event.sent);self.assertFalse(self.ctx.calls)
    async def test_private_voice_uses_existing_voice_limits(self):
        provider=tv.Provider();self.p.edge_provider=provider;self.p.edge_provider_attempted=True
        event=await self.send('用语音说晚安');self.assertIsInstance(event.sent[0][0],tv.Record)
        self.assertEqual(self.p.store.used('voice_sent'),1);self.assertEqual(self.p.store.used('private_sent'),1)
    async def test_private_persona_does_not_claim_a_group_conversation(self):
        system=await self.p.reply_system(PrivateEvent());self.assertIn('一对一私聊',system)
        self.assertNotIn('只在当前授权群发言',system);self.assertIn('不透露或编造其他成员的信息',system)
    async def test_member_revocation_during_model_call_cancels_send(self):
        async def revoke():self.access.members=frozenset()
        self.ctx.before_return=revoke;event=await self.send();self.assertFalse(event.sent)
    async def test_equal_private_message_ids_from_different_members_are_distinct(self):
        first=PrivateEvent(sender='20001');second=PrivateEvent(sender='20002')
        first.message_obj.message_id=second.message_obj.message_id='same-synthetic-id'
        self.assertTrue(self.p.prepare(first,self.ctx.get_config(first.unified_msg_origin)))
        self.assertTrue(self.p.prepare(second,self.ctx.get_config(second.unified_msg_origin)))
        self.assertEqual(second.get_extra(m.EXTRA)['mode'],'direct')
    async def test_runtime_private_conversation_limit_is_bounded(self):
        for number in range(33):
            sender=str(30000+number);self.access.members=self.access.members|{sender}
            event=PrivateEvent(sender=sender);self.assertTrue(self.p.prepare(event,self.ctx.get_config(event.unified_msg_origin)))
        self.assertEqual(len(self.p.private_sessions),32)
        self.assertEqual(event.get_extra(m.EXTRA)['mode'],'ignore')
        self.assertLessEqual(len(self.p.buffers),32)
    async def test_private_sessions_never_become_random_opening_targets(self):
        await self.send();self.p.opening_status()
        keys=[row[0] for row in self.p.store.db.execute("SELECT key FROM meta WHERE key LIKE 'daily_opening_plan:%'")]
        self.assertTrue(keys);self.assertTrue(all(key=='daily_opening_plan:888888888' for key in keys))
    async def test_unavailable_or_malformed_member_list_does_not_open_private(self):
        for rows in [[],[{'user_id':'not-an-id'}],[{'user_id':20001}]*2001]:
            self.ctx.rows=rows;await self.access.maintain(force=True);self.assertFalse(self.access.ready)
    async def test_disabling_private_config_takes_effect_immediately(self):
        self.p.config['private_enabled']=False;event=PrivateEvent()
        self.assertFalse(self.p.prepare(event,self.ctx.get_config(event.unified_msg_origin)));self.assertTrue(event.stopped)
