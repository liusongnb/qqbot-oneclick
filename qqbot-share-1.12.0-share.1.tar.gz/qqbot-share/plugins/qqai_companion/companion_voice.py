"""Bounded free Edge TTS, using the verified upstream library and system ffmpeg."""
from __future__ import annotations

import asyncio
import hashlib
import importlib
import io
from pathlib import Path
import random
import re
import sys
import time
import wave

EDGE_WHEEL = 'edge_tts-7.3.1-py3-none-any.whl'
EDGE_SHA256 = '2a3c79d6235a7a736d681233823ce5492e829b43eb47beae49aa181237a8f9a4'


def load_edge(directory):
    """Load a pinned pure-Python wheel without installing or updating packages."""
    wheel = Path(directory)/'vendor'/EDGE_WHEEL
    if wheel.is_symlink() or hashlib.sha256(wheel.read_bytes()).hexdigest() != EDGE_SHA256:
        raise ValueError('Edge TTS dependency checksum mismatch')
    if 'edge_tts' in sys.modules:
        module = sys.modules['edge_tts']
        if not str(getattr(module, '__file__', '')).replace('\\', '/').startswith(str(wheel).replace('\\', '/')+'/'):
            raise RuntimeError('Another Edge TTS version is already loaded')
        return module
    sys.path.insert(0, str(wheel))
    try:
        return importlib.import_module('edge_tts')
    finally:
        sys.path.remove(str(wheel))


class EdgeVoice:
    """Keep short MP3 and PCM audio in memory; no audio cache or model install."""
    def __init__(self, directory, voice='zh-CN-XiaoyiNeural'):
        if voice not in ('zh-CN-XiaoyiNeural', 'zh-CN-XiaoxiaoNeural'):
            raise ValueError('Unsupported voice')
        self.module = load_edge(directory)
        self.voice = voice

    async def get_audio(self, text):
        mp3 = bytearray()
        async def collect():
            speaker = self.module.Communicate(text, self.voice, rate='-5%', pitch='+2Hz',
                                             connect_timeout=5, receive_timeout=10)
            async for chunk in speaker.stream():
                if chunk['type'] == 'audio':
                    mp3.extend(chunk['data'])
                    if len(mp3) > 512*1024:
                        raise ValueError('Encoded audio exceeds limit')
        await asyncio.wait_for(collect(), timeout=20)
        if not mp3:
            raise ValueError('No speech audio returned')
        process = await asyncio.create_subprocess_exec(
            'ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error',
            '-i', 'pipe:0', '-t', '31', '-f', 's16le', '-acodec', 'pcm_s16le',
            '-ar', '24000', '-ac', '1', 'pipe:1',
            stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL)
        try:
            pcm, _ = await asyncio.wait_for(process.communicate(bytes(mp3)), timeout=8)
            if process.returncode != 0 or not pcm or len(pcm) % 2 or len(pcm) > 30*24000*2:
                raise ValueError('Invalid or overlong decoded speech')
            output = io.BytesIO()
            with wave.open(output, 'wb') as wav:
                wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(24000)
                wav.writeframes(pcm)
            return output.getvalue()
        finally:
            if process.returncode is None:
                process.kill()
                await process.wait()


def voice_intent(text):
    """Only explicit requests in the current, top-level user text."""
    text = str(text or '')
    text = re.sub(r'能不能|可不可以','可以',text)
    if re.search(r'(?:不|别|停止|禁止|不用|不要).{0,8}(?:语音|朗读)|(?:只|改用|用)文字', text):
        return False
    bare=re.fullmatch(r'(?:请|麻烦(?:你)?|帮我|给我|能不能|可以)?(?:发|来)语音(?:给我|听听|吧|呀|啦|啊|嘛|[。！!?？~～\s])*',text.strip())
    return bool(bare or re.search(r'(?:用|换成|改成|来段|来条|发条|发段|发个|来个|发一条|发一段).{0,3}语音|语音(?:说|回复|回答|一下|念|读)|(?:请|帮我|给我)朗读', text))


def speakable(text, maximum=100):
    text = str(text or '').strip()
    if not text or len(text) > maximum:
        return ''
    if re.search(r'https?://|www\.|```|\[[^\]]*\]|[{}<>]|(?:^|\n)\s*(?:[-*#]|\d+[.)])', text, re.I):
        return ''
    # Plain punctuation is harmless; do not send redacted or sensitive content to TTS.
    if re.search(r'隐私已隐藏|密码|密钥|令牌|身份证|手机号|api.?key|bearer\s|sk-[\w-]{12,}', text, re.I):
        return ''
    text = re.sub(r'[\U00010000-\U0010ffff\ufe0f\u200d]', '', text).strip()
    return text if re.search(r'[\w\u4e00-\u9fff]', text) else ''


class VoiceService:
    """One retained synthesis job, even after the caller times out or cancels.

    Shielding and retaining the task prevents a timeout or plugin reload from
    allowing a second overlapping request. All audio stays in bounded memory.
    """
    def __init__(self, *, timeout=20, max_bytes=3*1024**2, max_seconds=30, shared_state=None):
        self.timeout = timeout
        self.max_bytes = max_bytes
        self.max_seconds = max_seconds
        self.state = shared_state if shared_state is not None else {}
        self.state.setdefault('pending', None)
        self.state.setdefault('backoff_until', 0.0)
        self.state.setdefault('last_auto_at', None)
        self.closed = False

    @property
    def pending(self): return self.state['pending']
    @pending.setter
    def pending(self, value): self.state['pending'] = value
    @property
    def backoff_until(self): return self.state['backoff_until']
    @backoff_until.setter
    def backoff_until(self, value): self.state['backoff_until'] = value
    @property
    def last_auto_at(self): return self.state['last_auto_at']
    @last_auto_at.setter
    def last_auto_at(self, value): self.state['last_auto_at'] = value

    @property
    def busy(self):
        return self.pending is not None and not self.pending.done()

    def auto_due(self, probability, cooldown):
        now = time.monotonic()
        return (not self.closed and not self.busy and now >= self.backoff_until
                and (self.last_auto_at is None or now-self.last_auto_at >= cooldown)
                and random.random()*100 < probability)

    async def _synthesize(self, provider, text):
        raw = await provider.get_audio(text)
        if not isinstance(raw, bytes) or len(raw) > self.max_bytes:
            raise ValueError('Invalid or oversized TTS output')
        with wave.open(io.BytesIO(raw), 'rb') as audio:
            if (audio.getcomptype() != 'NONE' or audio.getnchannels() not in (1, 2)
                    or audio.getsampwidth() != 2 or not 8000 <= audio.getframerate() <= 48000
                    or not 0 < audio.getnframes()/audio.getframerate() <= self.max_seconds):
                raise ValueError('Unsupported or overlong TTS output')
            expected = audio.getnframes()*audio.getnchannels()*audio.getsampwidth()
            if len(audio.readframes(audio.getnframes())) != expected:
                raise ValueError('Truncated TTS audio')
        return raw

    def _finished(self, task):
        # Retrieve failures even when the original caller already timed out.
        if not task.cancelled() and task.exception() is not None:
            self.backoff_until = time.monotonic()+120
        if self.pending is task:
            self.pending = None

    async def synthesize(self, provider, text, reserve, *, automatic=False):
        if (self.closed or self.busy or time.monotonic() < self.backoff_until
                or not callable(getattr(provider, 'get_audio', None))):
            return None, 'unavailable'
        if not reserve():
            return None, 'quota'
        self.last_auto_at = time.monotonic()
        task = asyncio.create_task(self._synthesize(provider, text))
        self.pending = task
        task.add_done_callback(self._finished)
        try:
            return await asyncio.wait_for(asyncio.shield(task), self.timeout), 'ready'
        except asyncio.CancelledError:
            raise
        except asyncio.TimeoutError:
            self.backoff_until = time.monotonic()+120
            return None, 'timeout'
        except Exception:
            self.backoff_until = time.monotonic()+120
            return None, 'failed'

    def close(self):
        self.closed = True
        # A standalone bounded job never accesses a store after unloading.
