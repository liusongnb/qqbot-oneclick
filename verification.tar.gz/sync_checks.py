import json
import shutil
from pathlib import Path

root=Path(__file__).resolve().parent
package=root/'qqbot-share'
checks=root/'checks'
for name,source in [('astrbot_plugin_qqai_companion',package/'plugins/qqai_companion'),('plugins',package/'plugins')]:
    shutil.copytree(source,checks/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
p=checks/'test_companion.py'
s=p.read_text(encoding='utf-8').replace("if key!='proactive_enabled':", "if key not in {'proactive_enabled','allowed_groups','voice_unlimited_users','breeze_voice_id'}:")
p.write_text(s,encoding='utf-8')
p=checks/'test_reminders.py'
s=p.read_text(encoding='utf-8').replace("{'enabled':True,'max_reminders':20}","{'enabled':True,'max_reminders':20,'allowed_groups':['888888888']}")
p.write_text(s,encoding='utf-8')
