"""QQAI compatibility entrypoint for findx010197's reminder SQLite backend.

The upstream entrypoint is preserved in upstream_main.py. QQAI owns parsing,
authorization and dispatch; this plugin never starts a second sending timer.
"""
import calendar
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
import re
import time
import uuid

from astrbot.api.star import Star, StarTools
from .database import ScheduleDatabase, ScheduleItem

CST=timezone(timedelta(hours=8))


def next_occurrence(item, now):
    if item.recurrence_type=='none':return None
    previous=datetime.fromtimestamp(item.trigger_time,CST)
    anchor=json.loads(item.recurrence_value or '{}').get('day',previous.day)
    for _ in range(5000):
        if item.recurrence_type in ('daily','weekdays'):
            previous+=timedelta(days=1)
            while item.recurrence_type=='weekdays' and previous.weekday()>4:previous+=timedelta(days=1)
        elif item.recurrence_type=='weekly':previous+=timedelta(days=7)
        elif item.recurrence_type in ('monthly','yearly'):
            month=previous.month+(1 if item.recurrence_type=='monthly' else 12)
            year=previous.year+(month-1)//12;month=(month-1)%12+1
            previous=previous.replace(year=year,month=month,day=min(anchor,calendar.monthrange(year,month)[1]))
        else:return None
        if previous.timestamp()>now:return previous.timestamp()
    return None


class ManagedDatabase(ScheduleDatabase):
    def __init__(self,path):
        super().__init__(path)
        with self._get_cursor() as c:
            c.execute('CREATE TABLE IF NOT EXISTS qqai_requests (request_key TEXT PRIMARY KEY, schedule_id TEXT NOT NULL, stamp REAL NOT NULL)')
            c.execute('CREATE TABLE IF NOT EXISTS qqai_occurrences (schedule_id TEXT NOT NULL, due REAL NOT NULL, state TEXT NOT NULL, stamp REAL NOT NULL, PRIMARY KEY(schedule_id,due))')

    def create(self,*,session,sender,title,due,recurrence,request_key,limit):
        now=time.time()
        with self._get_cursor() as c:
            c.execute('BEGIN IMMEDIATE')
            saved=c.execute('SELECT schedule_id FROM qqai_requests WHERE request_key=?',(request_key,)).fetchone()
            if saved:return {'id':saved[0],'duplicate':True}
            row=c.execute("SELECT id FROM schedules WHERE sender_id=? AND unified_msg_origin=? AND status='pending' AND event_content=? AND recurrence_type=? AND abs(trigger_time-?)<=60",(sender,session,title,recurrence,due)).fetchone()
            if row:
                c.execute('INSERT INTO qqai_requests VALUES(?,?,?)',(request_key,row[0],now))
                return {'id':row[0],'duplicate':True}
            count=c.execute("SELECT count(*) FROM schedules WHERE sender_id=? AND status='pending'",(sender,)).fetchone()[0]
            if count>=limit:return {'error':'limit'}
            row=c.execute('SELECT counter FROM id_counters WHERE sender_id=?',(sender,)).fetchone()
            counter=(row[0] if row else 0)+1
            c.execute('INSERT INTO id_counters VALUES(?,?) ON CONFLICT(sender_id) DO UPDATE SET counter=excluded.counter',(sender,counter))
            identity=uuid.uuid4().hex;short='R'+str(counter).zfill(4)
            item=ScheduleItem(identity,short,session,sender,'',title,due,now,
                target_id=sender,recurrence_type=recurrence,
                recurrence_value=json.dumps({'day':datetime.fromtimestamp(due,CST).day}))
            columns=list(item.to_dict());values=list(item.to_dict().values())
            c.execute('INSERT INTO schedules ('+','.join(columns)+') VALUES ('+','.join('?' for _ in columns)+')',values)
            c.execute('INSERT INTO qqai_requests VALUES(?,?,?)',(request_key,identity,now))
            return {'id':identity,'duplicate':False}

    def scoped_pending(self,session,sender):
        return [s for s in self.get_user_pending_schedules(sender) if s.unified_msg_origin==session]

    def cancel_scoped(self,session,sender,short):
        with self._get_cursor() as c:
            c.execute("UPDATE schedules SET status='cancelled' WHERE unified_msg_origin=? AND sender_id=? AND short_id=? AND status='pending'",(session,sender,short.upper()))
            return c.rowcount==1

    def due(self,now):
        with self._get_cursor() as c:
            rows=c.execute("SELECT id FROM schedules WHERE status='pending' AND trigger_time<=? ORDER BY trigger_time LIMIT 8",(now,)).fetchall()
        return [self.get_schedule_by_id(row[0]) for row in rows]

    def claim(self,item):
        """Reserve an occurrence before any transport; committed across reloads."""
        with self._get_cursor() as c:
            c.execute("INSERT OR IGNORE INTO qqai_occurrences SELECT id,trigger_time,'claimed',? FROM schedules WHERE id=? AND trigger_time=? AND status='pending'",(time.time(),item.id,item.trigger_time))
            return c.rowcount==1

    def finish(self,item,state,now=None):
        now=time.time() if now is None else now
        with self._get_cursor() as c:
            c.execute('UPDATE qqai_occurrences SET state=?,stamp=? WHERE schedule_id=? AND due=?',(state,now,item.id,item.trigger_time))
            next_at=next_occurrence(item,now)
            if next_at:
                c.execute("UPDATE schedules SET trigger_time=?,trigger_count=trigger_count+1 WHERE id=? AND trigger_time=? AND status='pending'",(next_at,item.id,item.trigger_time))
            else:
                c.execute("UPDATE schedules SET status=?,trigger_count=trigger_count+1 WHERE id=? AND trigger_time=? AND status='pending'",('triggered' if state=='sent' else state,item.id,item.trigger_time))

    def recover_claim(self,item,now):
        # A previous process might have sent before crashing. Never resend it.
        with self._get_cursor() as c:
            row=c.execute('SELECT state FROM qqai_occurrences WHERE schedule_id=? AND due=?',(item.id,item.trigger_time)).fetchone()
        if row:self.finish(item,'uncertain_after_reload',now)
        return bool(row)

    def cleanup(self,now):
        with self._get_cursor() as c:
            c.execute('DELETE FROM qqai_requests WHERE stamp<?',(now-30*86400,))
            c.execute('DELETE FROM qqai_occurrences WHERE stamp<?',(now-30*86400,))
            c.execute("DELETE FROM schedules WHERE status!='pending' AND created_at<?",(now-30*86400,))

    def counts(self):
        with self._get_cursor() as c:
            return dict(c.execute('SELECT status,count(*) FROM schedules GROUP BY status').fetchall())


class ReminderPlugin(Star):
    def __init__(self,context,config=None):
        super().__init__(context);self.config=config if config is not None else {};self.db=None
    async def initialize(self):
        directory=StarTools.get_data_dir('astrbot_plugin_reminder')
        os.chmod(directory,0o700)
        self.db=ManagedDatabase(str(directory/'schedules.db'));os.chmod(directory/'schedules.db',0o600)
    async def terminate(self):
        if self.db:self.db.close();self.db=None

    def create_qqai_reminder(self,**kwargs):
        if not self.db or not self.config.get('enabled',True):return {'error':'disabled'}
        match=re.fullmatch(r'qqai:(GroupMessage|FriendMessage):([0-9]{4,20})',kwargs['session'])
        groups=tuple(map(str,self.config.get('allowed_groups',[])))
        if (not match or not re.fullmatch(r'[0-9]{4,20}',kwargs['sender'])
                or len(groups)!=1 or not re.fullmatch(r'[1-9][0-9]{3,19}',groups[0])):return {'error':'scope'}
        if match[1]=='GroupMessage' and match[2]!=groups[0]:return {'error':'scope'}
        if kwargs['session'].startswith('qqai:FriendMessage:') and kwargs['session'].split(':')[-1]!=kwargs['sender']:
            return {'error':'scope'}
        if (not time.time()<kwargs['due']<=time.time()+365*86400 or not 1<=len(kwargs['title'])<=200
                or kwargs['recurrence'] not in ('none','daily','weekdays','weekly','monthly','yearly')):return {'error':'invalid'}
        result=self.db.create(**kwargs,limit=max(1,min(100,int(self.config.get('max_reminders',20)))))
        if 'id' in result:result['item']=self.db.get_schedule_by_id(result['id'])
        return result
