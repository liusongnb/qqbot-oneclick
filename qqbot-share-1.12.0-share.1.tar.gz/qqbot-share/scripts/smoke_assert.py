"""Read native data and import plugin entrypoints without invoking providers."""
import importlib
import json
from pathlib import Path
import sqlite3
import sys

data=Path('/AstrBot/data')
with sqlite3.connect(data/'data_v4.db') as db:
    assert db.execute('SELECT count(*) FROM personas WHERE persona_id=?',('小鲸鱼',)).fetchone()[0]==1
    row=db.execute("SELECT value FROM preferences WHERE scope='global' AND scope_id='global' AND key='umop_config_routing'").fetchone()
    route=json.loads(row[0])['val'];profile=route['qqai:FriendMessage:*']
    row=db.execute("SELECT value FROM preferences WHERE scope='global' AND scope_id='global' AND key='abconf_mapping'").fetchone()
    mapping=json.loads(row[0])['val'];private=json.loads((data/'config'/mapping[profile]['path']).read_text())
    assert not private['platform_settings']['enable_id_white_list']
    assert private['plugin_set']==['qqai_companion']
    assert private['provider_settings']['enable'] is False
with sqlite3.connect(data/'plugin_data/qqai_companion/memory.sqlite3') as db:
    own=json.loads(db.execute('SELECT value FROM meta WHERE key=?',('qqai_private_profile_v170',)).fetchone()[0])
    assert own['id']==profile and own['group']=='777777777'
    assert db.execute('SELECT count(*) FROM facts').fetchone()[0]==0
sys.path.insert(0,str(data/'plugins'))
for name in ['astrbot_plugin_qqai_companion.main','time_awareness.main','astrbot_plugin_reminder.main']:
    importlib.import_module(name)
print('Native schema, empty memory, shared group identity, private routing and all three plugin imports passed.')
