import argparse
import json
from pathlib import Path
import time
from urllib.error import HTTPError,URLError
from urllib.request import urlopen

def check():
    result={}
    for name,url in [('astrbot','http://127.0.0.1:16185/'),('napcat','http://127.0.0.1:6099/webui/')]:
        try:
            with urlopen(url,timeout=2) as response:result[name]=200<=response.status<400
        except HTTPError as e:result[name]=e.code in (401,403)
        except (OSError,URLError):result[name]=False
    result['qq_scan_required']=True
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--wait',action='store_true');args=parser.parse_args()
    deadline=time.monotonic()+(150 if args.wait else 0)
    while True:
        result=check()
        if result['astrbot'] and result['napcat'] or time.monotonic()>=deadline:break
        time.sleep(3)
    print(json.dumps(result))
    raise SystemExit(0 if result['astrbot'] and result['napcat'] else 1)
