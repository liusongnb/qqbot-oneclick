"""Resolve common Chinese reminder times; leave open language to the model."""
from datetime import datetime, timedelta, timezone
import re

CST=timezone(timedelta(hours=8))
NUMBER=r'(?:[0-9]{1,4}|[零〇一二两三四五六七八九十百]{1,6})'
CLOCK=re.compile(r'(?P<period>凌晨|清晨|早上|早晨|上午|中午|下午|傍晚|晚上|晚间|夜里|夜间)?\s*'
                 r'(?P<hour>'+NUMBER+r')(?:(?:点|时)(?:(?P<fraction>半|一刻|三刻)|(?P<minute>'+NUMBER+r')(?:分)?)?'
                 r'|[:：](?P<colon>[0-9]{1,2}))(?:整)?')
DAY=re.compile(r'大后天|后天|明天|明早|明晚|今天|今日|今早|今晚|今夜')
CUE=re.compile(r'提醒(?:一下|下)?我|(?:叫|喊|催|通知)我')
RELATIVE=re.compile(r'(?:再过|过|再等|等)?\s*(?P<amount>'+NUMBER+r'|半)\s*'
                    r'(?P<unit>秒钟|秒|分钟|分|小时|钟头|天)(?:之)?(?:以)?后?')
TIME_HINT=re.compile(r'今天|今日|明天|明早|明晚|后天|今晚|今早|今夜|凌晨|清晨|早上|早晨|上午|中午|下午|傍晚|晚上|晚间|夜里|夜间|每天|每日|工作日|周[一二三四五六日天]|星期|下周|[0-9零〇一二两三四五六七八九十]+(?:月|号|日|点|时|分钟|秒)|[0-9]{1,2}[:：][0-9]{2}|半小时')


def number(value):
    if value.isdigit():return int(value)
    digits={'零':0,'〇':0,'一':1,'二':2,'两':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9}
    if value in digits:return digits[value]
    if '百' in value:
        left,right=value.split('百',1)
        return digits.get(left,1)*100+(number(right.lstrip('零')) if right.lstrip('零') else 0)
    if '十' in value:
        left,right=value.split('十',1)
        return digits.get(left,1)*10+digits.get(right,0)
    raise ValueError('unsupported numeral')


def explicit_request(text):
    text=str(text).strip()
    # A quoted task is fine; reports/examples of someone else's request are not.
    if re.search(r'(?:他|她|别人|有人|朋友)(?:跟我|对我)?说|(?:举个|举一?个)?例子|例如|假如|假设',text):return False
    if re.match(r'^(?:[“「].*[”」])[。！!？?\s]*$',text):return False
    return bool(re.search(r'提醒(?:一下|下)?我|设置提醒|(?:查看|列出|取消|删除)(?:我的)?(?:提醒|日程)|(?:有哪些|有什么).*(?:提醒|日程)|^/?(?:callme|remind|提醒列表|取消提醒)\b',text,re.I)
                or (re.search(r'(?:叫|喊|催|通知)我',text) and TIME_HINT.search(text)))


def event_text(text):
    cue=CUE.search(text)
    if not cue:return ''
    after=text[cue.end():].strip()
    source=after if after.strip('，,。.!！?？一下声 ') else text[:cue.start()]
    source=CLOCK.sub('',source)
    source=DAY.sub('',source)
    source=re.sub(r'每天|每日|工作日|到时候|到时|别忘了|别忘|记得|麻烦|请|帮我', '',source)
    source=RELATIVE.sub('',source)
    source=re.sub(r'[0-9]{1,2}月[0-9]{1,2}[日号]','',source)
    source=re.sub(r'^(?:(?:我|要|在|于|再|一下|一声)\s*)+','',source)
    source=re.sub(r'(?:的时候|的时候再|的时候就|就|再)$','',source)
    return source.strip('，,。.!！?？；;：:～~“”「」"\' \n')


def parse_local(text,now,previous=''):
    """Return a complete/partial structure only when the time expression is known."""
    title=event_text(text) or event_text(previous)
    if previous and not title and not CUE.search(text) and not TIME_HINT.search(text):title=text.strip('，,。.!！?？ ')
    combined=text+' '+previous
    # Offsets, alternatives, multiple clock times and calendar recurrences need semantics.
    if re.search(r'提前|推迟|延后|之前|之后|或者|还是|每周|每月|每年|下周|下个|星期|周[一二三四五六日天]'
                 r'|昨天|昨日|昨晚|前天|前晚|上周|本周|这周|周末|礼拜|下月|本月|这个月|月底|月末|月初'
                 r'|明年|今年|后年|[0-9]{4}年|[0-9一二两三四五六七八九十]+[号日]',combined):return None
    recurrence='weekdays' if '工作日' in combined else 'daily' if re.search(r'每天|每日',combined) else 'none'
    relative=RELATIVE.search(text)
    if relative and ('后' in relative.group() or re.match(r'(?:再过|过|再等|等)',relative.group())):
        amount=.5 if relative['amount']=='半' else number(relative['amount'])
        seconds=amount*{'秒钟':1,'秒':1,'分钟':60,'分':60,'小时':3600,'钟头':3600,'天':86400}[relative['unit']]
        if seconds>=15 and title:
            return {'action':'create','fire_at':(now+timedelta(seconds=seconds)).isoformat(),'event':title,'recurrence':'none'}
    matches=list(CLOCK.finditer(text)) or list(CLOCK.finditer(previous))
    if len(matches)>1:return None
    if not matches:
        # Unknown colloquial times go to the model; an absent clock is a real missing field.
        if re.search(r'一会|待会|等会|早[0-9一二两三四五六七八九十]|半小时|小时|分钟|秒|吃完|结束|之后',combined):return None
        if title:return {'action':'clarify','event':title,'missing':['time'],'recurrence':recurrence}
        return None
    clock=matches[0]
    try:
        hour=number(clock['hour'])
        minute={'半':30,'一刻':15,'三刻':45}.get(clock['fraction'],number(clock['minute'] or clock['colon'] or '0'))
    except ValueError:return None
    if hour>23 or minute>59:return {'action':'clarify','event':title,'missing':['time'],'reason':'invalid_time'}
    period=clock['period'] or ''
    day_source=text if DAY.search(text) or re.search(r'[0-9]{1,2}月[0-9]{1,2}[日号]',text) else previous
    day_match=DAY.search(day_source)
    day_word=day_match.group() if day_match else ''
    if not period and day_word in ('今晚','明晚','今夜'):period='晚上'
    # Midnight phrased as "晚上十二点" has a calendar-day boundary; use semantics.
    if hour==12 and period in ('晚上','晚间','夜里','夜间'):return None
    if hour>12 and period in ('凌晨','清晨','早上','早晨','上午'):return None
    if period in ('下午','傍晚','晚上','晚间','夜里','夜间') and 1<=hour<=11:hour+=12
    if period=='中午' and 1<=hour<=4:hour+=12
    if period=='凌晨' and hour==12:hour=0
    if period in ('夜里','夜间') and hour==12:hour=0
    offset={'大后天':3,'后天':2,'明天':1,'明早':1,'明晚':1}.get(day_word,0)
    due=(now+timedelta(days=offset)).replace(hour=hour,minute=minute,second=0,microsecond=0)
    month_day=re.search(r'([0-9]{1,2})月([0-9]{1,2})[日号]',day_source)
    if month_day:
        try:due=due.replace(month=int(month_day[1]),day=int(month_day[2]))
        except ValueError:return {'action':'clarify','event':title,'missing':['date'],'reason':'invalid_date'}
    if recurrence!='none':
        if due<=now:due+=timedelta(days=1)
        while recurrence=='weekdays' and due.weekday()>4:due+=timedelta(days=1)
    result={'action':'create' if title else 'clarify','fire_at':due.isoformat(),'event':title,'recurrence':recurrence}
    if not title:result['missing']=['event']
    return result


def when_label(when,now):
    delta=(when.date()-now.date()).days
    day={0:'今天',1:'明天',2:'后天'}.get(delta,f'{when:%m月%d日}')
    return f'{day} {when:%H:%M}'


def clarification(data,text,now):
    missing=data.get('missing') or ['time']
    title=str(data.get('event','')).strip()[:80]
    if missing==['event'] and data.get('fire_at'):
        try:return when_label(datetime.fromisoformat(data['fire_at']).astimezone(CST),now)+'，提醒你做什么呀？'
        except (ValueError,TypeError):pass
    if data.get('reason')=='invalid_date':return '这个日期不太对，再告诉我是几月几号呀？'
    if data.get('reason')=='invalid_time':return '这个时刻不太对，再告诉我是几点几分呀？'
    if title:
        found=DAY.search(text)
        day=found.group() if found else ''
        return f'{day}几点提醒你{title}呀？'
    return '想让我什么时候提醒你做什么呀？说一句就行。'
