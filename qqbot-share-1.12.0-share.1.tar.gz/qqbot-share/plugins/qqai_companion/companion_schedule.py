"""Persistent, bounded daily openings; no personal memory or chat data."""
from __future__ import annotations

from datetime import datetime,timedelta,timezone
import json
import random
import re
import time
from astrbot.api.event import AstrMessageEvent
from astrbot.core.platform.message_type import MessageType

BJT=timezone(timedelta(hours=8))
TOPICS={
    'animal':('动物的小聪明','动物 有趣行为 科普'),
    'ocean':('海里的奇妙生物','海洋生物 有趣冷知识 科普'),
    'space':('宇宙里的小问题','天文 有趣现象 科普'),
    'plant':('植物的生存技巧','植物 有趣适应 科普'),
    'language':('语言里的小巧合','汉字 词语 有趣来历 博物馆'),
    'museum':('日常物件的来历','博物馆 日常用品 有趣历史'),
    'game':('游戏设计的小巧思','电子游戏 设计 趣味细节'),
    'animation':('动画里的有趣细节','动画 制作 有趣细节'),
    'optics':('光与颜色的小趣事','彩虹 光学 有趣现象 科普'),
    'puzzle':('一个轻松的脑洞','数学 趣味 小谜题 科普'),
    'sound':('声音的小秘密','声音 有趣现象 科普'),
    'everyday':('日常小习惯的脑洞','日常生活 有趣小发明 博物馆'),
    'tinyjoy':('不起眼的小快乐','生活 小快乐 有趣发现'),
    'design':('设计里的小机关','日常设计 有趣细节'),
    'time':('时间感的脑洞','时间感知 有趣现象 科普'),
    'books':('故事里的小设定','童话 故事 有趣设定'),
}

class GroupTarget:
    """An outbound group target, not a fabricated member's incoming message."""
    def __init__(self,group):
        self.group=str(group)
        self.unified_msg_origin='qqai:GroupMessage:'+self.group
    def get_message_type(self):return MessageType.GROUP_MESSAGE
    def get_platform_name(self):return 'aiocqhttp'
    def get_platform_id(self):return 'qqai'
    def get_group_id(self):return self.group
    def get_sender_id(self):return '__group_proactive__'
    def get_self_id(self):return '__outbound_target__'
    def plain_result(self,text):return AstrMessageEvent.plain_result(self,text)
    def chain_result(self,chain):return AstrMessageEvent.chain_result(self,chain)

class DailySchedule:
    def __init__(self,db,*,clock=None,rng=None):
        self.db=db;self.clock=clock or time.time;self.rng=rng or random.SystemRandom()

    def read(self,key,default):
        row=self.db.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone()
        try:return json.loads(row[0]) if row else default
        except (ValueError,TypeError):return default

    def write(self,key,value):
        self.db.execute('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                        (key,json.dumps(value,ensure_ascii=False)))
        self.db.commit()

    def recent(self,group):
        value=self.read('daily_opening_recent:'+group,[])
        return [v for v in value[-8:] if isinstance(v,dict)] if isinstance(value,list) else []

    def plan(self,group,minimum=1,maximum=2,start_hour=9,end_hour=22,already_sent=0):
        now=self.clock();date=datetime.fromtimestamp(now,BJT).date().isoformat()
        key='daily_opening_plan:'+group
        existing=self.read(key,{})
        if isinstance(existing,dict) and existing.get('day')==date:
            return existing
        maximum=max(1,min(2,maximum));minimum=max(1,min(maximum,minimum))
        goal=self.rng.randint(minimum,maximum)
        midnight=datetime.fromtimestamp(now,BJT).replace(hour=0,minute=0,second=0,microsecond=0)
        start=(midnight+timedelta(hours=start_hour)).timestamp()
        end=(midnight+timedelta(hours=end_hour)).timestamp()
        earliest=max(start,now+900)
        count=max(0,goal-already_sent) if earliest<end else 0
        if count==2 and end-earliest<3*3600:count=1
        if count==2:
            first=self.rng.uniform(earliest,end-3*3600)
            times=[first,self.rng.uniform(first+3*3600,end)]
        elif count==1:times=[self.rng.uniform(earliest,end)]
        else:times=[]
        excluded={v.get('topic') for v in self.recent(group)}
        pool=[v for v in TOPICS if v not in excluded]
        topics=self.rng.sample(pool or list(TOPICS),len(times))
        value={'day':date,'goal':goal,'slots':[{'at':stamp,'topic':topic,'kind':'web' if i==0 else 'casual','state':'pending'}
                                             for i,(stamp,topic) in enumerate(zip(times,topics))]}
        self.write(key,value);return value

    def claim(self,group,plan,*,already_sent=0,maximum=2):
        if already_sent>=min(plan['goal'],max(1,min(2,maximum))):return None
        now=self.clock()
        for slot in plan['slots']:
            if slot['state']!='pending':continue
            if now<slot['at']:return None
            if now-slot['at']>3600:
                slot['state']='expired';continue
            # Durable claim before any I/O: reloads and send failures never replay.
            slot['state']='claimed'
            self.write('daily_opening_plan:'+group,plan)
            return dict(slot)
        self.write('daily_opening_plan:'+group,plan)
        return None

    def remember_opening(self,group,topic,text):
        entries=self.recent(group)
        entries.append({'topic':topic,'text':str(text)[:400],'stamp':self.clock()})
        self.write('daily_opening_recent:'+group,entries[-8:])

    def repetitive(self,group,text):
        def grams(value):
            value=re.sub(r'[^\w\u4e00-\u9fff]','',value.lower())
            return {value[i:i+3] for i in range(max(0,len(value)-2))}
        new=grams(text)
        for item in self.recent(group):
            old=grams(item.get('text',''))
            if new and old and len(new&old)/min(len(new),len(old))>=0.6:return True
        return False
