"""Synthetic cross-channel memory migration, isolation and forgetting contracts."""
import asyncio
import json
import tempfile
import time
import unittest

import test_companion as tc
import test_private as tp
from companion_under_test.companion_memory import PAIR_PREFIX, share_facts, restore_separate_facts

m=tc.m


class SharedStoreTest(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.store=m.Store(self.temp.name)
        self.group=self.store.scope('qqai','888888888','20001')
        self.private=self.store.scope('qqai','private:20001','20001')
    def tearDown(self):self.store.close();self.temp.cleanup()
    def insert(self,scope,text,stamp):
        self.store.db.execute('INSERT INTO facts VALUES(?,?,?)',(scope,text,stamp));self.store.db.commit()
    def test_migrate_legacy_private_and_group_without_touching_histories(self):
        now=time.time();self.insert(self.group,'喜欢草莓',now-20);self.insert(self.private,'喜欢音乐',now-10)
        self.store.add_turn(self.group,'synthetic group question','synthetic group answer')
        self.store.add_turn(self.private,'synthetic private question','synthetic private answer')
        before=self.store.db.execute('SELECT * FROM turns ORDER BY id').fetchall()
        self.assertEqual(share_facts(self.store.db,self.group,self.private),1)
        self.assertEqual(set(self.store.facts(self.group,'',recall=True)),{'喜欢草莓','喜欢音乐'})
        self.assertFalse(self.store.facts(self.private,'',recall=True))
        self.assertEqual(self.store.db.execute('SELECT * FROM turns ORDER BY id').fetchall(),before)
        self.assertEqual(self.store.db.execute('SELECT stamp FROM facts WHERE content=?',('喜欢音乐',)).fetchone()[0],now-10)
    def test_latest_preference_wins_across_legacy_channels(self):
        now=time.time();self.insert(self.group,'喜欢草莓',now-20);self.insert(self.private,'不喜欢草莓',now-10)
        share_facts(self.store.db,self.group,self.private)
        self.assertEqual(self.store.facts(self.group,'草莓'),['不喜欢草莓'])
    def test_newer_group_preference_is_not_overwritten_by_old_private_fact(self):
        now=time.time();self.insert(self.group,'不喜欢草莓',now-5);self.insert(self.private,'喜欢草莓',now-20)
        share_facts(self.store.db,self.group,self.private)
        self.assertEqual(self.store.facts(self.group,'草莓'),['不喜欢草莓'])
    def test_duplicate_facts_keep_latest_timestamp_and_do_not_repeat_on_reload(self):
        now=time.time();self.insert(self.group,'喜欢音乐',now-20);self.insert(self.private,'喜欢音乐',now-10)
        share_facts(self.store.db,self.group,self.private);self.assertEqual(share_facts(self.store.db,self.group,self.private),0)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM facts').fetchone()[0],1)
        self.assertEqual(self.store.db.execute('SELECT stamp FROM facts').fetchone()[0],now-10)
        self.store.close();self.store=m.Store(self.temp.name)
        self.assertEqual(share_facts(self.store.db,self.group,self.private),0)
        self.assertEqual(self.store.facts(self.group,'音乐'),['喜欢音乐'])
    def test_total_shared_memory_retains_existing_per_member_bound(self):
        now=time.time()
        for index in range(100):
            self.insert(self.group,'群偏好'+str(index),now-200+index)
            self.insert(self.private,'私聊偏好'+str(index),now-100+index)
        share_facts(self.store.db,self.group,self.private)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM facts').fetchone()[0],100)
    def test_expired_source_facts_do_not_resurrect(self):
        self.insert(self.private,'喜欢旧话题',time.time()-366*86400)
        share_facts(self.store.db,self.group,self.private)
        self.assertFalse(self.store.facts(self.group,'旧话题',recall=True))
    def test_wrong_existing_identity_is_rejected_without_data_change(self):
        self.store.remember(self.private,'喜欢音乐')
        other=self.store.scope('qqai','888888888','20002')
        self.store.db.execute('INSERT INTO meta VALUES(?,?)',(PAIR_PREFIX+self.private,other));self.store.db.commit()
        before=self.store.db.execute('SELECT * FROM facts').fetchall()
        with self.assertRaises(ValueError):share_facts(self.store.db,self.group,self.private)
        self.assertEqual(self.store.db.execute('SELECT * FROM facts').fetchall(),before)
    def test_migration_failure_rolls_back_facts_and_pair_registration(self):
        self.store.remember(self.private,'喜欢音乐')
        self.store.db.execute("CREATE TRIGGER reject_migration BEFORE INSERT ON facts WHEN NEW.scope='"+self.group+"' BEGIN SELECT RAISE(ABORT,'synthetic failure'); END")
        self.store.db.commit()
        with self.assertRaises(Exception):share_facts(self.store.db,self.group,self.private)
        self.assertEqual(self.store.facts(self.private,'音乐'),['喜欢音乐'])
        self.assertIsNone(self.store.db.execute('SELECT value FROM meta WHERE key=?',(PAIR_PREFIX+self.private,)).fetchone())
    def test_rollback_copies_current_shared_facts_without_restoring_old_database(self):
        self.store.remember(self.private,'喜欢音乐');share_facts(self.store.db,self.group,self.private)
        self.store.remember(self.group,'不喜欢音乐')
        self.assertEqual(restore_separate_facts(self.store.db),1)
        for scope in (self.group,self.private):self.assertEqual(self.store.facts(scope,'音乐'),['不喜欢音乐'])
    def test_rollback_does_not_restore_forgotten_facts(self):
        self.store.remember(self.private,'喜欢音乐');share_facts(self.store.db,self.group,self.private)
        self.store.forget(self.group);self.store.forget(self.private);restore_separate_facts(self.store.db)
        self.assertFalse(self.store.facts(self.private,'音乐'));self.assertFalse(self.store.facts(self.group,'音乐'))


class SharedMemoryTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        asyncio.get_running_loop().slow_callback_duration=1
        self.temp=tempfile.TemporaryDirectory();self.ctx=tp.Context()
        config=json.loads((tc.ROOT/'plugin-config.json').read_text(encoding='utf-8'))
        config['voice_probability_percent']=0
        self.p=m.Main(self.ctx,config);self.p.store=m.Store(self.temp.name);self.p.ready=True;self.p.quiet=lambda:False
        self.access=tp.PrivateAccess(self.ctx,self.p.store,['888888888']);self.p.private_access=self.access
        await self.access.maintain(force=True)
    async def asyncTearDown(self):await self.p.terminate();self.temp.cleanup()
    def event(self,text,*,private=False,sender='20001'):
        return tp.PrivateEvent(text,sender=sender) if private else tc.Event('大肥鱼，'+text,sender=sender,direct=True)
    def prepare(self,event):
        self.assertTrue(self.p.prepare(event,self.ctx.get_config(event.unified_msg_origin)))
        return event.get_extra(m.EXTRA)
    async def send(self,text,*,private=False,sender='20001'):
        self.p.reply_times.clear();event=self.event(text,private=private,sender=sender)
        self.prepare(event);await self.p.on_candidate(event);return event
    def scopes(self,sender='20001'):
        return (self.p.store.scope('qqai','888888888',sender),self.p.store.scope('qqai','private:'+sender,sender))
    async def test_group_preference_is_in_private_prompt_but_group_history_is_absent(self):
        await self.send('记住我喜欢草莓');self.ctx.calls.clear()
        await self.send('我喜欢什么？',private=True)
        call=self.ctx.calls[0];self.assertIn('喜欢草莓',json.loads(call['prompt'])['personal_memory'])
        self.assertFalse(call['contexts'])
        self.assertNotIn('记住我喜欢草莓',json.dumps(json.loads(call['prompt'])['recent_group'],ensure_ascii=False))
    async def test_private_preference_is_in_group_prompt_but_private_history_is_absent(self):
        await self.send('记住我喜欢音乐',private=True);self.ctx.calls.clear()
        await self.send('我喜欢什么？')
        call=self.ctx.calls[0];self.assertIn('喜欢音乐',json.loads(call['prompt'])['personal_memory'])
        self.assertFalse(call['contexts'])
        self.assertNotIn('记住我喜欢音乐',json.dumps(json.loads(call['prompt'])['recent_group'],ensure_ascii=False))
    async def test_different_people_do_not_share_facts_or_private_text(self):
        await self.send('记住我喜欢音乐',private=True);self.ctx.calls.clear()
        await self.send('我喜欢什么？',private=True,sender='20002')
        call=self.ctx.calls[0];self.assertFalse(json.loads(call['prompt'])['personal_memory'])
        self.assertNotIn('音乐',json.dumps(call,ensure_ascii=False))
    async def test_existing_private_facts_are_available_on_first_group_message(self):
        group,private=self.scopes();self.p.store.remember(private,'喜欢音乐')
        await self.send('我喜欢什么？')
        self.assertIn('喜欢音乐',json.loads(self.ctx.calls[0]['prompt'])['personal_memory'])
    async def test_legacy_facts_of_a_different_member_are_not_migrated_into_current_member(self):
        _,private=self.scopes('20002');self.p.store.remember(private,'喜欢音乐')
        await self.send('我喜欢什么？')
        self.assertFalse(json.loads(self.ctx.calls[0]['prompt'])['personal_memory'])
        self.assertEqual(self.p.store.facts(private,'音乐'),['喜欢音乐'])
    async def test_preference_updates_in_either_channel_replace_the_other_channel_fact(self):
        await self.send('记住我喜欢草莓');await self.send('记住我不喜欢草莓',private=True)
        self.ctx.calls.clear();await self.send('我喜欢什么？')
        self.assertEqual(json.loads(self.ctx.calls[0]['prompt'])['personal_memory'],['不喜欢草莓'])
    async def test_forget_from_either_channel_clears_own_facts_and_both_histories(self):
        for from_private in (False,True):
            await self.send('记住我喜欢音乐');await self.send('你好呀',private=True)
            other_group,_=self.scopes('20002');self.p.store.remember(other_group,'喜欢草莓')
            event=await self.send('忘记我的记忆',private=from_private)
            self.assertIn('群聊和私聊',event.sent[0])
            for scope in self.scopes():
                self.assertFalse(self.p.store.facts(scope,'音乐',recall=True));self.assertFalse(self.p.store.history(scope))
            self.assertEqual(self.p.store.facts(other_group,'草莓'),['喜欢草莓'])
    async def test_forget_in_private_invalidates_in_flight_group_reply(self):
        async def forget():self.prepare(self.event('忘记我的记忆',private=True))
        self.ctx.before_return=forget
        event=await self.send('记住我喜欢音乐');self.assertFalse(event.sent)
        self.assertFalse(self.p.store.history(self.scopes()[0]))
        self.assertFalse(self.p.store.facts(self.scopes()[0],'音乐'))
    async def test_forget_in_group_invalidates_in_flight_private_reply(self):
        async def forget():self.prepare(self.event('忘记我的记忆'))
        self.ctx.before_return=forget
        event=await self.send('记住我喜欢音乐',private=True);self.assertFalse(event.sent)
    async def test_forget_preserves_another_members_queued_group_reply(self):
        other=self.event('你好呀',sender='20002');self.prepare(other)
        self.p.deferred['888888888']=(other,time.monotonic())
        self.prepare(self.event('忘记我的记忆',private=True))
        self.assertIs(self.p.deferred['888888888'][0],other)
    async def test_forget_clears_own_queued_reply_across_channels(self):
        event=self.event('你好呀');self.prepare(event)
        self.p.deferred['888888888']=(event,time.monotonic())
        self.prepare(self.event('忘记我的记忆',private=True));self.assertFalse(self.p.deferred)
    async def test_invalid_private_sender_cannot_migrate_or_recall_facts(self):
        _,private=self.scopes('29999');self.p.store.remember(private,'喜欢音乐')
        event=tp.PrivateEvent('我喜欢什么？',sender='29999')
        self.assertFalse(self.p.prepare(event,self.ctx.get_config(event.unified_msg_origin)))
        self.assertEqual(self.p.store.facts(private,'音乐'),['喜欢音乐']);self.assertFalse(self.ctx.calls)
    async def test_memory_extraction_uses_the_shared_member_scope(self):
        event=self.event('我喜欢音乐，平时经常听歌',private=True);candidate=self.prepare(event)
        self.ctx.responses=['[{"kind":"preference","evidence":"我喜欢音乐"}]']
        await self.p.extract(event,candidate)
        group,private=self.scopes();self.assertEqual(self.p.store.facts(group,'音乐'),['喜欢音乐'])
        self.assertFalse(self.p.store.facts(private,'音乐'))
    async def test_forget_during_extraction_cannot_recreate_shared_fact(self):
        event=self.event('我喜欢音乐，平时经常听歌',private=True);candidate=self.prepare(event)
        async def forget():self.prepare(self.event('忘记我的记忆'))
        self.ctx.before_return=forget;self.ctx.responses=['[{"kind":"preference","evidence":"我喜欢音乐"}]']
        await self.p.extract(event,candidate)
        self.assertFalse(self.p.store.facts(self.scopes()[0],'音乐'))
    async def test_pausing_during_extraction_prevents_late_shared_memory_write(self):
        event=self.event('我喜欢音乐，平时经常听歌',private=True);candidate=self.prepare(event)
        async def pause():(self.p.store.directory/'PAUSED').touch()
        self.ctx.before_return=pause;self.ctx.responses=['[{"kind":"preference","evidence":"我喜欢音乐"}]']
        await self.p.extract(event,candidate)
        self.assertFalse(self.p.store.facts(self.scopes()[0],'音乐'))
    async def test_system_prompt_describes_shared_facts_and_separate_histories(self):
        system=await self.p.reply_system(tp.PrivateEvent())
        self.assertIn('共用的长期记忆',system);self.assertIn('近期聊天记录与对话上下文仍按本轮群聊或私聊分别处理',system)
        self.assertIn('不透露或编造其他成员的信息',system)
