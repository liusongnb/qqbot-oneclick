"""Join one member's facts while preserving the two conversation histories."""
from __future__ import annotations

import re
import time

PAIR_PREFIX = 'shared_facts_v180:'


def _validate(canonical, private):
    if canonical == private or not all(re.fullmatch(r'[0-9a-f]{64}', value) for value in (canonical, private)):
        raise ValueError('Invalid shared memory scopes')


def _rows(db, scope):
    return db.execute('SELECT content,stamp FROM facts WHERE scope=? AND stamp>? '
                      'ORDER BY stamp DESC,content LIMIT 100',
                      (scope, time.time()-365*86400)).fetchall()


def _merged(canonical_rows, private_rows):
    # Latest explicit preference wins; exact ties favor the canonical scope.
    ordered=sorted([(stamp,1,text) for text,stamp in canonical_rows]
                   +[(stamp,0,text) for text,stamp in private_rows], reverse=True)
    selected=[];seen=set()
    for stamp,_,text in ordered:
        opposite=('喜欢'+text[3:]) if text.startswith('不喜欢') else ('不喜欢'+text[2:]) if text.startswith('喜欢') else None
        if text in seen or (opposite and opposite in seen):
            continue
        selected.append((text,stamp));seen.add(text)
        if len(selected)>=100:
            break
    return selected


def share_facts(db, canonical, private):
    """Atomically merge legacy facts; keep original timestamps and all turns."""
    _validate(canonical, private)
    key=PAIR_PREFIX+private
    saved=db.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone()
    if saved and saved[0]!=canonical:
        raise ValueError('Existing memory identity differs')
    private_rows=_rows(db,private)
    if not private_rows and saved:
        return 0
    with db:
        db.execute('INSERT OR IGNORE INTO meta(key,value) VALUES(?,?)',(key,canonical))
        if private_rows:
            merged=_merged(_rows(db,canonical),private_rows)
            db.execute('DELETE FROM facts WHERE scope IN (?,?)',(canonical,private))
            db.executemany('INSERT INTO facts(scope,content,stamp) VALUES(?,?,?)',
                           [(canonical,text,stamp) for text,stamp in merged])
    return len(private_rows)


def restore_separate_facts(db):
    """Rollback helper: copy current shared facts to both old scopes, without rewinding data."""
    pairs=db.execute('SELECT key,value FROM meta WHERE key LIKE ?', (PAIR_PREFIX+'%',)).fetchall()
    with db:
        for key,canonical in pairs:
            private=key[len(PAIR_PREFIX):];_validate(canonical,private)
            merged=_merged(_rows(db,canonical),_rows(db,private))
            db.execute('DELETE FROM facts WHERE scope=?',(private,))
            db.executemany('INSERT INTO facts(scope,content,stamp) VALUES(?,?,?)',
                           [(private,text,stamp) for text,stamp in merged])
    return len(pairs)
