"""Private QQAI companion package."""
