"""Hosted API contract and text fallback; synthetic audio, no real charges."""
import asyncio
import json
import sys
import tempfile
import unittest
from unittest.mock import patch

import test_companion as tc
import test_voice as tv

b=sys.modules[tc.m.__package__+'.companion_breeze']
KEY='synthetic-test-key-never-real'
VOICE='voc_syntheticvoice001'


class Response:
    def __init__(self, raw=None, status=200, content_type='audio/wav', length=None, encoding='identity'):
        self.raw=tv.wav() if raw is None else raw
        self.status=status
        self.headers={'Content-Type':content_type,'Content-Encoding':encoding}
        self.content_length=length
        self.content=self
        self.entered=False;self.chunks=0
    async def __aenter__(self):self.entered=True;return self
    async def __aexit__(self,*args):pass
    async def iter_chunked(self,size):
        for i in range(0,len(self.raw),size):
            self.chunks+=1;yield self.raw[i:i+size]


class Session:
    def __init__(self,response):self.response=response;self.calls=[];self.options=None
    def create(self,**kwargs):self.options=kwargs;return self
    async def __aenter__(self):return self
    async def __aexit__(self,*args):pass
    def post(self,*args,**kwargs):self.calls.append((args,kwargs));return self.response


class BreezeContract(unittest.IsolatedAsyncioTestCase):
    async def call(self,response):
        session=Session(response)
        with patch.object(b.aiohttp,'ClientSession',session.create):
            raw=await b.BreezeVoice(KEY,VOICE).get_audio('你好呀')
        return raw,session
    async def test_exact_hosted_protocol_with_bounded_wav(self):
        raw,s=await self.call(Response())
        self.assertEqual(raw,tv.wav())
        args,kw=s.calls[0]
        self.assertEqual(args,(b.API+VOICE,))
        self.assertEqual(kw['params'],{'output_format':'wav_24000','delivery':'sync'})
        self.assertEqual(kw['json'],{'text':'你好呀','model_id':'breeze-tts-2','language_code':'zh'})
        self.assertEqual(kw['headers']['xi-api-key'],KEY)
        self.assertFalse(kw['allow_redirects']);self.assertFalse(s.options['trust_env'])
        self.assertFalse(s.options['auto_decompress']);self.assertEqual(s.options['timeout'].total,40)
        self.assertEqual(s.options['timeout'].connect,5)
    async def test_redirects_async_and_failure_statuses_never_consume_body(self):
        for status in [202,301,302,307,400,401,403,404,422,429,503,504]:
            r=Response(raw=KEY.encode(),status=status)
            with self.assertRaises(b.BreezeError) as error:await self.call(r)
            self.assertNotIn(KEY,str(error.exception));self.assertEqual(r.chunks,0)
    async def test_json_and_html_are_rejected_before_read(self):
        for content_type in ['application/json','text/html','audio/mpeg','']:
            r=Response(content_type=content_type)
            with self.assertRaises(b.BreezeError):await self.call(r)
            self.assertEqual(r.chunks,0)
    async def test_encoding_mismatch_rejected(self):
        with self.assertRaises(b.BreezeError):await self.call(Response(encoding='gzip'))
    async def test_oversized_declared_length_rejected_without_read(self):
        r=Response(length=b.MAX_BYTES+1)
        with self.assertRaises(b.BreezeError):await self.call(r)
        self.assertEqual(r.chunks,0)
    async def test_chunked_response_also_bounded(self):
        with self.assertRaises(b.BreezeError):await self.call(Response(raw=b'x'*(b.MAX_BYTES+1)))
    async def test_nonwav_binary_rejected(self):
        with self.assertRaises(b.BreezeError):await self.call(Response(raw=b'x'*200))
    async def test_transport_exception_suppresses_sensitive_diagnostic(self):
        with patch.object(b.aiohttp,'ClientSession',side_effect=RuntimeError(KEY)):
            with self.assertRaises(b.BreezeError) as e:await b.BreezeVoice(KEY,VOICE).get_audio('你好')
        self.assertNotIn(KEY,str(e.exception));self.assertTrue(e.exception.__suppress_context__)
    async def test_cancellation_propagates(self):
        with patch.object(b.aiohttp,'ClientSession',side_effect=asyncio.CancelledError):
            with self.assertRaises(asyncio.CancelledError):await b.BreezeVoice(KEY,VOICE).get_audio('你好')
    async def test_invalid_inputs_fail_before_request(self):
        for key,voice in [('',VOICE),('bad\r\nkey',VOICE),('key with space',VOICE),(KEY,'../voices'),(KEY,VOICE+'?x=y'),(None,VOICE)]:
            with self.assertRaises(b.BreezeError):b.BreezeVoice(key,voice)
        with patch.object(b.aiohttp,'ClientSession') as mocked:
            for text in ['',None,'长'*121]:
                with self.assertRaises(b.BreezeError):await b.BreezeVoice(KEY,VOICE).get_audio(text)
            mocked.assert_not_called()
    async def test_shared_voice_service_validates_duration_and_truncation(self):
        for raw in [tv.wav(30.1),tv.wav()[:-2]]:
            s=Session(Response(raw=raw));service=tv.v.VoiceService()
            with patch.object(b.aiohttp,'ClientSession',s.create):
                audio,reason=await service.synthesize(b.BreezeVoice(KEY,VOICE),'你好',lambda:True)
            self.assertIsNone(audio);self.assertEqual(reason,'failed')


class BreezePolicy(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.ctx=tc.Context()
        self.config=json.loads((tc.ROOT/'plugin-config.json').read_text(encoding='utf-8'))
        self.p=tc.m.Main(self.ctx,self.config);self.p.store=tc.m.Store(self.temp.name)
        self.p.ready=True;self.p.quiet=lambda:False;self.config['voice_probability_percent']=0
    async def asyncTearDown(self):await self.p.terminate();self.temp.cleanup()
    async def test_empty_key_does_not_load_edge_and_text_still_works(self):
        with patch.object(tc.m,'EdgeVoice',side_effect=AssertionError('Unexpected fallback')):
            self.assertIsNone(self.p.voice_provider())
            e=tc.Event();self.assertTrue(self.p.prepare(e,tc.CFG));await self.p.on_candidate(e)
        self.assertEqual(e.sent,['你好呀'])
    async def test_explicit_unconfigured_voice_request_is_explained_without_model_call(self):
        e=tc.Event('大肥鱼用语音说你好');self.p.prepare(e,tc.CFG);await self.p.on_candidate(e)
        self.assertEqual(e.sent,['语音服务还没配置好，我先用文字陪你聊～']);self.assertFalse(self.ctx.calls)
    async def test_key_can_be_added_after_initial_missing_configuration(self):
        self.assertIsNone(self.p.voice_provider());self.config['breeze_api_key']=KEY
        self.assertIsInstance(self.p.voice_provider(),b.BreezeVoice)
    async def test_invalid_configuration_never_silently_uses_edge(self):
        self.config['breeze_api_key']='bad\r\nkey'
        with patch.object(tc.m,'EdgeVoice',side_effect=AssertionError('Unexpected fallback')):
            self.assertIsNone(self.p.voice_provider())
    async def test_voice_failure_sends_single_text_reply_and_reserves_attempt(self):
        self.config['breeze_api_key']=KEY
        s=Session(Response(status=429))
        with patch.object(b.aiohttp,'ClientSession',s.create):
            e=tc.Event('大肥鱼用语音说你好');self.p.prepare(e,tc.CFG);await self.p.on_candidate(e)
        self.assertEqual(e.sent,['你好呀']);self.assertEqual(len(s.calls),1)
        self.assertEqual(self.p.store.used('tts_calls'),1)
    async def test_real_provider_wav_reaches_record_without_extra_qq_message(self):
        self.config['breeze_api_key']=KEY;s=Session(Response())
        with patch.object(b.aiohttp,'ClientSession',s.create):
            e=tc.Event('大肥鱼用语音说你好');self.p.prepare(e,tc.CFG);await self.p.on_candidate(e)
        self.assertEqual(len(e.sent),1);self.assertIsInstance(e.sent[0][0],tv.Record)
    async def test_key_absent_from_status_model_prompts_and_memory(self):
        self.config['breeze_api_key']=KEY;self.p.write_status()
        status=(self.p.store.directory/'status.json').read_text(encoding='utf-8')
        self.assertNotIn(KEY,status);self.assertTrue(json.loads(status)['voice_credential_configured'])
        e=tc.Event();self.p.prepare(e,tc.CFG);await self.p.on_candidate(e)
        self.assertNotIn(KEY,json.dumps(self.ctx.calls));self.assertNotIn(KEY,str(list(self.p.store.db.iterdump())))
