"""Network integration boundaries, using synthetic data and fake transport."""
import asyncio
import base64
import hashlib
import io
import json
import pathlib
import socket
import sys
import tempfile
import time
import unittest
from unittest.mock import AsyncMock, patch
from PIL import Image as PILImage
from test_companion import m, Context, Event, CFG, ROOT

n=sys.modules['companion_under_test.companion_network']

def picture():
    raw=io.BytesIO();PILImage.new('RGB',(8,8),'blue').save(raw,format='JPEG')
    return {'data_url':'data:image/jpeg;base64,'+base64.b64encode(raw.getvalue()).decode(),
            'source_url':'https://example.com/public-sticker','title':'public test'}

class FakeNetwork:
    def __init__(self):
        self.calls=[];self.fail=False;self.hook=None
        self.sources=[{'title':'公开测试资料','url':'https://example.com/public','content':'公开资料正文'}]
        self.candidates=[picture()]
    async def search(self,cfg,provider,query):
        self.calls.append(('search',query))
        if self.hook:await self.hook()
        if self.fail:raise ValueError('secret diagnostic must never be sent')
        return self.sources
    async def fetch(self,cfg,provider,url):
        self.calls.append(('fetch',url));return self.sources
    async def sticker_candidates(self,query):
        self.calls.append(('sticker',query));return self.candidates

class NetworkFlowTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.ctx=Context()
        self.p=m.Main(self.ctx,json.loads((ROOT/'plugin-config.json').read_text(encoding='utf-8')))
        self.p.store=m.Store(self.temp.name);self.p.ready=True;self.p.quiet=lambda:False
        self.p.web=FakeNetwork()
    async def asyncTearDown(self):
        await self.p.terminate();self.temp.cleanup()
    async def send(self,text):
        self.p.reply_times.clear();e=Event(text)
        self.assertTrue(self.p.prepare(e,CFG));await self.p.on_candidate(e);return e
    async def test_explicit_search_one_request_one_answer_with_verified_source(self):
        self.ctx.responses=['查到了公开资料。']
        e=await self.send('肥鱼，查一下公开测试资料')
        self.assertEqual(self.p.web.calls,[('search','公开测试资料')])
        self.assertEqual(len(self.ctx.calls),1);self.assertEqual(len(e.sent),1)
        self.assertIn('来源：https://example.com/public',e.sent[0])
        payload=json.loads(self.ctx.calls[0]['prompt'])
        self.assertEqual(payload['sources'],self.p.web.sources)
        self.assertEqual(self.ctx.calls[0]['contexts'],[]);self.assertIsNone(self.ctx.calls[0]['tools'])
        self.assertEqual(self.p.store.used('web_answer_sent'),1)
    async def test_fetch_extracts_url_without_chinese_punctuation(self):
        e=await self.send('肥鱼，读一下 https://example.com/page，概括内容')
        self.assertEqual(self.p.web.calls,[('fetch','https://example.com/page')]);self.assertEqual(len(e.sent),1)
    async def test_implicit_need_executes_single_model_action_then_answer(self):
        self.ctx.responses=['{"action":"web_search","query":"最新公开资料"}','这是查到的结果。']
        e=await self.send('肥鱼，最新的公开资料是什么？')
        self.assertEqual(self.p.web.calls,[('search','最新公开资料')]);self.assertEqual(len(self.ctx.calls),2)
        self.assertNotIn('"action"',e.sent[0])
    async def test_no_action_loop_when_answer_model_requests_another_action(self):
        self.ctx.responses=['{"action":"web_search","query":"另一个问题"}']
        e=await self.send('肥鱼，搜索公开资料')
        self.assertEqual(len(self.p.web.calls),1);self.assertEqual(len(self.ctx.calls),1)
        self.assertNotIn('"action"',e.sent[0]);self.assertIn('来源：',e.sent[0])
    async def test_network_failure_is_honest_and_does_not_backoff_chat(self):
        self.p.web.fail=True;e=await self.send('肥鱼，搜索公开资料')
        self.assertIn('联网没成功',e.sent[0]);self.assertNotIn('secret',e.sent[0]);self.assertFalse(self.ctx.calls)
        e=await self.send('肥鱼，你在干什么？');self.assertEqual(e.sent,['你好呀'])
        self.assertEqual(self.p.backoff,0)
    async def test_search_and_fetch_share_daily_quota(self):
        self.p.config['daily_web_requests']=1
        await self.send('肥鱼，搜索公开资料')
        e=await self.send('肥鱼，看看 https://example.com/page')
        self.assertEqual(len(self.p.web.calls),1);self.assertIn('查得有点多',e.sent[0])
    async def test_empty_results_never_claim_verified_answer(self):
        self.p.web.sources=[];e=await self.send('肥鱼，搜索不存在的资料')
        self.assertFalse(self.ctx.calls);self.assertIn('没查到',e.sent[0]);self.assertNotIn('来源：',e.sent[0])
    async def test_forget_during_lookup_prevents_stale_answer(self):
        async def forget():self.p.prepare(Event('忘记我的记忆'),CFG)
        self.p.web.hook=forget;e=await self.send('肥鱼，搜索公开资料')
        self.assertFalse(e.sent);self.assertFalse(self.ctx.calls)
    async def test_network_answer_does_not_extract_or_send_long_term_facts(self):
        scope=self.p.store.scope('qqai','888888888','test-A')
        self.p.store.remember(scope,'喜欢测试水果');self.ctx.responses=['公开资料已找到。']
        await self.send('肥鱼，搜索公开资料')
        self.assertEqual(len(self.ctx.calls),1)
        self.assertNotIn('喜欢测试水果',self.ctx.calls[0]['prompt'])
        self.assertEqual(self.p.store.facts(scope,'测试水果'),['喜欢测试水果'])
    async def test_web_sticker_is_vision_selected_one_image_and_cache_reused(self):
        self.ctx.responses=['{"pick":0,"safe":true,"is_sticker":true}']
        e=await self.send('肥鱼，上网找个猫猫开心表情')
        self.assertEqual(self.p.web.calls,[('sticker','猫猫开心')]);self.assertEqual(len(e.sent[0]),1)
        self.assertTrue(e.sent[0][0].file.startswith('base64://'))
        self.assertEqual(len(self.ctx.calls),1);self.assertEqual(len(self.ctx.calls[0]['image_urls']),1)
        self.assertEqual(self.p.store.used('web_sticker_sent'),1)
        stored=json.dumps(self.p.store.history(e.get_extra(m.EXTRA)['scope']))
        self.assertNotIn('base64',stored)
        e=await self.send('肥鱼，上网找个猫猫开心表情')
        self.assertEqual(len(self.p.web.calls),1);self.assertEqual(len(self.ctx.calls),1)
        self.assertEqual(self.p.store.used('web_sticker_cache_hit'),1)
    async def test_rejected_online_image_is_not_sent_or_cached(self):
        self.ctx.responses=['{"pick":0,"safe":false,"is_sticker":true}']
        e=await self.send('肥鱼，上网找个猫猫开心表情')
        self.assertIsInstance(e.sent[0],str);self.assertEqual(self.p.store.used('sticker_sent'),0)
        self.assertIsNone(self.p.web_cache.get('猫猫开心'))
    async def test_local_whale_request_uses_pinned_preferred_asset_without_network(self):
        e=await self.send('发个大肥鱼开心表情')
        self.assertFalse(self.p.web.calls);self.assertFalse(self.ctx.calls)
        raw=base64.b64decode(e.sent[0][0].file[9:])
        digests={hashlib.sha256(p.read_bytes()).hexdigest() for p in self.p.stickers.preferred['happy']}
        self.assertIn(hashlib.sha256(raw).hexdigest(),digests)
        self.assertEqual(self.p.stickers.preferred_count,11);self.assertEqual(self.p.stickers.count,46)
    async def test_proactive_and_ambient_cannot_start_implicit_network(self):
        await self.send('肥鱼，你觉得晚饭吃什么？')
        self.ctx.responses=['{"action":"web_search","query":"公开资料"}']
        self.p.reply_times.clear()
        for job in self.p.pending.values():job['due']=m.time.monotonic()-1
        await self.p.proactive_tick();self.assertFalse(self.p.web.calls);self.assertFalse(self.ctx.sent)
    async def test_denied_group_or_private_never_starts_network(self):
        for e in [Event('搜索公开资料',group='other'),Event('搜索公开资料',group='',kind='friend')]:
            self.assertFalse(self.p.prepare(e,CFG));await self.p.on_candidate(e);self.assertFalse(e.sent)
        self.assertFalse(self.p.web.calls);self.assertFalse(self.ctx.calls)
    async def test_private_model_action_is_rejected_without_diagnostic_leak(self):
        self.ctx.responses=['{"action":"web_search","query":"手机号13800138000"}']
        e=await self.send('肥鱼，帮我处理下这个问题')
        self.assertFalse(self.p.web.calls);self.assertNotIn('13800138000',e.sent[0])

class NetworkBoundaryTest(unittest.IsolatedAsyncioTestCase):
    async def test_online_image_search_uses_meme_collection_and_downloads_at_most_three(self):
        import html
        raw=base64.b64decode(picture()['data_url'].split(',',1)[1])
        rows=[{'murl':'https://www.2008php.com/stock.jpg','purl':'https://example.com/stock','t':'猫照片'}]
        rows += [{'murl':'https://example.com/'+str(i)+'.jpg','purl':'https://example.com/page','t':'猫咪表情包'} for i in range(5)]
        page=''.join('<a m="'+html.escape(json.dumps(v),quote=True)+'">' for v in rows).encode()
        transport=AsyncMock(side_effect=[page,raw,raw,raw])
        with patch.object(n,'public_get',transport):
            result=await n.NetworkClient().sticker_candidates('猫猫开心')
        from urllib.parse import parse_qs,urlsplit
        query=parse_qs(urlsplit(transport.call_args_list[0].args[0]).query)
        self.assertEqual(query['q'],['猫咪表情包']);self.assertEqual(len(result),3)
        self.assertEqual(transport.await_count,4)
        self.assertFalse(any('2008php' in call.args[0] for call in transport.call_args_list))

    async def test_public_url_rejects_local_credentials_and_non_http(self):
        for url in ['http://127.0.0.1/a','http://169.254.169.254/a','http://[::1]/',
                    'http://2130706433/','http://0x7f000001/','http://localhost/','https://a.local/',
                    'https://user:pass@example.com/','https://example.com:22/','file:///etc/passwd']:
            self.assertFalse(n.public_url(url),url)
        self.assertTrue(n.public_url('https://example.com/public'))
        self.assertTrue(n.public_url('https://[2606:4700:4700::1111]/'))
    async def test_resolver_rejects_mixed_public_and_private_dns_answers(self):
        loop=asyncio.get_running_loop()
        rows=[(socket.AF_INET,socket.SOCK_STREAM,6,'',('8.8.8.8',443)),
              (socket.AF_INET,socket.SOCK_STREAM,6,'',('127.0.0.1',443))]
        with patch.object(loop,'getaddrinfo',AsyncMock(return_value=rows)):
            with self.assertRaises(ValueError):await n.PublicResolver().resolve('example.com',443)
    async def test_router_distinguishes_local_online_negative_and_howto(self):
        labels=['开心','点赞'];topics=['大肥鱼','肥鱼','小鲸鱼']
        for text in ['发个开心表情','发个大肥鱼开心表情','不要找表情','怎么搜表情包']:
            self.assertIsNone(n.infer_action(text,labels,topics),text)
        self.assertEqual(n.infer_action('上网找个猫猫开心表情',labels,topics),{'action':'find_sticker','query':'猫猫开心'})
        self.assertEqual(n.infer_action('搜索公开资料',labels,topics),{'action':'web_search','query':'公开资料'})
        self.assertIsNone(n.parse_action({'action':'web_search','query':'我的密码是测试'}))
    async def test_only_existing_deepseek_credentials_allowed(self):
        cfg={'provider':[{'id':'test','provider_source_id':'s'}],
             'provider_sources':[{'id':'s','api_base':'https://api.deepseek.com','key':['synthetic-key']}]}
        self.assertEqual(n.NetworkClient.credentials(cfg,'test')['Authorization'],'Bearer synthetic-key')
        cfg['provider_sources'][0]['api_base']='https://api.deepseek.com.evil.example/'
        with self.assertRaises(ValueError):n.NetworkClient.credentials(cfg,'test')
    async def test_image_parser_rejects_private_and_preserves_source(self):
        import html
        parser=n.ImageSearchParser()
        for ref in ['http://127.0.0.1/x','https://example.com/public.jpg']:
            parser.feed('<a m="'+html.escape(json.dumps({'murl':ref,'purl':'https://example.com/page'}),quote=True)+'">')
        self.assertEqual(len(parser.items),1);self.assertEqual(parser.items[0]['source_url'],'https://example.com/page')
    async def test_cache_integrity_expiry_bounds_and_malformed_index(self):
        with tempfile.TemporaryDirectory() as d:
            cache=n.WebStickerCache(d);cache.put('公开测试',picture());self.assertIsNotNone(cache.get('公开测试'))
            stored=json.loads((pathlib.Path(d)/'index.json').read_text())
            self.assertNotIn('公开测试',json.dumps(stored,ensure_ascii=False))
            cache.entries[0]['stamp']=time.time()-8*86400;self.assertIsNone(cache.get('公开测试'))
            cache.entries[0]['stamp']=time.time();(pathlib.Path(d)/cache.entries[0]['file']).write_bytes(b'tampered')
            self.assertIsNone(cache.get('公开测试'))
            (pathlib.Path(d)/'index.json').write_text('[1,null,{"stamp":"bad"}]')
            self.assertEqual(n.WebStickerCache(d).entries,[])
