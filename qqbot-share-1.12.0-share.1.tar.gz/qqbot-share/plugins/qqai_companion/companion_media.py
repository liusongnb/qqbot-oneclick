"""Bounded in-memory QQ image input and pinned local sticker assets."""
from __future__ import annotations

import asyncio
import base64
import hashlib
import io
import json
from pathlib import Path
import re
from urllib.parse import unquote, urljoin, urlsplit

MAX_BYTES=8*1024**2
MAX_PIXELS=20_000_000
STICKER=re.compile(r'^\[STICKER:([a-z][a-z0-9_]{0,29})\]$')
FALLBACK={'happy':'嘿嘿～','approval':'好耶！','question':'嗯？','surprised':'哇！',
          'apology':'抱歉啦。','surrender':'好吧好吧～','food':'想吃～','shy':'有点不好意思啦。','interaction':'我在呢～','sad':'呜～'}


def trusted_qq_url(ref):
    try:
        value=urlsplit(ref);host=(value.hostname or '').lower()
        return (value.scheme in ('http','https') and not value.username and not value.password
                and value.port in (None,80,443)
                and any(host==domain or host.endswith('.'+domain) for domain in ('qq.com','qq.com.cn','qpic.cn','qlogo.cn')))
    except ValueError:
        return False


def normalize_image(raw):
    from PIL import Image,ImageOps
    if not raw or len(raw)>MAX_BYTES:
        raise ValueError('image_size')
    with Image.open(io.BytesIO(raw)) as image:
        if image.width*image.height>MAX_PIXELS or image.format not in ('JPEG','PNG','GIF','WEBP'):
            raise ValueError('image_format_or_pixels')
        image.seek(0)
        image.draft('RGB',(1600,1600))
        image=ImageOps.exif_transpose(image)
        image.thumbnail((1600,1600))
        image=image.convert('RGB')
        output=io.BytesIO();image.save(output,format='JPEG',quality=85,optimize=False)
    result=output.getvalue()
    if len(result)>2*1024**2:
        raise ValueError('image_normalized_size')
    return 'data:image/jpeg;base64,'+base64.b64encode(result).decode('ascii')


class ImageLoader:
    def __init__(self,local_roots=()):
        self.local_roots=[Path(p).resolve() for p in local_roots]

    async def raw(self,part):
        ref=str(getattr(part,'url','') or getattr(part,'file','') or '')
        if ref.startswith(('data:image/','base64://')):
            encoded=ref.split(',',1)[1] if ref.startswith('data:') else ref[9:]
            if len(encoded)>((MAX_BYTES+2)//3)*4:
                raise ValueError('image_size')
            return base64.b64decode(encoded,validate=True)
        if ref.startswith(('http://','https://')):
            import aiohttp
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                for _ in range(3):
                    if not trusted_qq_url(ref):
                        raise ValueError('image_host')
                    async with session.get(ref,allow_redirects=False) as response:
                        if response.status in (301,302,303,307,308):
                            ref=urljoin(ref,response.headers.get('Location',''));continue
                        if response.status!=200 or int(response.headers.get('Content-Length','0'))>MAX_BYTES:
                            raise ValueError('image_response')
                        data=bytearray()
                        async for chunk in response.content.iter_chunked(65536):
                            data.extend(chunk)
                            if len(data)>MAX_BYTES:
                                raise ValueError('image_size')
                        return bytes(data)
            raise ValueError('image_redirects')
        path=Path(unquote(urlsplit(ref).path) if ref.startswith('file://') else ref).resolve()
        if not self.local_roots or not any(path.is_relative_to(p) for p in self.local_roots):
            raise ValueError('image_path')
        if not path.is_file() or path.stat().st_size>MAX_BYTES:
            raise ValueError('image_file')
        return path.read_bytes()

    async def load(self,parts,limit=2):
        images=[];failures=0
        for part in parts[:limit]:
            try:
                raw=await asyncio.wait_for(self.raw(part),timeout=11)
                images.append(await asyncio.to_thread(normalize_image,raw))
            except asyncio.CancelledError:
                raise
            except Exception:
                failures+=1
        return images,failures


class StickerLibrary:
    def __init__(self,directory):
        self.directory=Path(directory).resolve()
        self.categories={};self.images={};self.preferred={}
        path=self.directory/'sticker_catalog.json'
        if not path.is_file():
            return
        try:
            catalog=json.loads(path.read_text(encoding='utf-8'))
            for category,label in catalog['categories'].items():
                if STICKER.fullmatch('[STICKER:'+category+']') and category in FALLBACK:
                    self.categories[category]=str(label)[:12]
            for item in catalog['images'][:100]:
                category=item['category'];path=self.directory/item['file']
                if category not in self.categories or path.is_symlink() or not path.resolve().is_relative_to(self.directory/'stickers'):
                    continue
                if path.is_file() and path.stat().st_size<=1024**2:
                    raw=path.read_bytes()
                    if hashlib.sha256(raw).hexdigest()==item['sha256']:
                        self.images.setdefault(category,[]).append(path)
                        if item.get('pack')=='whale-chan':
                            self.preferred.setdefault(category,[]).append(path)
            self.categories={k:v for k,v in self.categories.items() if self.images.get(k)}
        except (OSError,ValueError,KeyError,TypeError):
            self.categories={};self.images={};self.preferred={}

    @property
    def count(self):
        return sum(map(len,self.images.values()))

    @property
    def preferred_count(self):
        return sum(map(len,self.preferred.values()))

    def catalog_prompt(self):
        return json.dumps({k:{'label':v,'count':len(self.images[k]),'whale_chan':len(self.preferred.get(k,[]))} for k,v in self.categories.items()},ensure_ascii=False)

    def requested_category(self,text):
        for category,label in self.categories.items():
            if label in text or category in text.lower():
                return category
        synonyms={'高兴':'happy','笑':'happy','夸':'approval','赞':'approval','问号':'question',
                  '震惊':'surprised','抱歉':'apology','认输':'surrender','吃':'food','脸红':'shy','哭':'sad','难过':'sad'}
        return next((category for word,category in synonyms.items() if word in text and category in self.categories),'happy')

    def pick(self,category,index=0):
        choices=self.preferred.get(category) or self.images.get(category,[])
        return choices[index%len(choices)] if choices else None

    @staticmethod
    def strip_markers(reply):
        return re.sub(r'\[STICKER:[^\]\n]{0,100}\]','',reply).strip()
