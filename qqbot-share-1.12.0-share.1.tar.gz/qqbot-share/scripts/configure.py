"""Prepare a fresh, recipient-owned instance. Never import an existing data tree."""
import copy
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import sys
from urllib.parse import urlsplit

BASE=Path(__file__).resolve().parents[1]

def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    path.chmod(0o600)

def ask(label,default='',secret=False):
    prompt=label+(f' [{default}]' if default else '')+': '
    value=getpass.getpass(prompt) if secret else input(prompt)
    return value.strip() or default

def validate_group(value):
    if not re.fullmatch(r'[1-9][0-9]{3,19}',value):raise ValueError('群号格式不正确')
    return value

def prepare(root,answers):
    root=Path(root)
    if root.resolve()==Path('/opt/qq-ai') or (root/'astrbot/data').exists():
        raise ValueError('已有实例或受保护目录，拒绝覆盖')
    group=validate_group(answers['group'])
    api=answers.get('api_base','https://api.deepseek.com/v1')
    parts=urlsplit(api)
    if parts.scheme!='https' or not parts.hostname or parts.username or parts.password:
        raise ValueError('模型接口必须是没有内嵌账号的 HTTPS 地址')
    if not answers.get('api_key'):raise ValueError('模型 API Key 不能为空')
    engine=answers.get('voice_engine','edge_tts')
    if engine not in ('breeze_blue','edge_tts'):raise ValueError('未知语音引擎')
    if engine=='breeze_blue' and not (answers.get('breeze_api_key') and re.fullmatch(r'voc_[A-Za-z0-9]+',answers.get('breeze_voice_id',''))):
        raise ValueError('BreezeBlue 需要自己的 API Key 和音色 ID')
    exemptions=[v for v in re.split(r'[,，\s]+',answers.get('exemptions','')) if v]
    for value in exemptions:validate_group(value)
    cfg=json.loads((BASE/'templates/core-config.json').read_text(encoding='utf-8'))
    password='Qq'+secrets.token_urlsafe(24)+'8';salt=secrets.token_hex(16)
    onebot=secrets.token_urlsafe(48);nap_token=secrets.token_urlsafe(48)
    cfg['dashboard'].update(enable=True,username='qqbot-admin',
        password=hashlib.md5(password.encode()).hexdigest(),
        pbkdf2_password='pbkdf2_sha256$600000$'+salt+'$'+hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),600000).hex(),
        jwt_secret=secrets.token_urlsafe(48),password_storage_upgraded=True,password_change_required=True)
    cfg['platform'][0].update(enable=True,ws_reverse_token=onebot)
    cfg['platform_settings'].update(id_whitelist=[group],enable_id_white_list=True)
    cfg['platform_settings']['rate_limit'].update(count=6)
    cfg['plugin_set']=['qqai_companion'];cfg['wake_prefix']=['大肥鱼','小鲸鱼','鲸鲸']
    source={'id':'share-source','provider':'openai','type':'openai_chat_completion',
        'provider_type':'chat_completion','enable':True,'key':[answers['api_key']],
        'api_base':api,'timeout':60,'proxy':'','custom_headers':{}}
    cfg['provider_sources']=[source]
    cfg['provider']=[{'id':'share-chat','provider_source_id':'share-source','enable':True,
        'model':answers.get('model','deepseek-chat'),'modalities':['text','image'],'model_config':{}}]
    cfg['agent_runner']={'runner_type':'local','config':{'model':{'provider_id':'share-chat'},'persona':{'persona_id':'小鲸鱼'}}}
    data=root/'astrbot/data';save(data/'cmd_config.json',cfg)
    companion=json.loads((BASE/'templates/plugin-config.json').read_text(encoding='utf-8'))
    companion.update(allowed_groups=[group],voice_engine=engine,voice_unlimited_users=exemptions,
        breeze_api_key=answers.get('breeze_api_key',''),breeze_voice_id=answers.get('breeze_voice_id',''))
    save(data/'config/astrbot_plugin_qqai_companion_config.json',companion)
    for name,file in [('time_awareness','time-plugin-config.json'),('astrbot_plugin_reminder','reminder-plugin-config.json')]:
        values=json.loads((BASE/'templates'/file).read_text(encoding='utf-8'))
        if name=='astrbot_plugin_reminder':values['allowed_groups']=[group]
        save(data/f'config/{name}_config.json',values)
    for folder,dest in [('qqai_companion','astrbot_plugin_qqai_companion'),('time_awareness','time_awareness'),('astrbot_plugin_reminder','astrbot_plugin_reminder')]:
        shutil.copytree(BASE/'plugins'/folder,data/'plugins'/dest)
    shutil.copyfile(BASE/'templates/persona.txt',data/'share-persona.txt')
    reverse={'network':{'httpServers':[],'httpSseServers':[],'httpClients':[],'websocketServers':[],
        'websocketClients':[{'name':'share-reverse','enable':True,'url':'ws://astrbot:6199/ws',
            'messagePostFormat':'array','reportSelfMessage':False,'token':onebot,'heartInterval':30000,'reconnectInterval':30000}]},
        'musicSignUrl':'','enableLocalFile2Url':False,'parseMultMsg':False}
    save(root/'napcat/config/onebot11.json',reverse)
    save(root/'napcat/config/webui.json',{'host':'0.0.0.0','port':6099,'prefix':'','token':nap_token,
        'loginRate':3,'accessControlMode':'none','ipWhitelist':[],'ipBlacklist':[],'enableXForwardedFor':False})
    save(root/'napcat/config/napcat.json',{'fileLog':False,'consoleLog':False,'fileLogLevel':'error',
        'consoleLogLevel':'error','packetBackend':'auto','packetServer':'','o3HookMode':1,
        'bypass':dict.fromkeys(('hook','window','module','process','container','js'),False)})
    for folder in ['napcat/qq','napcat/plugins']:(root/folder).mkdir(parents=True,mode=0o700)
    for p in (root/'napcat').rglob('*'):
        if os.name!='nt':os.chown(p,1000,1000)
    if os.name!='nt':os.chown(root/'napcat',1000,1000)
    save(root/'secrets/admin-access.json',{'astrbot_username':'qqbot-admin',
        'astrbot_initial_password':password,'napcat_webui_token':nap_token})
    save(root/'instance.json',{'distribution':'qqbot-share','version':'1.12.0-share.1','group':group,'bootstrap_complete':False})
    return cfg,companion

if __name__=='__main__':
    try:
        if len(sys.argv)==3 and sys.argv[1]=='--answers-file':
            answers_file=Path(sys.argv[2])
            if os.name!='nt' and answers_file.stat().st_mode & 0o077:raise ValueError('答案文件必须设为 600 权限')
            prepare(BASE,json.loads(answers_file.read_text(encoding='utf-8')))
            print('独立配置已创建。')
            sys.exit(0)
        if len(sys.argv)!=1:raise ValueError('未知参数')
        print('小鲸鱼现有功能分享版：群聊、私聊、记忆、表情、语音、时间与提醒。')
        a={'group':ask('允许的 QQ 群号'),'api_base':ask('OpenAI 兼容接口','https://api.deepseek.com/v1'),
           'model':ask('模型名称','deepseek-chat'),'api_key':ask('模型 API Key（隐藏输入）',secret=True)}
        a['voice_engine']='breeze_blue' if ask('语音：1 免费 Edge 晓伊 / 2 BreezeBlue','1')=='2' else 'edge_tts'
        if a['voice_engine']=='breeze_blue':
            a['breeze_voice_id']=ask('你自己的 BreezeBlue 音色 ID')
            a['breeze_api_key']=ask('BreezeBlue API Key（隐藏输入）',secret=True)
        a['exemptions']=ask('聊天语音免限额 QQ 号，可留空，多个用逗号隔开')
        prepare(BASE,a)
        print('独立配置已创建；后台凭据仅保存于本实例 secrets/admin-access.json。')
    except (ValueError,EOFError,KeyboardInterrupt) as e:
        print('配置未完成：'+str(e),file=sys.stderr);sys.exit(1)
