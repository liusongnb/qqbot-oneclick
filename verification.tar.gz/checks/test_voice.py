"""Speech contracts: quotas, uncertain sends, cancellation and reloads; no network."""
import asyncio
import base64
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import wave

import test_companion as tc

m=tc.m
v=sys.modules[m.__package__+'.companion_voice']

def wav(seconds=.1):
    stream=io.BytesIO()
    with wave.open(stream,'wb') as audio:
        audio.setnchannels(1);audio.setsampwidth(2);audio.setframerate(24000)
        audio.writeframes(b'\x00\x00'*int(seconds*24000))
    return stream.getvalue()

class Provider:
    def __init__(self,raw=None):
        self.raw=wav() if raw is None else raw
        self.calls=[];self.gate=None;self.peak=0;self.running=0
    async def get_audio(self,text):
        self.calls.append(text);self.running+=1;self.peak=max(self.peak,self.running)
        try:
            if self.gate is not None:await self.gate.wait()
            if isinstance(self.raw,Exception):raise self.raw
            return self.raw
        finally:self.running-=1

class Record:
    def __init__(self,data,text=None):self.file='base64://'+data;self.text=text
    @classmethod
    def fromBase64(cls,data,**kwargs):return cls(data,kwargs.get('text'))
sys.modules['astrbot.api.message_components'].Record=Record

class VoiceTextTest(unittest.TestCase):
    def test_explicit_requests_and_negations(self):
        for text in ['发条语音','用语音说晚安','语音回复我','来个语音','请朗读这句话']:
            self.assertTrue(v.voice_intent(text),text)
        for text in ['别发语音','不要用语音回复','只用文字','这个语音怎么样','我喜欢听语音']:
            self.assertFalse(v.voice_intent(text),text)
    def test_knowledge_links_lists_secrets_and_long_replies_stay_text(self):
        for text in ['看 https://example.com','1. 第一项','```code```','[隐私已隐藏]','密码是测试','长'*121]:
            self.assertFalse(v.speakable(text),text)
        self.assertEqual(v.speakable('你好呀～🐳'),'你好呀～')
    def test_dependency_checksum_checked_before_import(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'vendor'/v.EDGE_WHEEL;path.parent.mkdir();path.write_bytes(b'wrong')
            with self.assertRaises(ValueError):v.load_edge(directory)
    def test_packaged_library_matches_fixed_distribution(self):
        path=tc.ROOT/'astrbot_plugin_qqai_companion/vendor'/v.EDGE_WHEEL
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),v.EDGE_SHA256)

class VoiceServiceTest(unittest.IsolatedAsyncioTestCase):
    async def test_valid_audio_and_single_reservation(self):
        provider=Provider();reservations=[];service=v.VoiceService()
        raw,reason=await service.synthesize(provider,'你好',lambda:reservations.append(1) or True)
        self.assertEqual(reason,'ready');self.assertEqual(raw,wav());self.assertEqual(reservations,[1])
    async def test_invalid_truncated_overlong_and_oversized_output_rejected(self):
        for raw in [b'not audio',wav()[:-2],wav(30.1),b'x'*(3*1024**2+1),'unexpected path']:
            service=v.VoiceService();audio,reason=await service.synthesize(Provider(raw),'你好',lambda:True)
            self.assertIsNone(audio);self.assertEqual(reason,'failed')
    async def test_quota_blocks_request_without_contacting_service(self):
        provider=Provider();raw,reason=await v.VoiceService().synthesize(provider,'你好',lambda:False)
        self.assertIsNone(raw);self.assertEqual(reason,'quota');self.assertEqual(provider.calls,[])
    async def test_timeout_and_reload_keep_actual_inflight_concurrency_one(self):
        provider=Provider();provider.gate=asyncio.Event();state={}
        service=v.VoiceService(timeout=.01,shared_state=state)
        raw,reason=await service.synthesize(provider,'第一条',lambda:True)
        self.assertIsNone(raw);self.assertEqual(reason,'timeout');self.assertTrue(service.busy)
        service.close();replacement=v.VoiceService(shared_state=state)
        raw,reason=await replacement.synthesize(provider,'第二条',lambda:self.fail('Must not reserve'))
        self.assertIsNone(raw);self.assertEqual(reason,'unavailable')
        job=service.pending;provider.gate.set();await job;await asyncio.sleep(0)
        self.assertFalse(replacement.busy);self.assertEqual(provider.peak,1);self.assertEqual(provider.calls,['第一条'])
    async def test_cancelling_handler_does_not_release_inflight_guard(self):
        provider=Provider();provider.gate=asyncio.Event();service=v.VoiceService()
        handler=asyncio.create_task(service.synthesize(provider,'你好',lambda:True))
        await asyncio.sleep(0);await asyncio.sleep(0);handler.cancel()
        with self.assertRaises(asyncio.CancelledError):await handler
        self.assertTrue(service.busy);job=service.pending;provider.gate.set();await job
        await asyncio.sleep(0);self.assertFalse(service.busy)
    async def test_failed_service_has_scoped_backoff(self):
        service=v.VoiceService();provider=Provider(RuntimeError('unavailable'))
        await service.synthesize(provider,'你好',lambda:True)
        raw,reason=await service.synthesize(provider,'再来',lambda:self.fail('Backoff reserves nothing'))
        self.assertIsNone(raw);self.assertEqual(reason,'unavailable');self.assertEqual(len(provider.calls),1)
    async def test_explicit_speech_also_delays_next_automatic_speech(self):
        service=v.VoiceService();await service.synthesize(Provider(),'你好',lambda:True)
        with patch.object(v.random,'random',return_value=0):self.assertFalse(service.auto_due(10,1800))

class VoicePolicyTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.ctx=tc.Context()
        self.p=m.Main(self.ctx,json.loads((tc.ROOT/'plugin-config.json').read_text(encoding='utf-8')))
        self.p.store=m.Store(self.temp.name);self.p.ready=True;self.p.quiet=lambda:False
        self.p.config['voice_probability_percent']=0
        self.provider=Provider();self.p.edge_provider=self.provider;self.p.edge_provider_attempted=True
    async def asyncTearDown(self):
        if self.provider.gate is not None:self.provider.gate.set()
        if self.p.voice and self.p.voice.pending:await self.p.voice.pending
        await self.p.terminate();self.temp.cleanup()
    async def run_message(self,text='大肥鱼，用语音说晚安',**kwargs):
        event=tc.Event(text,**kwargs);self.assertTrue(self.p.prepare(event,tc.CFG));await self.p.on_candidate(event)
        return event
    async def test_explicit_voice_is_one_record_with_text_history(self):
        event=await self.run_message();self.assertEqual(len(event.sent),1)
        self.assertIsInstance(event.sent[0][0],Record)
        self.assertEqual(base64.b64decode(event.sent[0][0].file[9:]),wav())
        self.assertEqual(self.p.store.used('tts_calls'),1);self.assertEqual(self.p.store.used('voice_sent'),1)
        scope=self.p.store.scope('qqai','888888888','test-A')
        self.assertEqual(self.p.store.history(scope)[-1]['content'],'你好呀')
        self.assertTrue(event.stopped)
    async def test_plain_explicit_request_does_not_need_alias(self):
        event=await self.run_message('发条语音');self.assertIsInstance(event.sent[0][0],Record)
    async def test_disabled_voice_does_not_claim_it_can_send_voice(self):
        self.p.config['voice_enabled']=False;event=await self.run_message()
        self.assertIn('还没配置好',event.sent[0]);self.assertFalse(self.provider.calls)
        self.assertIn('不能生成新图片、发语音',await self.p.reply_system(event))
    async def test_enabled_voice_prompt_explains_real_capability(self):
        system=await self.p.reply_system(tc.Event())
        self.assertIn('偶尔用短语音',system);self.assertIn('不能识别群友发来的语音',system)
    async def test_provider_failure_falls_back_once_without_chat_backoff(self):
        self.provider.raw=RuntimeError('temporary');event=await self.run_message()
        self.assertEqual(event.sent,['你好呀']);self.assertEqual(self.p.store.used('voice_fallback_failed'),1)
        self.assertEqual(self.p.backoff,0)
    async def test_quota_exhaustion_preserves_full_text_answer(self):
        self.assertTrue(self.p.store.reserve_voice_chars(2000,2000))
        event=await self.run_message();self.assertEqual(event.sent,['你好呀']);self.assertFalse(self.provider.calls)
    async def test_long_or_linked_replies_do_not_get_truncated_for_speech(self):
        for reply in ['长'*110,'查看 https://example.com']:
            self.p.reply_times.clear();self.ctx.responses=[reply]
            event=await self.run_message();self.assertEqual(event.sent,[reply])
        self.assertFalse(self.provider.calls)
    async def test_ordinary_reply_can_use_probability_but_negation_stays_text(self):
        self.p.config['voice_probability_percent']=10
        with patch.object(v.random,'random',return_value=0):event=await self.run_message('大肥鱼，你好呀')
        self.assertIsInstance(event.sent[0][0],Record)
        self.p.reply_times.clear()
        with patch.object(v.random,'random',return_value=0):event=await self.run_message('大肥鱼，不要语音，用文字回答')
        self.assertEqual(event.sent,['你好呀']);self.assertEqual(len(self.provider.calls),1)
    async def test_private_and_other_group_remain_denied(self):
        for event in [tc.Event('发条语音',group='',kind='friend'),tc.Event('发条语音',group='another')]:
            self.assertFalse(self.p.prepare(event,tc.CFG));await self.p.on_candidate(event);self.assertFalse(event.sent)
        self.assertFalse(self.provider.calls)
    async def test_forgetting_during_synthesis_cancels_old_reply(self):
        self.provider.gate=asyncio.Event();event=tc.Event('大肥鱼，用语音说你好')
        self.p.prepare(event,tc.CFG);job=asyncio.create_task(self.p.on_candidate(event))
        for _ in range(20):
            if self.provider.calls:break
            await asyncio.sleep(.001)
        forgotten=tc.Event('忘记我的记忆');self.assertTrue(self.p.prepare(forgotten,tc.CFG))
        await self.p.on_candidate(forgotten);self.provider.gate.set();await job
        self.assertFalse(event.sent);self.assertEqual(self.p.store.used('skip_stale_voice'),1)
    async def test_uncertain_voice_send_is_not_duplicated_or_global_backoff(self):
        event=tc.Event('发条语音')
        async def failed_send(result):raise TimeoutError('Unknown delivery')
        event.send=failed_send;self.p.prepare(event,tc.CFG);await self.p.on_candidate(event)
        self.assertEqual(self.p.store.used('voice_send_failed'),1);self.assertEqual(self.p.backoff,0)
        next_event=await self.run_message('大肥鱼，你好呀');self.assertEqual(next_event.sent,['你好呀'])

