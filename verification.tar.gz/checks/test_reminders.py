"""Synthetic time context, durable reminder ownership, dedup and quota contracts."""
import asyncio
from datetime import datetime, timedelta
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import time
import types
import unittest
from unittest.mock import patch

import test_companion as tc
import test_private as tp
import test_voice as tv

m=tc.m
bridge=sys.modules[m.__package__+'.companion_reminders']
ROOT=tc.ROOT
spec=importlib.util.spec_from_file_location('qqai_managed_reminder_test',ROOT/'plugins/astrbot_plugin_reminder/main.py',submodule_search_locations=[str(ROOT/'plugins/astrbot_plugin_reminder')])
backend_module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=backend_module;spec.loader.exec_module(backend_module)

class MessageChain:
    def __init__(self):self.chain=[]
class Plain:
    def __init__(self,text):self.text=text
class At:
    def __init__(self,qq):self.qq=str(qq)
sys.modules['astrbot.api.event'].MessageChain=MessageChain
sys.modules['astrbot.api.message_components'].Plain=Plain
sys.modules['astrbot.api.message_components'].At=At


class BackendStoreTest(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.db=backend_module.ManagedDatabase(str(Path(self.temp.name)/'schedules.db'))
    def tearDown(self):self.db.close();self.temp.cleanup()
    def create(self,**kw):
        values=dict(session='qqai:FriendMessage:20001',sender='20001',title='喝水',due=time.time()+600,
                    recurrence='none',request_key='synthetic-request',limit=20);values.update(kw)
        result=self.db.create(**values);return self.db.get_schedule_by_id(result['id']),result
    def test_replayed_message_and_same_event_do_not_create_duplicate_tasks(self):
        a,_=self.create();b,result=self.create();self.assertEqual(a.id,b.id);self.assertTrue(result['duplicate'])
        c,result=self.create(request_key='different-message',due=a.trigger_time+15)
        self.assertEqual(c.id,a.id);self.assertTrue(result['duplicate'])
    def test_other_users_sessions_and_separate_times_are_distinct(self):
        a,_=self.create();b,_=self.create(request_key='b',sender='20002',session='qqai:FriendMessage:20002')
        c,_=self.create(request_key='c',session='qqai:GroupMessage:888888888')
        d,_=self.create(request_key='d',due=a.trigger_time+120)
        self.assertEqual(len({a.id,b.id,c.id,d.id}),4)
    def test_scope_filters_list_and_cancel(self):
        a,_=self.create();self.assertEqual(self.db.scoped_pending('qqai:GroupMessage:888888888','20001'),[])
        self.assertFalse(self.db.cancel_scoped(a.unified_msg_origin,'20002',a.short_id))
        self.assertTrue(self.db.cancel_scoped(a.unified_msg_origin,'20001',a.short_id))
    def test_claim_survives_reload_and_cannot_be_acquired_twice(self):
        a,_=self.create();self.assertTrue(self.db.claim(a));self.assertFalse(self.db.claim(a))
        self.db.close();self.db=backend_module.ManagedDatabase(str(Path(self.temp.name)/'schedules.db'))
        self.assertFalse(self.db.claim(a));self.assertTrue(self.db.recover_claim(a,time.time()))
        self.assertEqual(self.db.get_schedule_by_id(a.id).status,'uncertain_after_reload')
    def test_recurring_claim_advances_to_next_occurrence_once(self):
        a,_=self.create(recurrence='daily');self.db.claim(a);self.db.finish(a,'sent',a.trigger_time+1)
        b=self.db.get_schedule_by_id(a.id);self.assertEqual(b.status,'pending');self.assertGreater(b.trigger_time,a.trigger_time)
        self.assertTrue(self.db.claim(b));self.assertFalse(self.db.claim(b))
    def test_month_end_recurrence_returns_to_original_anchor_day(self):
        due=datetime(2027,1,31,9,tzinfo=bridge.CST).timestamp();a,_=self.create(due=due,recurrence='monthly')
        feb=backend_module.next_occurrence(a,due+1);self.assertEqual(datetime.fromtimestamp(feb,bridge.CST).day,28)
        a.trigger_time=feb;mar=backend_module.next_occurrence(a,feb+1);self.assertEqual(datetime.fromtimestamp(mar,bridge.CST).day,31)


class ReminderFlowTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.ctx=tp.Context()
        self.cfg=json.loads((ROOT/'plugin-config.json').read_text(encoding='utf-8'))
        self.p=m.Main(self.ctx,self.cfg);self.p.store=m.Store(self.temp.name);self.p.ready=True;self.p.quiet=lambda:False
        self.cfg['voice_probability_percent']=0
        self.backend=backend_module.ReminderPlugin(self.ctx,{'enabled':True,'max_reminders':20,'allowed_groups':['888888888']})
        self.backend.db=backend_module.ManagedDatabase(str(Path(self.temp.name)/'reminders.db'))
        self.ctx.plugins={'astrbot_plugin_reminder':self.backend}
        self.ctx.get_registered_star=lambda name:types.SimpleNamespace(star_cls=self.ctx.plugins.get(name))
        self.p.private_access=tp.PrivateAccess(self.ctx,self.p.store,['888888888']);await self.p.private_access.maintain(force=True)
        self.provider=tv.Provider();self.p.edge_provider=self.provider;self.p.edge_provider_attempted=True
    async def asyncTearDown(self):
        await self.p.terminate();self.backend.db.close();self.temp.cleanup()
    async def request(self,text='提醒我2分钟后喝水',private=True,sender='20001'):
        self.p.reply_times.clear()
        e=tp.PrivateEvent(text,sender=sender) if private else tc.Event(text,sender=sender)
        self.assertTrue(self.p.prepare(e,self.ctx.get_config(e.unified_msg_origin)))
        await self.p.on_candidate(e);return e
    def make_due(self,item=None,**kw):
        if item is None:
            values=dict(session='qqai:FriendMessage:20001',sender='20001',title='喝水',due=time.time()+60,recurrence='none',request_key=str(time.time_ns()))
            values.update(kw);result=self.backend.create_qqai_reminder(**values);item=result['item']
        self.backend.db._get_connection().execute('UPDATE schedules SET trigger_time=? WHERE id=?',(time.time()-1,item.id));self.backend.db._get_connection().commit()
        return self.backend.db.get_schedule_by_id(item.id)
    async def tick(self):await self.p.reminders.tick(tc.sys.modules['astrbot.core.platform.message_type'].MessageType)
    async def test_relative_create_is_stored_before_confirmation_without_llm_or_tts(self):
        e=await self.request();self.assertIn('记下啦',e.sent[0]);self.assertIn('R0001',e.sent[0])
        self.assertEqual(len(self.backend.db.scoped_pending(e.unified_msg_origin,'20001')),1)
        self.assertFalse(self.ctx.calls);self.assertFalse(self.provider.calls)
    async def test_natural_create_uses_model_budget_and_fixed_actual_recipient(self):
        when=datetime.now(bridge.CST)+timedelta(hours=1)
        self.ctx.responses=[json.dumps({'action':'create','fire_at':when.isoformat(),'event':'开会','recurrence':'none','target_id':'999999'})]
        e=await self.request('下周一早八叫我开会');items=self.backend.db.scoped_pending(e.unified_msg_origin,'20001')
        self.assertEqual(items[0].target_id,'20001');self.assertEqual(self.p.store.used('llm_calls'),1)
    async def test_ambiguous_or_bad_model_output_does_not_claim_success(self):
        self.ctx.responses=['{"action":"clarify"}'];e=await self.request('提醒我明天开会')
        self.assertIn('几点',e.sent[0]);self.assertFalse(self.backend.db.scoped_pending(e.unified_msg_origin,'20001'))
    async def test_duplicate_create_returns_existing_id(self):
        await self.request();e=await self.request();self.assertIn('不重复',e.sent[0])
        self.assertEqual(len(self.backend.db.scoped_pending(e.unified_msg_origin,'20001')),1)
    async def test_list_and_cancel_only_current_owner_and_session(self):
        await self.request();e=await self.request('查看提醒');self.assertIn('R0001',e.sent[0])
        e=await self.request('取消提醒 R0001',sender='20002');self.assertIn('没找到',e.sent[0])
        e=await self.request('取消提醒 R0001');self.assertIn('已取消',e.sent[0])
    async def test_text_is_default_and_one_occurrence_only_calls_transport_once(self):
        item=self.make_due()
        with patch.object(tv.v.random,'random',return_value=.9):await self.tick();await self.tick()
        self.assertEqual(len(self.ctx.sent),1);self.assertIsInstance(self.ctx.sent[0][1].chain[0],Plain)
        self.assertEqual(self.backend.db.get_schedule_by_id(item.id).status,'triggered')
        self.assertEqual(self.p.store.used('reminder_text_sent'),1)
    async def test_plentiful_budget_can_select_one_voice_instead_of_text(self):
        self.make_due()
        with patch.object(tv.v.random,'random',return_value=0):await self.tick()
        self.assertEqual(len(self.ctx.sent),1);self.assertEqual(len(self.ctx.sent[0][1].chain),1)
        self.assertIsInstance(self.ctx.sent[0][1].chain[0],tv.Record)
        self.assertGreater(self.p.store.used('tts_chars'),0);self.assertEqual(self.p.store.used('reminder_voice_sent'),1)
    async def test_low_budget_stays_text_without_synthesis(self):
        self.p.store.reserve_voice_chars(600,2000);self.make_due()
        with patch.object(tv.v.random,'random',return_value=0):await self.tick()
        self.assertFalse(self.provider.calls);self.assertIsInstance(self.ctx.sent[0][1].chain[0],Plain)
    async def test_reminder_tts_still_uses_public_budget_for_chat_exempt_account(self):
        self.ctx.rows.append({'user_id':20003});await self.p.private_access.maintain(force=True)
        self.make_due(session='qqai:FriendMessage:20003',sender='20003')
        with patch.object(tv.v.random,'random',return_value=0):await self.tick()
        self.assertGreater(self.p.store.used('tts_chars'),0);self.assertEqual(self.p.store.used('tts_unlimited_chars'),0)
    async def test_tts_failure_falls_back_to_single_text_before_any_send(self):
        self.provider.raw=RuntimeError('synthetic');self.make_due()
        with patch.object(tv.v.random,'random',return_value=0):await self.tick()
        self.assertEqual(len(self.ctx.sent),1);self.assertIsInstance(self.ctx.sent[0][1].chain[0],Plain)
    async def test_uncertain_send_is_never_retried_or_fallback_sent(self):
        calls=[]
        async def send(*args):calls.append(args);raise TimeoutError('synthetic')
        self.ctx.send_message=send;item=self.make_due();self.cfg['reminder_tts_enabled']=False
        await self.tick();await self.tick();self.assertEqual(len(calls),1)
        self.assertEqual(self.backend.db.get_schedule_by_id(item.id).status,'uncertain')
    async def test_member_revoked_before_due_does_not_receive_private_reminder(self):
        item=self.make_due();self.p.private_access.members=frozenset({'20002'})
        await self.tick();self.assertFalse(self.ctx.sent);self.assertEqual(self.backend.db.get_schedule_by_id(item.id).status,'blocked')
    async def test_temporarily_offline_membership_defers_without_consuming_occurrence(self):
        item=self.make_due();self.p.private_access.checked_at-=91;await self.tick()
        self.assertFalse(self.ctx.sent);self.assertEqual(self.backend.db.get_schedule_by_id(item.id).status,'pending')
        await self.p.private_access.maintain(force=True);self.cfg['reminder_tts_enabled']=False;await self.tick()
        self.assertEqual(len(self.ctx.sent),1)
    async def test_old_occurrence_is_not_replayed_on_recovery(self):
        item=self.make_due();self.backend.db.claim(item);await self.tick()
        self.assertFalse(self.ctx.sent);self.assertEqual(self.backend.db.get_schedule_by_id(item.id).status,'uncertain_after_reload')
    async def test_long_overdue_occurrence_is_missed_without_late_spam(self):
        item=self.make_due();conn=self.backend.db._get_connection();conn.execute('UPDATE schedules SET trigger_time=? WHERE id=?',(time.time()-301,item.id));conn.commit()
        await self.tick();self.assertFalse(self.ctx.sent);self.assertEqual(self.backend.db.get_schedule_by_id(item.id).status,'missed')
    async def test_group_reminder_has_owner_at_and_single_message(self):
        self.make_due(session='qqai:GroupMessage:888888888');self.cfg['reminder_tts_enabled']=False;await self.tick()
        umo,chain=self.ctx.sent[0];self.assertEqual(umo,'qqai:GroupMessage:888888888')
        self.assertIsInstance(chain.chain[0],At);self.assertEqual(chain.chain[0].qq,'20001');self.assertEqual(len(self.ctx.sent),1)


class TimeBridgeTest(unittest.IsolatedAsyncioTestCase):
    async def test_time_is_transient_cached_per_turn_and_scope_keys_are_opaque(self):
        with tempfile.TemporaryDirectory() as d:
            ctx=tc.Context();p=m.Main(ctx,{'time_awareness_enabled':True});p.store=m.Store(d)
            calls=[];records=[]
            plugin=types.SimpleNamespace(time_context=types.SimpleNamespace(now=lambda:datetime(2026,10,26,12,tzinfo=bridge.CST),
                build_dynamic=lambda **kw:calls.append(kw) or '<SYSTEM_REMINDER>2026-10-26 12:00 星期一</SYSTEM_REMINDER>'),
                last_chat_tracker=types.SimpleNamespace(record_user=lambda *a:records.append(a),record_ai=lambda *a:records.append(a)))
            ctx.get_registered_star=lambda name:types.SimpleNamespace(star_cls=plugin)
            e=tc.Event(sender='20001');first=p.time_bridge.system_context(e);second=p.time_bridge.system_context(e)
            self.assertEqual(first,second);self.assertEqual(len(calls),1);self.assertEqual(len(records),1)
            self.assertNotIn('qqai:',calls[0]['session']);self.assertEqual(len(calls[0]['session']),64)
            self.assertNotIn('SYSTEM_REMINDER',str(list(p.store.db.iterdump())));p.store.close()
