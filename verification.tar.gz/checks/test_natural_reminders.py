"""Natural Chinese reminder intent, absolute time, clarification and session isolation."""
from contextlib import contextmanager
from datetime import datetime, timedelta
import json
import sys
import time
import unittest
from unittest.mock import patch

import test_companion as tc
import test_reminders as tr

bridge=tr.bridge
parser=sys.modules[tc.m.__package__+'.companion_reminder_parse']
NOW=datetime(2026,10,26,10,0,tzinfo=bridge.CST)

@contextmanager
def at(when=NOW):
    class Clock(datetime):
        @classmethod
        def now(cls,tz=None):return when.astimezone(tz) if tz else when.replace(tzinfo=None)
    with patch.object(bridge,'datetime',Clock),patch.object(time,'time',return_value=when.timestamp()):yield


class ChineseTimeTest(unittest.TestCase):
    def test_complete_chinese_requests_extract_date_clock_and_activity(self):
        cases=[
            ('今天下午1点提醒我上课',0,13,0,'上课'),
            ('今天下午一点提醒我上课',0,13,0,'上课'),
            ('提醒我今天下午一点上课',0,13,0,'上课'),
            ('我今天下午一点要上课，到时候记得叫我',0,13,0,'上课'),
            ('明天下午一点半提醒我上课',1,13,30,'上课'),
            ('明天13:00提醒我上课',1,13,0,'上课'),
            ('今晚九点一刻提醒我吃药',0,21,15,'吃药'),
            ('明早八点提醒我起床',1,8,0,'起床'),
            ('后天下午两点三十分提醒我开会',2,14,30,'开会'),
            ('今天下午1点提醒我“上课”',0,13,0,'上课'),
        ]
        for text,days,hour,minute,event in cases:
            with self.subTest(text=text):
                self.assertTrue(parser.explicit_request(text))
                data=parser.parse_local(text,NOW)
                self.assertEqual(data['action'],'create')
                self.assertEqual(datetime.fromisoformat(data['fire_at']),
                    (NOW+timedelta(days=days)).replace(hour=hour,minute=minute))
                self.assertEqual(data['event'],event)
    def test_relative_chinese_numerals_and_half_hour(self):
        for text,minutes in [('十五分钟后提醒我喝水',15),('过半小时叫我喝水',30),('提醒我两小时后喝水',120)]:
            with self.subTest(text=text):
                data=parser.parse_local(text,NOW)
                self.assertEqual(datetime.fromisoformat(data['fire_at']),NOW+timedelta(minutes=minutes))
                self.assertEqual(data['event'],'喝水')
    def test_missing_time_preserves_known_day_and_activity(self):
        data=parser.parse_local('提醒我明天上课',NOW)
        self.assertEqual(data['missing'],['time']);self.assertEqual(data['event'],'上课')
        self.assertEqual(parser.clarification(data,'提醒我明天上课',NOW),'明天几点提醒你上课呀？')
    def test_ambiguous_multiple_clocks_and_offsets_require_semantic_model(self):
        for text in ['今天1点还是明天2点提醒我上课','明天下午一点上课，提前十分钟提醒我','下周一早八叫我上课']:
            self.assertIsNone(parser.parse_local(text,NOW))
    def test_reports_and_whole_quoted_requests_do_not_schedule(self):
        for text in ['他说今天下午一点提醒我上课','她对我说“明天一点提醒我”','“今天下午一点提醒我上课”','假如我说今天一点提醒我上课']:
            self.assertFalse(parser.explicit_request(text),text)
    def test_unknown_calendar_words_are_not_silently_treated_as_today(self):
        for text in ['昨天13点提醒我上课','下个月1号13点提醒我交房租','27号13点提醒我上课','明年十月一点提醒我上课','今晚十二点提醒我睡觉']:
            self.assertIsNone(parser.parse_local(text,NOW),text)
    def test_explicit_noon_and_midnight_are_distinct(self):
        noon=parser.parse_local('明天上午十二点提醒我吃饭',NOW)
        midnight=parser.parse_local('明天凌晨十二点提醒我睡觉',NOW)
        self.assertEqual(datetime.fromisoformat(noon['fire_at']).hour,12)
        self.assertEqual(datetime.fromisoformat(midnight['fire_at']).hour,0)
    def test_daily_and_weekday_schedules_advance_to_future(self):
        now=NOW.replace(hour=15)
        data=parser.parse_local('每天13:00提醒我上课',now)
        self.assertEqual(datetime.fromisoformat(data['fire_at']),NOW.replace(day=27,hour=13))
        friday=NOW.replace(day=30,hour=15)
        data=parser.parse_local('工作日下午一点提醒我上课',friday)
        self.assertEqual(datetime.fromisoformat(data['fire_at']),datetime(2026,11,2,13,tzinfo=bridge.CST))


class NaturalReminderFlowTest(tr.ReminderFlowTest):
    async def test_exact_user_sentence_creates_in_private_without_template_or_llm(self):
        with at():e=await self.request('今天下午1点提醒我上课')
        items=self.backend.db.scoped_pending(e.unified_msg_origin,'20001')
        self.assertEqual(len(items),1);self.assertEqual(items[0].event_content,'上课')
        self.assertEqual(items[0].trigger_time,NOW.replace(hour=13).timestamp())
        self.assertIn('今天 13:00',e.sent[0]);self.assertNotIn('哪天几点',e.sent[0])
        self.assertFalse(self.ctx.calls)
    async def test_exact_user_sentence_creates_in_original_group(self):
        with at():e=await self.request('大肥鱼，今天下午一点提醒我上课',private=False)
        items=self.backend.db.scoped_pending(e.unified_msg_origin,'20001')
        self.assertEqual(len(items),1);self.assertEqual(items[0].event_content,'上课')
        self.assertEqual(items[0].unified_msg_origin,'qqai:GroupMessage:888888888')
    async def test_missing_clock_only_asks_for_clock_then_accepts_plain_answer(self):
        with at():
            first=await self.request('明天提醒我上课')
            self.assertEqual(first.sent[0],'明天几点提醒你上课呀？')
            last=await self.request('下午一点')
        items=self.backend.db.scoped_pending(last.unified_msg_origin,'20001')
        self.assertEqual(len(items),1);self.assertEqual(items[0].trigger_time,NOW.replace(day=27,hour=13).timestamp())
        self.assertEqual(items[0].event_content,'上课');self.assertFalse(self.ctx.calls)
    async def test_missing_activity_accepts_plain_activity_without_repeating_time(self):
        with at():
            first=await self.request('明天下午一点提醒我')
            self.assertIn('明天 13:00，提醒你做什么',first.sent[0])
            last=await self.request('上课')
        items=self.backend.db.scoped_pending(last.unified_msg_origin,'20001')
        self.assertEqual(items[0].event_content,'上课');self.assertIn('明天 13:00',last.sent[0])
    async def test_past_today_time_is_explained_without_silently_changing_day(self):
        with at(NOW.replace(hour=14)):
            first=await self.request('今天下午一点提醒我上课')
            self.assertIn('今天 13:00 已经过了',first.sent[0])
            self.assertFalse(self.backend.db.scoped_pending(first.unified_msg_origin,'20001'))
            last=await self.request('那就明天吧')
        items=self.backend.db.scoped_pending(last.unified_msg_origin,'20001')
        self.assertEqual(items[0].trigger_time,NOW.replace(day=27,hour=13).timestamp())
    async def test_partial_state_is_scoped_to_same_person_and_conversation(self):
        with at():
            await self.request('明天提醒我上课')
            same=tr.tp.PrivateEvent('下午一点',sender='20001')
            other=tr.tp.PrivateEvent('下午一点',sender='20002')
            group=tr.tc.Event('下午一点',sender='20001')
            self.assertTrue(self.p.reminders.followup(same,'下午一点'))
            self.assertFalse(self.p.reminders.followup(other,'下午一点'))
            self.assertFalse(self.p.reminders.followup(group,'下午一点'))
    async def test_partial_state_expires_and_can_be_cancelled(self):
        with at():
            await self.request('明天提醒我上课')
            e=await self.request('算了');self.assertIn('先不设',e.sent[0])
            self.assertFalse(self.p.reminders.pending)
            await self.request('明天提醒我上课')
        for value in self.p.reminders.pending.values():value['at']-=601
        self.assertFalse(self.p.reminders.followup(e,'下午一点'))
    async def test_quoted_activity_is_a_valid_request_and_negative_request_does_not_create(self):
        with at():
            e=await self.request('今天下午一点提醒我“上课”')
            denied=await self.request('明天下午一点不要提醒我喝水')
        items=self.backend.db.scoped_pending(e.unified_msg_origin,'20001')
        self.assertEqual(len(items),1);self.assertEqual(items[0].event_content,'上课')
        self.assertNotIn('记下啦',denied.sent[0])
    async def test_semantic_fallback_sees_full_original_sentence_and_known_partial(self):
        with at():
            await self.request('提醒我上课')
            self.ctx.responses=[json.dumps({'action':'create','fire_at':'2026-11-02T08:00:00+08:00','event':'上课','recurrence':'none'})]
            e=await self.request('下周一早八')
        self.assertIn('R0001',e.sent[0]);self.assertEqual(self.p.store.used('llm_calls'),1)
        payload=json.loads(self.ctx.calls[-1]['prompt'])
        self.assertEqual(payload['request'],'下周一早八')
        self.assertEqual(payload['previous_incomplete_request'],'提醒我上课')
        self.assertEqual(self.ctx.calls[-1]['contexts'],[])
    async def test_complex_offset_is_not_misread_as_the_class_time(self):
        self.ctx.responses=[json.dumps({'action':'create','fire_at':'2026-10-27T12:50:00+08:00','event':'上课','recurrence':'none'})]
        with at():e=await self.request('明天下午一点上课，提前十分钟提醒我')
        item=self.backend.db.scoped_pending(e.unified_msg_origin,'20001')[0]
        self.assertEqual(item.trigger_time,NOW.replace(day=27,hour=12,minute=50).timestamp())
        self.assertEqual(self.p.store.used('llm_calls'),1)
    async def test_invalid_clock_only_asks_for_valid_time_without_creating(self):
        with at():e=await self.request('今天25点提醒我上课')
        self.assertIn('时刻不太对',e.sent[0])
        self.assertFalse(self.backend.db.scoped_pending(e.unified_msg_origin,'20001'))

# Reuse the fixture and helper methods without rerunning the inherited suite twice.
for _name in dir(tr.ReminderFlowTest):
    if _name.startswith('test_') and _name not in NaturalReminderFlowTest.__dict__:
        setattr(NaturalReminderFlowTest,_name,None)
