"""Read-only search/fetch and bounded public image search. No shell/tools."""
from __future__ import annotations

import asyncio
import base64
import hashlib
from html.parser import HTMLParser
import ipaddress
import json
import os
from pathlib import Path
import re
import socket
import time
from urllib.parse import urlencode,urljoin,urlsplit

from .companion_media import normalize_image

URL=re.compile(r'https?://[^\s<>"\u3000，。！？；）\])]+')
ACTIONS={'web_search','web_fetch','find_sticker'}
PRIVATE_QUERY=re.compile(r'密码|口令|密钥|令牌|身份证|手机号|银行卡|病历|住址|token|password|secret|api[_ -]?key|隐私已隐藏|(?<!\d)1[3-9]\d{9}(?!\d)|[a-z0-9_+/=-]{40,}',re.I)
NEGATIVE=re.compile(r'(?:别|不要|不许|不准|禁止|停止|不用|不喜欢).{0,8}(?:搜|查|找|发|表情)')


def public_url(url):
    try:
        if not isinstance(url,str) or len(url)>2048 or any(c in url for c in '\r\n\t\\'):
            return False
        p=urlsplit(url);host=(p.hostname or '').rstrip('.').lower()
        if p.scheme not in ('http','https') or not host or p.username or p.password or p.port not in (None,80,443):
            return False
        if host=='localhost' or host.endswith(('.localhost','.local','.internal','.invalid')):
            return False
        try:return ipaddress.ip_address(host).is_global
        except ValueError:
            # Reject alternate numeric IPv4 forms rather than resolving them.
            return '.' in host and not re.fullmatch(r'[0-9.]+|0x[0-9a-f.]+',host)
    except ValueError:
        return False


def parse_action(value):
    if not isinstance(value,dict) or value.get('action') not in ACTIONS:
        return None
    action=value['action'];key='url' if action=='web_fetch' else 'query'
    argument=value.get(key)
    if not isinstance(argument,str):return None
    argument=argument.strip()
    if PRIVATE_QUERY.search(argument):return None
    if action=='web_fetch':
        if not public_url(argument):return None
    elif not 1<=len(argument)<=128:
        return None
    return {'action':action,key:argument}


def infer_action(text,labels,local_topics=()):
    """Explicit public commands only; implicit needs can be chosen by the model."""
    text=text.strip().lstrip('，,:： ')
    if NEGATIVE.search(text):return None
    urls=URL.findall(text)
    if urls and re.search(r'读|阅读|看看|总结|概括|网页|链接|内容|文章',text):
        return parse_action({'action':'web_fetch','url':urls[0].rstrip('。！？!?,，；;）)')})
    request=re.fullmatch(r'(?:(?:请|再|帮我|给我|你|能不能|可以|麻烦|上网|联网|网上|到网上|在网上)\s*){0,5}(?:搜|找|查|发|来|给)(.{0,100})(?:表情包|表情)[。!！?？～~\s]*',text)
    if request:
        query=request.group(1)
        query=re.sub(r'^(?:索|寻|一下|一个|一张|一只|个|张|我|下|些|点|一下子)+','',query).strip(' ，,:：的')
        online=bool(re.search(r'上网|联网|网上|搜|找',text))
        residue=query
        for label in labels:residue=residue.replace(label,'')
        for topic in local_topics:residue=residue.replace(topic,'')
        residue=re.sub(r'的|一下|一个|一张|个|张|我|随机|随便','',residue).strip()
        if query and (online or residue):
            return parse_action({'action':'find_sticker','query':query})
    match=re.fullmatch(r'(?:(?:请|帮我|给我|你|能不能|可以|麻烦|上网|联网|到网上|在网上)\s*){0,4}(?:查一下|查一查|查查|搜一下|搜搜|搜索|搜|查询|查找|查)\s*[：:]?\s*(.{1,128})',text)
    if match:
        return parse_action({'action':'web_search','query':match.group(1).strip(' 。！？!?')})
    return None


class PublicResolver:
    async def resolve(self,host,port=0,family=socket.AF_INET):
        answers=await asyncio.get_running_loop().getaddrinfo(host,port,type=socket.SOCK_STREAM,family=family)
        rows=[]
        for fam,kind,proto,canon,address in answers:
            ip=address[0]
            if not ipaddress.ip_address(ip).is_global:raise ValueError('nonpublic_address')
            rows.append({'hostname':host,'host':ip,'port':port,'family':fam,'proto':proto,'flags':socket.AI_NUMERICHOST})
        if not rows:raise ValueError('no_public_address')
        return rows
    async def close(self):pass


async def public_get(url,*,limit=2*1024**2,timeout=10):
    import aiohttp
    connector=aiohttp.TCPConnector(resolver=PublicResolver(),use_dns_cache=False,limit=2)
    async with aiohttp.ClientSession(connector=connector,timeout=aiohttp.ClientTimeout(total=timeout),headers={'User-Agent':'Mozilla/5.0 QQAI/1.4'}) as session:
        for _ in range(3):
            if not public_url(url):raise ValueError('nonpublic_url')
            async with session.get(url,allow_redirects=False) as response:
                if response.status in (301,302,303,307,308):
                    url=urljoin(url,response.headers.get('Location',''));continue
                if response.status!=200 or int(response.headers.get('Content-Length','0'))>limit:
                    raise ValueError('public_response')
                data=bytearray()
                async for chunk in response.content.iter_chunked(65536):
                    data.extend(chunk)
                    if len(data)>limit:raise ValueError('public_size')
                return bytes(data)
    raise ValueError('public_redirects')


class ImageSearchParser(HTMLParser):
    def __init__(self):super().__init__();self.items=[]
    def handle_starttag(self,tag,attrs):
        if tag!='a' or len(self.items)>=40:return
        try:
            item=json.loads(dict(attrs).get('m','{}'))
            if public_url(item.get('murl')):
                self.items.append({'image_url':item['murl'],'source_url':item.get('purl') if public_url(item.get('purl')) else item['murl'],
                                   'title':str(item.get('t',''))[:100]})
        except (ValueError,TypeError):pass


class NetworkClient:
    @staticmethod
    def credentials(cfg,provider_id):
        model=next((p for p in cfg.get('provider',[]) if p.get('id')==provider_id),{})
        source=next((s for s in cfg.get('provider_sources',[]) if s.get('id')==model.get('provider_source_id')),None)
        if not source or urlsplit(source.get('api_base','')).hostname!='api.deepseek.com':
            source=next((s for s in cfg.get('provider_sources',[]) if s.get('enable') and s.get('id')=='deepseek'),None)
        if not source or urlsplit(source.get('api_base','')).hostname!='api.deepseek.com':
            raise ValueError('search_provider_unavailable')
        if urlsplit(source['api_base']).scheme!='https':raise ValueError('search_provider_scheme')
        keys=source.get('key');key=keys[0] if isinstance(keys,list) and keys else keys
        if not isinstance(key,str) or not key:raise ValueError('search_credentials_unavailable')
        headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'}
        headers.update(source.get('custom_headers') or {})
        return headers

    async def api(self,cfg,provider_id,kind,payload):
        import aiohttp
        if kind not in ('search','fetch'):raise ValueError('search_kind')
        headers=self.credentials(cfg,provider_id)
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as session:
            async with session.post('https://api.deepseek.com/v1/tools/'+kind,headers=headers,json=payload,allow_redirects=False) as response:
                if response.status!=200:raise ValueError('search_http_'+str(response.status))
                raw=bytearray()
                async for chunk in response.content.iter_chunked(65536):
                    raw.extend(chunk)
                    if len(raw)>1024*1024:raise ValueError('search_response_size')
                return json.loads(raw)

    async def search(self,cfg,provider_id,query):
        data=await self.api(cfg,provider_id,'search',{'query':query,'count':5,'need_content':True})
        result=[]
        for row in data.get('results',[])[:5]:
            if isinstance(row,dict) and public_url(row.get('url')):
                result.append({'title':str(row.get('title',''))[:100],'url':row['url'],
                               'date':str(row.get('date') or '')[:40],
                               'content':str(row.get('content') or row.get('summary') or row.get('snippet') or '')[:3000]})
        return result

    async def fetch(self,cfg,provider_id,url):
        if not public_url(url):raise ValueError('fetch_url')
        p=urlsplit(url)
        await PublicResolver().resolve(p.hostname,p.port or (443 if p.scheme=='https' else 80),socket.AF_UNSPEC)
        data=await self.api(cfg,provider_id,'fetch',{'url':url})
        content=str(data.get('content') or '')[:10000]
        return [{'title':str(data.get('title') or '')[:100],'url':url,'content':content}] if content.strip() else []

    async def sticker_candidates(self,query):
        # Search broad animal meme collections; let vision match the exact mood.
        # Over-specific concatenated Chinese queries often return stock photos.
        subject=re.fullmatch(r'(猫猫|猫咪|小猫|狗狗|小狗|狗子)(?:的)?(?:不开心|开心|快乐|高兴|难过|委屈|生气|害羞|可爱|搞笑|疑惑|震惊)*',query)
        keyword=({'猫猫':'猫咪','小猫':'猫咪','狗狗':'小狗','狗子':'小狗'}.get(subject.group(1),subject.group(1)) if subject else query)
        url='https://www.bing.com/images/search?'+urlencode({'q':keyword+'表情包','adlt':'strict','count':12})
        parser=ImageSearchParser();parser.feed((await public_get(url,limit=1024*1024,timeout=10)).decode('utf-8','replace'))
        result=[];seen=set();deadline=time.monotonic()+18
        ranked=sorted(parser.items,key=lambda item:not bool(re.search(r'表情|斗图|meme|sticker|reaction',item['title'],re.I)))
        for item in ranked[:12]:
            host=(urlsplit(item['image_url']).hostname or '').lower()
            if host.endswith(('nximg.cn','nipic.com','chuangkit.com','2008php.com')) or item['image_url'] in seen:continue
            seen.add(item['image_url'])
            remaining=deadline-time.monotonic()
            if remaining<1 or len(result)>=3:break
            try:
                raw=await public_get(item['image_url'],limit=3*1024**2,timeout=min(5,remaining))
                data=await asyncio.to_thread(normalize_image,raw)
                result.append({'data_url':data,'source_url':item['source_url'],'title':item['title']})
            except asyncio.CancelledError:raise
            except Exception:continue
        return result


class WebStickerCache:
    def __init__(self,directory):
        self.directory=Path(directory);self.entries=[]
        self.directory.mkdir(mode=0o700,parents=True,exist_ok=True)
        path=self.directory/'index.json'
        if path.is_file():
            try:
                rows=json.loads(path.read_text(encoding='utf-8'))
                if isinstance(rows,list):
                    self.entries=[v for v in rows[:20] if isinstance(v,dict) and isinstance(v.get('stamp'),(int,float)) and isinstance(v.get('bytes'),int)]
            except (ValueError,OSError,TypeError):pass

    def get(self,query):
        digest=hashlib.sha256(query.encode()).hexdigest()
        for item in reversed(self.entries):
            if item.get('query_sha256')!=digest or time.time()-item.get('stamp',0)>7*86400:continue
            name=item.get('file','')
            if not re.fullmatch(r'[0-9a-f]{64}\.jpg',name):continue
            path=self.directory/name
            if path.is_file() and not path.is_symlink() and path.stat().st_size<=2*1024**2:
                raw=path.read_bytes()
                if hashlib.sha256(raw).hexdigest()==name[:-4] and public_url(item.get('source_url')):
                    return {'data_url':'data:image/jpeg;base64,'+base64.b64encode(raw).decode(),'source_url':item['source_url']}
        return None

    def put(self,query,item):
        if len(self.entries)>=20:return
        raw=base64.b64decode(item['data_url'].split(',',1)[1]);digest=hashlib.sha256(raw).hexdigest()
        if len(raw)>1024*1024 or sum(e.get('bytes',0) for e in self.entries)+len(raw)>10*1024**2:return
        target=self.directory/(digest+'.jpg')
        if target.is_symlink():return
        target.write_bytes(raw);os.chmod(target,0o600)
        self.entries.append({'query_sha256':hashlib.sha256(query.encode()).hexdigest(),'file':target.name,
                             'source_url':item['source_url'],'stamp':time.time(),'bytes':len(raw)})
        path=self.directory/'index.json';tmp=path.with_suffix('.tmp')
        tmp.write_text(json.dumps(self.entries,ensure_ascii=False),encoding='utf-8');os.chmod(tmp,0o600);os.replace(tmp,path)
