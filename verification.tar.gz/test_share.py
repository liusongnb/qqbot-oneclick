"""New-instance portability and isolation checks, without external API calls."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent
PACKAGE=ROOT/'qqbot-share'
spec=importlib.util.spec_from_file_location('share_configure',PACKAGE/'scripts/configure.py')
config=importlib.util.module_from_spec(spec);spec.loader.exec_module(config)

class ShareTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'instance'
        self.a={'group':'777777777','api_key':'synthetic-not-a-real-key','model':'synthetic-model','voice_engine':'edge_tts'}
    def tearDown(self):self.tmp.cleanup()
    def test_fresh_data_and_credentials_are_generated_independently(self):
        with patch.object(config.os,'chown',create=True):cfg,companion=config.prepare(self.root,self.a)
        self.assertEqual(cfg['platform_settings']['id_whitelist'],['777777777'])
        self.assertEqual(companion['allowed_groups'],['777777777']);self.assertEqual(companion['voice_unlimited_users'],[])
        self.assertEqual(companion['voice_engine'],'edge_tts');self.assertEqual(companion['daily_voice_chars'],2000)
        self.assertEqual(cfg['plugin_set'],['qqai_companion']);self.assertFalse(cfg['provider_settings']['enable'])
        self.assertFalse((self.root/'astrbot/data/data_v4.db').exists())
        self.assertFalse((self.root/'astrbot/data/plugin_data').exists())
        reminder=json.loads((self.root/'astrbot/data/config/astrbot_plugin_reminder_config.json').read_text(encoding='utf-8'))
        self.assertEqual(reminder['allowed_groups'],['777777777'])
        other=Path(self.tmp.name)/'other'
        with patch.object(config.os,'chown',create=True):cfg2,_=config.prepare(other,self.a)
        self.assertNotEqual(cfg['dashboard']['jwt_secret'],cfg2['dashboard']['jwt_secret'])
        self.assertNotEqual(cfg['platform'][0]['ws_reverse_token'],cfg2['platform'][0]['ws_reverse_token'])
    def test_existing_data_is_not_overwritten(self):
        p=self.root/'astrbot/data';p.mkdir(parents=True);marker=p/'important';marker.write_text('preserve')
        with self.assertRaises(ValueError):config.prepare(self.root,self.a)
        self.assertEqual(marker.read_text(),'preserve')
    def test_invalid_group_rejected_before_any_data_is_created(self):
        self.a['group']='1;touch /tmp/unsafe'
        with self.assertRaises(ValueError):config.prepare(self.root,self.a)
        self.assertFalse(self.root.exists())
    def test_breeze_requires_recipient_key_and_voice(self):
        self.a['voice_engine']='breeze_blue'
        with self.assertRaises(ValueError):config.prepare(self.root,self.a)
        self.assertFalse(self.root.exists())
    def test_share_templates_have_no_original_ids_or_secrets(self):
        c=json.loads((PACKAGE/'templates/plugin-config.json').read_text(encoding='utf-8'))
        for key in ['allowed_groups','voice_unlimited_users']:self.assertEqual(c[key],[])
        for key in ['breeze_api_key','breeze_voice_id']:self.assertEqual(c[key],'')
    def test_docker_file_has_local_bindings_and_no_host_access(self):
        import yaml
        c=yaml.safe_load((PACKAGE/'compose.yaml').read_text(encoding='utf-8'))
        self.assertEqual(c['name'],'qqbotshare')
        for service in c['services'].values():
            self.assertTrue(all(p.startswith('127.0.0.1:') for p in service['ports']))
            self.assertNotIn('network_mode',service);self.assertFalse(service.get('privileged',False))
            self.assertTrue(all('docker.sock' not in p for p in service['volumes']))
    def test_shared_memory_uses_the_recipient_group_and_rejects_invalid_groups(self):
        import sys
        sys.path.insert(0,str(ROOT/'checks'))
        import test_companion as tc
        obj=tc.m.Main(tc.Context(),json.loads((ROOT/'checks/plugin-config.json').read_text(encoding='utf-8')))
        for group in ['777777777','666666666']:
            obj.config['allowed_groups']=[group]
            obj.store=tc.m.Store(Path(self.tmp.name)/('portable-memory-'+group))
            try:
                self.assertTrue(obj.sharing_enabled())
                self.assertEqual(obj.shared_scopes('qqai','20001')[0],obj.store.scope('qqai',group,'20001'))
            finally:obj.store.close()
        for groups in [[],['invalid'],['777777777','666666666']]:
            obj.config['allowed_groups']=groups
            self.assertFalse(obj.sharing_enabled())
            with self.assertRaises(ValueError):obj.shared_scopes('qqai','20001')

if __name__=='__main__':unittest.main()
