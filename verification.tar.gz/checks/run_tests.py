"""Run the isolated suite and save a compact, source-bound result."""
import hashlib
import json
from pathlib import Path
import time
import unittest
import test_companion
import test_network
import test_schedule
import test_voice
import test_private
import test_shared_memory
import test_breeze
import test_voice_budget
import test_reminders
import test_natural_reminders

root=Path(__file__).resolve().parent
suite=unittest.defaultTestLoader.loadTestsFromModule(test_companion)
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_network))
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_schedule))
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_voice))
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_private))
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_shared_memory))
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_breeze))
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_voice_budget))
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_reminders))
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_natural_reminders))
started=time.monotonic()
result=unittest.TextTestRunner(verbosity=1).run(suite)
report={'passed':result.wasSuccessful(),'tests_run':result.testsRun,
        'failures':len(result.failures),'errors':len(result.errors),
        'elapsed_sec':round(time.monotonic()-started,3),'real_model_calls':0,'real_qq_sends':0,
        'module_sha256':hashlib.sha256((root/'astrbot_plugin_qqai_companion/main.py').read_bytes()).hexdigest()}
report['source_sha256']={str(path.relative_to(root/'astrbot_plugin_qqai_companion')).replace('\\','/'):hashlib.sha256(path.read_bytes()).hexdigest()
                        for path in sorted((root/'astrbot_plugin_qqai_companion').rglob('*')) if path.is_file() and '__pycache__' not in str(path)}
(root/'test-results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
report['external_source_sha256']={str(path.relative_to(root/'plugins')).replace('\\','/'):hashlib.sha256(path.read_bytes()).hexdigest()
                                for path in sorted((root/'plugins').rglob('*')) if path.is_file() and '__pycache__' not in str(path)}
(root/'test-results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in {'source_sha256','external_source_sha256'}}|{'files_verified':len(report['source_sha256'])}))
raise SystemExit(0 if result.wasSuccessful() else 1)
